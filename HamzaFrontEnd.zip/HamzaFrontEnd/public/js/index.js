$(document).ready(function () {

    $("#poublie").on("click", function () {
        $("#Annonce").trigger("click");
    });
});
var vm = new Vue({
    el: '#app',
    data: {
        product: {
            id_client: 0,
            id_category: 0,
            unity:1,
            price: '',
            width: 0,
            height: 0,
            weight: 0,
            show_price: 1,
            show_telephone: 1,
            id_ville: 0,
            id_secteur: 0,
            titre: "",
            description: "",
            type_annonce: 0,
            is_premium: 0,
            id_marque:0,
            id_model:0,
            type_carburant:'DIESEL',
            km:0,
            annee:'1900',
            n_pieces:0,
            superficie:0,
        },
        user: {
            id: 0,
            type_client: 0,
            name: '',
            email: '',
            password: '',
            phone: '',
            hide_phone: 0
        },
        secteurs:[],
        marque_vehicules:[],
        model_marque_vehicules:[],
    },
    methods: {
        onChange: function ()
        {
            var $i = this.product.id_category;
            $(".form").hide();
            $("#form_" + $i).show();
        },

        changeVille: function ()
        {
            axios.post(window.Laravel.url + '/sectuer', this.product)
                    .then(response =>
                    {
                        this.secteurs = response.data;
                    })
                    .catch(error =>
                    {
                        console.log('errors : ', error);
                    });
        },
        changeModel_vehicule: function ()
        {
            axios.post(window.Laravel.url + '/model_marque_vehicule', this.product)
                    .then(response =>
                    {
                        this.model_marque_vehicules = response.data;
                    })
                    .catch(error =>
                    {
                        console.log('errors : ', error);
                    });
        },
        changeMarque_vehicule: function ()
        {
            axios.post(window.Laravel.url + '/marque_vehicule')
                    .then(response =>
                    {
                        this.marque_vehicules = response.data;
                    })
                    .catch(error =>
                    {
                        console.log('errors : ', error);
                    });
        },

        onSave: function ()
        {
            location.href = window.Laravel.url + '/espace_client';
        },
        addProduct: function ()
        {
            axios.post(window.Laravel.url + '/chekLogin', this.user)
                    .then(response =>
                    {
//                        alert(response.data[1]);
                        this.user.id = response.data[0];

                        if (response.data[1] === '0')
                        {
                            this.product.id_client = this.user.id;
                            axios.post(window.Laravel.url + '/add_product', this.product)
                                    .then(response =>
                                    {
                                        $("#up_file").trigger("click");

                                        //location.href = window.Laravel.url + '/espace_client';
                                    })
                        } else
                        {
                            if (response.data[1] === '1')
                            {
                                this.product.id_client = this.user.id;
                                axios.post(window.Laravel.url + '/add_product', this.product)
                                        .then(response =>
                                        {
                                            $("#up_file").trigger("click");
                                            // location.href = window.Laravel.url + '/espace_client';
                                        })
                            } else
                            {
                                alert('Moe de pass error');
                            }
                        }
                    })
                    .catch(error =>
                    {
                        console.log('errors : ', error);
                    });
        },

        submit() {
            this.$router.push();
        },

        validateForm(scope) {
            this.$validator.validateAll(scope).then((result) => {
                if (result) {
//                    alert('bien add');
                    this.addProduct();
                    $("#mdl").trigger("click");
                }
            });
        }
    },
    created: function () {
        //this.onChange();
        this.changeMarque_vehicule();
    }
}
);