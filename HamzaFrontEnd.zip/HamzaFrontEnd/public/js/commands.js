/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


$(document).ready(function () {
    $("._selector ul li").on("click", function () {
        //alert($(this).attr("data-qa-id"));_selectorv
        var vr = $(this).attr("data-qa-id");
        var text = $(this).html();
        //    alert(vr);
        $("#_selector option[value='" + vr + "']").attr("selected", "selected");
        //  $("_1etKl").hide();
        $("#comboType").text(text);
        $("._selector").hide();
    });
    $("._3X-Yv").on("click", function () {
        $("._selector").show();
             
    });
    
    $("#_test").on("change", function () {
        alert ($(this).vinoal());
   
    $('#app').html('<ol> <todo-item></todo-item> </ol><div style="text-align: center; background-color: black; height: 50px; width: 50px; color: black">trtrvctr</div>');//<div id="chg"><ol> <todo-item></todo-item> </ol></div>
    });
    
}
        
        
)
