<?php


//Route::get('/', function () {
//    return view('welcome');
//});
Route::get('/', 'ProductController@welcome');
Route::get('offres', 'ProductController@search');
Route::get('offres/add', 'ProductController@create');

Route::get('Emplois', 'ProductController@EmploiServices');
Route::get('Autres', 'ProductController@Autres');
Route::get('Entreprises', 'ProductController@Entreprises');
Route::get('HabillementBienEtre', 'ProductController@HabillementBienEtre');
Route::get('Immobilier', 'ProductController@Immobilier');
Route::get('InformatiqueMultimedia', 'ProductController@InformatiqueMultimedia');
Route::get('LoisirsDivertissement', 'ProductController@LoisirsDivertissement');
Route::get('MaisonJardin', 'ProductController@MaisonJardin');
Route::get('Vehicules', 'ProductController@Vehicules');
Route::get('Services', 'ProductController@Services');
Route::get('Vaconces', 'ProductController@Vaconces');

Route::post('/sectuer', 'SecteurController@sectuer');
Route::post('/model_marque_vehicule', 'SecteurController@model');
Route::post('/marque_vehicule', 'SecteurController@marque');

Route::get('/espace_client', 'ProductController@ProductsClient');

Auth::routes();

Route::get('/afficher/{ville}/{nom}', 'ProductController@afficher');

Route::get('/search/{titre}', 'ProductController@search_titre');
Route::get('/search/{titre}/{category}', 'ProductController@searchAll');
Route::get('/search_ville/{ville}', 'ProductController@search_ville');

Route::post('/add_product', 'ProductController@add_product');
Route::post('/my_annonce', 'ProductController@upload');

Route::post('/paginate_next', 'ProductController@paginate_next');

Route::post('/chekLogin', 'ProductController@chekLogin')->name('chekLogin');

Route::get('/offres/affiche/{id}', 'ProductController@afficher_product');
Route::get('/offres/liste/{id}', 'ProductController@liste_product');

Route::get('/offres/{id}', 'ProductController@prodct_category');

Route::post('/verifier_annonce', 'ProductController@ProductsClient');
Route::post('/liste_annonce', 'ProductController@ProductsClient');
Route::get('/espace', 'ProductController@espace');

?>