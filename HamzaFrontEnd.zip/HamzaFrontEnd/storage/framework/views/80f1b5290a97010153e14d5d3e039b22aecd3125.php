


<div class="modal-container">
    <label id="close-action" class="modal-close" for="modal-toggle">✕</label>
    <div id="modal-toggle" class="modal-content">
        <div class="modal-body">
            <div class="head-elem"> <span>1 Choisissez une catégorie </span> <span> 2 Choisissez une sous-catégorie </span></div>
            <ul class="table-content"> 
                <li><i id="147753099" class="sprite_ai_popup_Image_16"></i><div>IMMOBILIER</div>
                    <ul class="sub-categories-elm">
                        <li><div data-parent="1000">Appartements</div>
                        </li><li><div data-parent="1000">Maisons et Villas</div></li>
                        <li><div data-parent="1000">Locations de vacances</div></li>
                        <li><div data-parent="1000">Bureaux et Plateaux</div></li>
                        <li><div data-parent="1000">Magasins, Commerces et Locaux industriels</div></li>
                        <li><div data-parent="1000">Terrains et Fermes</div></li>
                        <li><div data-parent="1000">Colocations</div></li>
                    </ul>
                </li>
                <li><i id="998254134" class="sprite_ai_popup_Image_17"></i><div>VEHICULES</div>
                    <ul class="sub-categories-elm">
                        <li><div data-parent="2000">Voitures</div></li>
                        <li><div data-parent="2000">Motos</div></li>
                        <li><div data-parent="2000">Pièces et Accessoires pour véhicules</div></li>
                        <li><div data-parent="2000">Bateaux</div></li>
                        <li><div data-parent="2000">Vélos</div></li>
                        <li><div data-parent="2000">Véhicules Professionnels</div></li>
                    </ul>
                </li>
                <li><i id="89403205424" class="sprite_ai_popup_Image_19"></i><div>POUR LA MAISON ET JARDIN</div>
                    <ul class="sub-categories-elm"><li><div data-parent="3000">Electroménager et Vaisselles</div></li>
                        <li><div data-parent="3000">Meubles et Décoration</div></li>
                        <li><div data-parent="3000">Jardin et Outils de bricolage</div></li>
                    </ul>
                </li>
                <li><i id="9404320524" class="sprite_ai_popup_Image_20"></i><div>LOISIRS ET DIVERTISSEMENT</div>
                    <ul class="sub-categories-elm">
                        <li><div data-parent="4000">Sports et Loisirs</div></li>
                        <li><div data-parent="4000">Animaux</div></li>
                        <li><div data-parent="4000">Films, Livres, Magazines</div></li>
                        <li><div data-parent="4000">Voyages et Billetterie</div></li>
                        <li><div data-parent="4000">Art et Collections</div></li>
                        <li><div data-parent="4000">Instruments de Musique</div></li>
                    </ul>
                </li>
                <li><i id="9460320524" class="sprite_ai_popup_Image_18"></i><div>INFORMATIQUE ET MULTIMEDIA</div>
                    <ul class="sub-categories-elm">
                        <li><div data-parent="5000">Téléphones</div></li>
                        <li><div data-parent="5000">Image &amp; Son</div></li>
                        <li><div data-parent="5000">Ordinateurs portables</div></li>
                        <li><div data-parent="5000">Jeux vidéo et Consoles</div></li>
                        <li><div data-parent="5000">Ordinateurs de bureau</div></li>
                        <li><div data-parent="5000">Accessoires informatique et Gadgets</div></li>
                        <li><div data-parent="5000">Appareils photo et Caméras</div></li>
                        <li><div data-parent="5000">Tablettes</div></li>
                        <li><div data-parent="5000">Télévisions</div></li>
                    </ul>
                </li>
                <li><i id="9403209524" class="sprite_ai_popup_Image_22"></i><div>EMPLOI ET SERVICES</div>
                    <ul class="sub-categories-elm">
                        <li><div data-parent="6000">Offres d'emploi</div></li>
                        <li><div data-parent="6000">Demandes d'emploi</div></li>
                        <li><div data-parent="6000">Services</div></li>
                        <li><div data-parent="6000">Cours et Formations</div></li>
                        <li><div data-parent="6000">Stages</div></li>
                    </ul>
                </li>
                <li><i id="94032056084" class="sprite_ai_popup_Image_23"></i><div>Autres</div>
                    <ul class="sub-categories-elm">
                        <li><div data-parent="7000">AUTRES</div></li>
                    </ul>
                </li>
                <li><i id="9403205624" class="sprite_ai_popup_Image_24"></i><div>HABILLEMENT ET BIEN ETRE</div>
                    <ul class="sub-categories-elm">
                        <li><div data-parent="8000">Vêtements pour enfant et bébé</div></li>
                        <li><div data-parent="8000">Vêtements</div></li>
                        <li><div data-parent="8000">Sacs et Accessoires</div></li>
                        <li><div data-parent="8000">Produits de beauté</div></li>
                        <li><div data-parent="8000">Equipements pour enfant et bébé</div></li>
                        <li><div data-parent="8000">Chaussures</div></li>
                        <li><div data-parent="8000">Montres et Bijoux</div></li>
                    </ul>
                </li>
                <li><i id="94032056024" class="sprite_ai_popup_Image_21"></i><div>ENTREPRISES</div>
                    <ul class="sub-categories-elm">
                        <li><div data-parent="9000">Matériels Professionnels</div></li>
                        <li><div data-parent="9000">Business et Affaires commerciales</div></li>
                        <li><div data-parent="9000">Stocks et Vente en gros</div></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>

