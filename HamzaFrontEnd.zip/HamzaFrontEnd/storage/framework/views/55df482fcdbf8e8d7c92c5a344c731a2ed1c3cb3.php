<style >
   // .nav-link{  color: #fff !important;  }
     .white_nav {    color: #3C3C3C !important;  border-left: 1px solid #BDC3C9;}
     .white_nav:hover {    text-decoration: underline;}
</style>
<nav class="navbar navbar-expand-lg navbar-light " style="background: #ECEEEF" >
    
    <span class="navbar-text">
                 <?php if(Route::has('login')): ?>
                 <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a style="color: #ff6068 !important;" href="<?php echo e(url('/home')); ?>">Principale</a>
                    <?php else: ?>                       
                    <a class="navbar-brand"   href="#">Bienvenue</a> <a style="color: #ff6068 !important;font-weight: bold"  href="<?php echo e(route('login')); ?>" >Connectez-vous</a>  ou <a style="color: #ff6068 !important;font-weight: bold"  href="<?php echo e(route('register')); ?>">inscrivez-vous</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>               
            </span>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item active">                      
                        <a class="nav-link white_nav" style="color: #009F97 !important" href="<?php echo e(url('/offres/add')); ?>">DÉPOSER UNE ANNONCE <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link white_nav" href="<?php echo e(url('/offres')); ?>">OFFRES</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link white_nav" href="#">DEMANDES</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link white_nav" href="#">BOUTIQUES</a>
                    </li>

                    <!-- <form class="form-inline">
                                <button class="btn btn-outline-success" type="button">Se connecter</button>
                                <button class="btn btn-sm btn-outline-secondary" type="button">S'inscrire</button>
                            </form> 
                    <li class="nav-item">
                                <a class="nav-link disabled" href="#">Disabled</a>
                            </li>-->     
                </ul>
            </div>
        </nav>

