
            <div class="card">
                <h6 class="card-header"><i class="far fa-address-card mr-2"></i>Vos coordonnées</h6>
                <div class="card-body">
                    <div class="form-group row">
                        <label for="exampleFormControlSelect1" class="col-sm-2" >Vous êtes un *</label>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="0" v-model="user.type_client">
                            <label class="form-check-label" for="inlineRadio1">Particulier</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="1" v-model="user.type_client">
                            <label class="form-check-label" for="inlineRadio2">Professionnel</label>
                        </div>

                        <hr class="input-xxlarge">
                    </div>
                    <hr>
                    <div class="form-group row">
                        <label for="edtNom" class="col-sm-2" >Nom </label>
                        <input type="text" class="form-control" id="edtNom" style="width: 270px" v-model="user.nom" maxlength="100" required>
                    </div>
                    <div class="form-group row">                           
                        <label for="exampleInputEmail1" class="col-sm-2">Email </label>
                        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" style="width: 270px" maxlength="100" v-model="user.email">
                    </div>
                    <div class="form-group row">
                        <label for="edtPhone" class="col-sm-2" >Téléphone </label>
                        <div  style="padding: 0px;width: 270px" >
                            <input type="text" class="form-control" id="edtPhone" v-model="user.phone" required>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" v-model="user.hide_phone" id="defaultCheck1" maxlength="50">
                                <label class="form-check-label" for="defaultCheck1">
                                    Cacher numéro
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-2">
                            <label for="exampleInputPassword1" >Mot de passe </label>
                            <small id="passwordHelp" class="form-text text-muted">[minimum 6 caractères]</small>
                        </div>
                        <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Entrer un mot de passe" style="width: 437px" v-model="user.password" maxlength="100">

                        <ol>
                            <li v-for="todo in todos">
                                {{ todo.text }}
                            </li>
                        </ol>

                    </div>
                </div>
            </div>
         