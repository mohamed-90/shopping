<div>
    <div class="form-group row">
        <label  class="col-sm-2" >Type D'annonce:</label>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="0" checked v-model="product.type_annonce">
            <label class="form-check-label" for="exampleRadios1">Offre    </label>
        </div>
        <div class="form-check">   </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="1" v-model="product.type_annonce">
            <label class="form-check-label" for="exampleRadios2"> Demande</label>
        </div>                      
        <hr class="input-xxlarge">                        
    </div>
    <div class="form-group row">
        <label for="Secteur" class="col-sm-2" >Secteur:</label>
        <select class="form-control" id="Secteur" @change="onChange()" style="max-width: 220px; width: 220px;" v-model="product.Secteur">
            <option value="0" >Toute la ville</option>
            <option value="1" selected>-- Sélectionnez secteur --</option>

        </select>                         
    </div>

    <div class="form-group row">
        <label for="Titre" class="col-sm-2" >Titre: </label>
        <input type="text" class="form-control" id="Titre" style="width: 500px" placeholder="Titre" v-model="product.titre" maxlength="100" required>
    </div>

    <div class="form-group row">
        <label for="Texte" class="col-sm-2" >Texte de l'annonce:</label>
        <div >
            <textarea id="Texte" style="width: 500px;" rows="6" cols="3" class="form-control" placeholder="discription" v-model="product.discription"></textarea>         
        </div>                    
    </div>

    <div class="form-group row">
        <label class="col-form-label col-sm-2">Prix:</label>                       
        <div class="input-group" style="width: 230px">
            <span class="input-group-text">DH</span>                               
            <input type="text" class="form-control" placeholder="0.00" v-model="product.prix">     
        </div>
    </div>
</div>