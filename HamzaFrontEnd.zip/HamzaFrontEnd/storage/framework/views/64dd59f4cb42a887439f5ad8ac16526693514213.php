<html>
    <head>
        <title>Hamza</title>
        <meta charset="${encoding}">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>"/>

    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <body>
        <div class="container">
  
                <?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <br/>
                <?php echo $__env->make('partials.search_product', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <div class="row">
                    <div class="col" style="text-align: center">
                        <h2>Toutes les catégories que vous imaginez</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm">      
                        <div class="card bg-light mb-3" style="text-align: center">                                

                            <div class="card-body">
                                <h1>   <i class="fas fa-car"></i><i class="fas fa-motorcycle"></i></h1>
                                <h5 class="card-title" style="text-align: center" >VEHICULES</h5>
<!--                                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                <a  class="list-group-item list-group-item-action" href="#" class="btn btn-primary">Go somewhere</a>-->
                            </div>
                        </div>
                    </div>
                    <div class="col-sm">  
                        <div class="card bg-light mb-3" style="text-align: center"> <!--style="width: 16rem;text-align: center"-->                               

                            <div class="card-body">
                                <h1>   <i class="fas fa-home"></i></h1>
                                <h5 class="card-title">IMMOBILIER</h5>
    <!--                                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                <a  class="list-group-item list-group-item-action" href="#" class="btn btn-primary">Go somewhere</a>-->
                            </div>
                        </div></div>
                    <div class="col-sm">  
                        <div class="card bg-light mb-3" style="text-align: center">                                

                            <div class="card-body">
                                <h1> <i class="far fa-building"></i></h1>
                                <h5 class="card-title">MAISON</h5>
    <!--                                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                <a  class="list-group-item list-group-item-action" href="#" class="btn btn-primary">Go somewhere</a>-->
                            </div>
                        </div>
                    </div>
                    <div class="col-sm">          
                        <div class="card bg-light mb-3" style="text-align: center">                                

                            <div class="card-body">
                                <h1>   <i class="fas fa-laptop"></i></h1>
                                <h5 class="card-title">ELECTRONIQUE</h5>
    <!--                                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                <a  class="list-group-item list-group-item-action" href="#" class="btn btn-primary">Go somewhere</a>-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">     
                    <div class="col-sm">
                        <div class="card bg-light mb-3" style="text-align: center">                                

                            <div class="card-body">
                                <h1>  <i class="fas fa-bicycle"></i></h1>
                                <h5 class="card-title">LOISIRS ET SPORTS</h5>
    <!--                                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                <a  class="list-group-item list-group-item-action" href="#" class="btn btn-primary">Go somewhere</a>-->
                            </div>
                        </div>
                    </div>
                    <div class="col-sm">  
                        <div class="card bg-light mb-3" style="text-align: center">                                

                            <div class="card-body">
                                <h1>   <i class="fas fa-briefcase"></i></h1>
                                <h5 class="card-title">EMPLOI ET SERVICES</h5>
    <!--                                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                <a  class="list-group-item list-group-item-action" href="#" class="btn btn-primary">Go somewhere</a>-->
                            </div>
                        </div>
                    </div>
                    <div class="col-sm">
                        <div class="card bg-light mb-3" style="text-align: center">                                


                            <div class="card-body">
                                <h1>   <i class="fas fa-briefcase"></i></h1>
                                <h5 class="card-title">AUTRES</h5>
    <!--                                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                <a  class="list-group-item list-group-item-action" href="#" class="btn btn-primary">Go somewhere</a>-->
                            </div>
                        </div>
                    </div>
                    <div class="col-sm">
                        <div class="card bg-light mb-3" style="text-align: center">                                


                            <div class="card-body">
                                <h1>   <i class="fas fa-briefcase"></i></h1>
                                <h5 class="card-title">AUTRES</h5>
    <!--                                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                <a  class="list-group-item list-group-item-action" href="#" class="btn btn-primary">Go somewhere</a>-->
                            </div>
                        </div>
                    </div>

                </div>
            </div>
    
        <div class="container">
            <div class="row"> 
                <div class="col" style="text-align: center">
                    <h2>  Sélectionner la ville</h2>
                </div>
            </div>
            <div class="row">
                <div class="col">     
                    <div class="list-group"  id="region_list_1" class="region_list span3 pull-left">
                        <a  class="list-group-item list-group-item-action" id="region_5" href="https://www.hamza.ma/fr/casablanca/">Casablanca</a>
                        <a  class="list-group-item list-group-item-action" id="region_13" href="https://www.hamza.ma/fr/agadir/">Agadir</a>
                        <a  class="list-group-item list-group-item-action" id="region_17" href="https://www.hamza.ma/fr/al_hociema/">Al Hoceïma</a>
                        <a  class="list-group-item list-group-item-action" id="region_14" href="https://www.hamza.ma/fr/béni_mellal/">Béni Mellal</a>
                        <a  class="list-group-item list-group-item-action" id="region_7" href="https://www.hamza.ma/fr/el_jadida/">El Jadida</a>
                        <a  class="list-group-item list-group-item-action" id="region_18" href="https://www.hamza.ma/fr/errachidia/">Errachidia</a>
                        <a  class="list-group-item list-group-item-action" id="region_3" href="https://www.hamza.ma/fr/fès/">Fès</a>
                        <a  class="list-group-item list-group-item-action" id="region_4" href="https://www.hamza.ma/fr/kénitra/">Kénitra</a>
                        <a  class="list-group-item list-group-item-action" id="region_19" href="https://www.hamza.ma/fr/khénifra/">Khénifra</a>
                        <a  class="list-group-item list-group-item-action" id="region_1" href="https://www.hamza.ma/fr/khouribga/">Khouribga</a>
                        <a  class="list-group-item list-group-item-action" id="region_20" href="https://www.hamza.ma/fr/larache/">Larache</a>
                        <a  class="list-group-item list-group-item-action" id="region_8" href="https://www.hamza.ma/fr/marrakech/">Marrakech</a>
                        <a  class="list-group-item list-group-item-action" id="region_9" href="https://www.hamza.ma/fr/meknès/">Meknès</a>
                    </div>
                </div>
                <div class="col">       
                    <div class="list-group" id="region_list_2" class="region_list span3 pull-right">
                        <a  class="list-group-item list-group-item-action" id="region_9" href="https://www.hamza.ma/fr/meknès/">Meknès</a>
                        <a  class="list-group-item list-group-item-action" id="region_21" href="https://www.hamza.ma/fr/nador/">Nador</a>
                        <a  class="list-group-item list-group-item-action" id="region_22" href="https://www.hamza.ma/fr/ouarzazate/">Ouarzazate</a>
                        <a  class="list-group-item list-group-item-action" id="region_10" href="https://www.hamza.ma/fr/oujda/">Oujda</a>
                        <a  class="list-group-item list-group-item-action" id="region_12" href="https://www.hamza.ma/fr/rabat/">Rabat</a>
                        <a  class="list-group-item list-group-item-action" id="region_2" href="https://www.hamza.ma/fr/safi/">Safi</a>
                        <a  class="list-group-item list-group-item-action" id="region_23" href="https://www.hamza.ma/fr/settat/">Settat</a>
                        <a  class="list-group-item list-group-item-action" id="region_6" href="https://www.hamza.ma/fr/salé/">Salé</a>
                        <a  class="list-group-item list-group-item-action" id="region_15" href="https://www.hamza.ma/fr/tanger/">Tanger</a>
                        <a  class="list-group-item list-group-item-action" id="region_16" href="https://www.hamza.ma/fr/taza/">Taza</a>
                        <a  class="list-group-item list-group-item-action" id="region_11" href="https://www.hamza.ma/fr/tétouan/">Tétouan</a>
                        <a  class="list-group-item list-group-item-action" id="colorlink" href="#" onclick="view_other_region_selector()">&gt; Autre ville...</a>
                    </div>
                </div>
            </div>
        </div>
   
    <div class="tab-content" id="pills-tabContent">
        <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">...</div>
        <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">...</div>
        <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">...</div>
    </div>

    <script src="<?php echo e(asset('assets/css/jquery-3.3.1.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
    
    <script src="<?php echo e(asset('js/commands.js')); ?>" type="text/javascript"></script>
</body>
</html>

