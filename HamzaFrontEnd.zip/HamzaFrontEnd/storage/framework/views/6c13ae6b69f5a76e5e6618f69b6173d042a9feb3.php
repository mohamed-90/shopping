<html>
    <head>
        <title>Déposez une annonce</title>
        <meta charset="${encoding}">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </head>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>"/>

    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <body>

        <div class="container" id="app">

            <?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo e(csrf_field()); ?>

            <br>


<section class="jumbotron text-center">
        <div class="container">
          <h1 class="jumbotron-heading">Album example</h1>
          <p class="lead text-muted">Something short and leading about the collection below—its contents, the creator, etc. Make it short and sweet, but not too short so folks don't simply skip over it entirely.</p>
          <p>
            <a href="#" class="btn btn-primary my-2">Main call to action</a>
            <a href="#" class="btn btn-secondary my-2">Secondary action</a>
          </p>
        </div>
      </section>

    
            
  </div>

        <script src="<?php echo e(asset('assets/css/jquery-3.3.1.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
        <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </body>


    <script src="<?php echo e(asset('js/vue.js')); ?>" ></script>
    <script src="<?php echo e(asset('js/veeValidate.js')); ?>" ></script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>

    <script>

Vue.use(VeeValidate);

window.Laravel = <?php echo json_encode([
        'csrfToken' => csrf_token(),
//    'idProduct' => $id_product,
'url' => url('/')
]); ?>

;
    </script>
    <script src="<?php echo e(asset('js/index.js')); ?>"></script>


</html>            