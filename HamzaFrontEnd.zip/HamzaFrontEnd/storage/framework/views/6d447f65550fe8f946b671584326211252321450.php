<div class="form-group row">
                        <label for="exampleFormControlSelect2" class="col-sm-2" >Type D'annonce:</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="0" checked v-model="product.id_category">
                            <label class="form-check-label" for="exampleRadios1">Offre    </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="1" v-model="product.id_category">
                            <label class="form-check-label" for="exampleRadios2"> Demande</label>
                        </div>                      
                        <hr class="input-xxlarge">
                    </div>
                    <div class="form-group row">
                        <label for="edtTitre" class="col-sm-2" >Titre: </label>
                        <input type="text" class="form-control" id="edtTitre" style="width: 270px" placeholder="Titre" v-model="product.titre" maxlength="100" required>
                    </div>
                    <div class="form-group row">
                        <label for="edtTexte" class="col-sm-2" >Texte de l'annonce:</label>
                        <div class="col-lg-10">
                            <textarea id="edtTexte" rows="3" cols="3" class="form-control" placeholder="discription" v-model="product.discription"></textarea>
                        </div>                    
                    </div>
                    <div class="form-group row">
                        <label class="col-form-label col-lg-2">Prix</label>
                        <div class="col-lg-10">
                            <div class="input-group">
                                <span class="input-group-text">DH</span>                               
                                <input type="text" class="form-control" placeholder="0.00 Dh">                              
                            </div>
                        </div>
                    </div>