<html>
    <head>                
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
        <style type="text/css">
            .asideclass{ position :absolute;   bottom: 0; right: 0;            }
            .item_image {  min-width: 100px;min-height: 90px;position: relative;overflow: hidden;float: left;width: 25%;   min-width: 130px; min-height: 120px;max-height: 100%;background: #f2f2f2;  }
            .item_imagePic {  display: block;   height: 100%;min-height: 120px;   text-align: center;   line-height: 120px;        }
            .item_price {  margin: 10px 0 0 0;  margin: 1rem 0 0 0;font-size: 20px; font-size: 2rem; color: #f56b2a;  font-family: "OpenSansBold",sans-serif; }
            .item_imageNumber { position: absolute;  left: 10px;  bottom: 10px; height: 25px; width: 25px;text-align: center;}
            .item_imageNumber span { font-weight: bold;display: block;margin-top: -18px;color: #f56b2a; font-family: "OpenSansBold",sans-serif; }
            .item_title { margin-bottom: 10px;  margin-bottom: 1rem; font-size: 16px; font-size: 1.6rem; font-family: "OpenSansSemiBold",sans-serif; }
            .blue {color: #4183d7;}
            .list_properties {float: right;}
            .selectWrapper { background: #ffffff url(//static.hamza.fr/img/arrow-select.png) no-repeat right; }
            .selectWrapper.blue {  border: 1px solid #4183d7; }

            .selectWrapper.blue .select { padding-right: 35px; padding-right: 3.5rem;color: #4183d7;font-family: "OpenSansSemiBold",sans-serif;}
            .publish-ad {display: block ;
                         height: 41px; font-size: 20px;line-height: 26px;color: #f2f2f2; margin: 0 0 11px; padding: 14px 11px 0 84px; }
            .media{
                width: 100%;
                height: 90px;   
            }
            .img{
                height: 80px;
                width: 120px;
                margin-right: 5px;
            }
            .toto{
                min-width: 200px;
            }
        </style>
        <title>Hamza</title>
        <meta charset="${encoding}">
        <!-- <meta name="viewport" content="width=device-width, initial-scale=1.0">-->

        <script src="<?php echo e(asset('global_assets/js/main/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('global_assets/js/main/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('global_assets/js/plugins/loaders/blockui.min.js')); ?>"></script>
    </head>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>"/>
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">

    <body style="background: #e1e1ea">
        <div id='up_menu' style='height: 360px; width: 100%;  text-align: center; display: inline-block;'>
            <img src="<?php echo e(asset('images/appImages/PUB1.JPG')); ?>" alt="" style="width: 30%; height: 350px">
            <img src="<?php echo e(asset('images/appImages/PUB2.JPG')); ?>" alt="" style="width: 30%; height: 350px">
            <img src="<?php echo e(asset('images/appImages/PUB3.jpg')); ?>" alt="" style="width: 30%; height: 350px">
        </div>
        <div class="container" style="margin-top: 10px">
            <?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <br/>
            <?php echo $__env->make('partials.search_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <hr>
            <div class="row"> 
                <div class="col" style="text-align: center">
                    <h2>  Catégorie</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-sm">
                    <span><a id="" href="#">Téléphones </a> <span class="fs12">(78695)</span></span>
                </div>
                <div class="col-sm">
                    <span><a id="" href="#">Tablettes </a> <span class="fs12">(4471)</span></span>
                </div>
                <div class="col-sm">
                    <span><a id="" href="#">Ordinateurs Portables </a> <span class="fs12">(32417)</span></span>
                </div>
            </div>
            <div class="row">
                <div class="col-sm">
                    <span><a id="" href="#">Ordinateurs De Bureau </a> <span class="fs12">(19001)</span></span>
                </div>
                <div class="col-sm">
                    <span><a id="" href="#">Accessoires Informatique Et Gadgets </a> <span class="fs12">(46071)</span></span>
                </div>
                <div class="col-sm">
                    <span><a id="" href="#">Jeux Vidéo Et Consoles </a> <span class="fs12">(10673)</span></span>
                </div>
            </div>
            <div class="row">
                <div class="col-sm">
                    <span><a id="" href="#">Appareils Photo Et Caméras </a> <span class="fs12">(11974)</span></span>
                </div>
                <div class="col-sm">
                    <span><a id="" href="#">Télévisions </a> <span class="fs12">(4416)</span></span>
                </div>
                <div class="col-sm">
                    <span><a id="" href="#">Image &amp; Son </a> <span class="fs12">(7465)</span></span>
                </div>
            </div>
        </div>
        <div class="container" style="margin-top: 20px">   
            <div class="row">
                <div class="col-8">
                    <div class="list-group" >
                        <div style="display: inline">
                            <div style="float:left"> 
                                <ul class="nav nav-tabs">
                                    <li class="nav-item" >
                                        <a class="nav-link active" href="#" style="color: gray !important; ">Toutes, 22145</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link active" href="#"  style="color: gray !important; ">Particulier, 11112</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#"  style="color: gray !important; ">Professionnel,565659</a>
                                    </li>                       
                                </ul>
                            </div>
                            <div class="selectWrapper blue" style="float: right;margin-top: 10">

                                <select id="listSorting" class="select" onchange="listSortingChange(this); xt_click(this, 'C', '8', 'ad_search::' + this.options[this.selectedIndex].getAttribute('data-value'), 'N');">
                                    <option value="#" data-value="trier_par_date" selected="">Trier par : Date</option>
                                    <option value="#" data-value="trier_par_prix">Trier par : Prix</option>
                                </select>
                            </div>
                        </div>
                        <?php ($i = 0); ?>

                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php (++$i); ?>
                        <?php if($i ===4): ?>
                        <div style="height: 240px;text-align: center">
                            <img src="<?php echo e(asset('images/appImages/PUB4.JPG')); ?>" alt="" style="width: 350px; height: 235px">
                        </div>

                        <?php endif; ?>
                        <div id="li-item-1" class="list-group-item list-group-item-action" style="height: 140px" >  
                            <div class="item_image" style=" margin-right: 10px">
                                <span class="item_imagePic">
                                    <span style="display:block; width:100%; height:100%;" data-imgsrc="<?php echo e(asset('assets/icons/pc.jpg')); ?>" data-imgalt="À SAISIR ! Nouvelle M4 série FROZEN garantie 2020">

                                        <img style="width:100%; height:100%; display: block; background: lightgray;" content="<?php echo e(asset('assets/icons/pc.jpg')); ?>" src="<?php echo e(asset('images/' . $product->id_client.'/' . $product->id.'/'.$product->photo_default)); ?>" alt="À SAISIR ! Nouvelle M4 série FROZEN garantie 2020">

                                    </span>                                                           
                                </span>
                                <span class="item_imageNumber">
                                    <i class="fas fa-camera" style="color: lightblue ;  font-size: 25px;"></i>
                                    <span > <?php echo e($product->nb_photos); ?> </span>
                                </span>  
                                <?php if($product->is_premium > 0): ?>   
                                <span class="badge badge-warning" style="display: block;position: absolute;left: 0px;top: 0px;">PREMIUM</span>
                                <?php endif; ?>
                            </div>

                            <div class="item-info ctext1" style="margin-left: 10px">
                                <div class="ctext3 fs12" >
                                    <h2 class="item_title">
                                        <a href="<?php echo e(url('/offres/affiche/'. $product->id)); ?>" style="color: black"> <?php echo e($product->titre); ?> </a>
                                    </h2> 

                                    <?php if(!is_null($product->ville)): ?>
                                    <span class="item-info-extra fs14">
                                        <small>
                                            <a href="#" style="color: black" ><?php echo e($product->ville->libelle); ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
                                        </small>
                                        <?php if($product->id_marque > 0): ?>
                                        <a href="#" style="color: black; size: " ><?php echo e($product->marque_vehicule->marque); ?>&nbsp;/</a>
                                        
                                        <a href="#" style="color: black" ><?php echo e($product->model_marque_vehicule->model); ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
                                        
                                         <a href="#" style="color: black" ><?php echo e($product->km); ?> Km</a>
                                        <?php endif; ?>
                                        <?php if($product->n_pieces > 0): ?>
                                        <a href="#" style="color: black; size: " >Nombre de pieces: <?php echo e($product->n_pieces); ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/</a>
                                        
                                        <a href="#" style="color: black" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Superficie: <?php echo e($product->superficie); ?> m²</a>
                                        
                                        <?php endif; ?>
                                    </span>
                                    <?php endif; ?>


                                </div>
                                <h3 class="item_price" itemprop="price" content="30">
                                    <?php echo e(number_format($product->price, 0)); ?>&nbsp;DH
                                </h3>
                            </div>   

                            <aside class="item_absolute asideclass" >
                                <p class="item_supp" itemprop="availabilityStarts" content="2018-06-23">                                                                    
                                    <br><?php echo e(date('d/m/y h:m', strtotime($product->created_at))); ?>  
                                </p>                                                            
                            </aside>
                        </div>     
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                    <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-center">

                            <?php echo $products->links();; ?>


                        </ul>
                    </nav>                 
                </div>
                <div class="container col-4 toto" >               
                    <div class="row card" >
                        <h4 class="card-header" style=" background: green; text-align: center">Annonces Premium</h4>                                                                    
                        <div class="card-body">                                                                        
                            <div class="gallery-box">                                                                           
                                <?php $__currentLoopData = $premium_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                                                      
                                <a  href="<?php echo e(url('/offres/affiche/'. $product->id)); ?>" id="gallery-item" style="color: black">                                                                                                                                                                                                                                                               
                                    <div class="media">
                                        <div class="media-left">
                                            <img class="img" src="<?php echo e(asset('images/' . $product->id_client.'/' . $product->id.'/'.$product->photo_default)); ?>">
                                        </div>
                                        <div class="media-right" style="">
                                            <h5><?php echo e($product->titre); ?> </h5>

                                            <h7><?php echo e(number_format($product->price, 0)); ?>&nbsp;<span style="padding-left: 5px;">Dhs</span></h7>
                                        </div>
                                    </div>                                                                                       
                                </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>                                                              
                        </div>                                                            
                    </div>                                                       
                </div>                                                   
            </div>

            <script src="<?php echo e(asset('assets/css/jquery-3.3.1.min.js')); ?>" type="text/javascript"></script>                                                   
            <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>" type="text/javascript"></script>       
            <script src="<?php echo e(asset('js/commands.js')); ?>" type="text/javascript"></script>
            <script src="<?php echo e(asset('js/vue.js')); ?>" ></script>
            <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
            <script>
window.Laravel = <?php echo json_encode([
        'csrfToken' => csrf_token(),
//    'idProduct' => $id_product,
'url' => url('/')
]); ?>

;
            </script>
            <hr>
        </div>

        <div style="width: 100%">
            <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </body>    
</html>