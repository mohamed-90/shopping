<div>
    <div class="form-group row">
        <label  class="col-sm-2" >Type D'annonce:</label>
        <div class="form-check">
            <input class="form-check-input" type="radio"  id="Radios1" value="0"  v-model="product.type_annonce">
            <label class="form-check-label" for="Radios1">Offre    </label>
        </div>
        <div class="form-check">   </div>
        <div class="form-check">
            <input class="form-check-input" type="radio"  id="Radios2" value="1" v-model="product.type_annonce">
            <label class="form-check-label" for="Radios2"> Demande</label>
        </div>                      
        <hr class="input-xxlarge">                        
    </div>
    <div class="form-group row">
        <label for="Secteur" class="col-sm-2" >Secteur:</label>
        <select class="form-control" id="Secteur" style="max-width: 220px; width: 220px;" v-model="product.id_sectuer">
            <option value="0" >Toute la ville</option>
            <option value="1" >-- Sélectionnez secteur --</option>

        </select>                         
    </div>

    <div class="form-group row ">
        <label for="Titre" class="col-sm-2" >Titre: </label>
        <input type="text" name="titre" v-validate="'required'" class="form-control" id="Titre" style="width: 500px" placeholder="Titre" v-model="product.titre" maxlength="100" required>
        <label class="control-label" style="color: red" v-show="errors.has('fortest.titre')">{{ errors.first('fortest.titre')}}</label>  
    </div>

    <div class="form-group row">
        <label for="Texte" class="col-form-label col-sm-2">Texte de l'annonce:</label> 
        <textarea  id="Texte" name="discription" v-validate="'required'" style="width: 500px;" rows="6" cols="3" class="form-control" placeholder="discription" v-model="product.description"></textarea>
        <label class="control-label" style="color: red" v-show="errors.has('fortest.discription')">{{ errors.first('fortest.discription')}}</label>  
        <br>        
    </div>

    <div class="form-group row">
        <label for="exampleFormControlSelect1" class="col-sm-2" >Prix </label>
        <div class="input-group" style="max-width: 220px; width: 220px;">
            <input type="text" name="price" v-validate="'required|numeric'" class="form-control" id="validationDefault05" placeholder="0.00" aria-label="Prix en DH" aria-describedby="btnGroupAddon" v-model="product.price" required>
            <div class="input-group-append">
                <span class="input-group-text" id="basic-addon2">DH</span>
            </div>
            <label class="help is-danger" style="color: red" v-show="errors.has('fortest.price')">{{ errors.first('fortest.price')}}</label>  
        </div>
    </div>
</div>