<div class="form-group row">
    <label for="edtVille" class="col-sm-2" >Ville </label>
    <select class="form-control"  id="edtVille" @change="changeVille()" style="width: 220px"  v-model="product.id_ville">
        <option value="0"> </option>
        <option value="0" selected="">Toutes les villes</option>
        <option style="background-color:#dcdcc3;" value="0" disabled="disabled">-- AUTRES VILLES --</option>
        <option id="searcharea_expanded_fisrt_option" value="4"> Casablanca</option>
        <option value="1"> Agadir</option>
        <option value="2"> Al Hoceïma</option>
        <option value="3"> Béni Mellal</option>
        <option value="5"> El Jadida</option>
        <option value="6"> Errachidia</option>
        <option value="7"> Fès</option>
        <option value="8"> Kénitra</option>
        <option value="9"> Khénifra</option>
        <option value="10"> Khouribga</option>
        <option value="11"> Larache</option>
        <option value="12"> Marrakech</option>
        <option value="13"> Meknès</option>
        <option value="14"> Nador</option>
        <option value="15"> Ouarzazate</option>
        <option value="16"> Oujda</option>
        <option value="17"> Rabat</option>
        <option value="18"> Safi</option>
        <option value="19"> Settat</option>
        <option value="20"> Salé</option>
        <option value="21"> Tanger</option>
        <option value="22"> Taza</option>
        <option value="23"> Tétouan</option>
        <option value="24"> Sebta</option>
        <option value="25"> Melilla</option>
        <option value="26"> Martil/M'diq/Fnideq</option>
        <option value="27"> Chefchaouen</option>
        <option value="0" style="color: red">Choisir une autre ville...</option>
    </select>
</div>
<div class="form-group row">
    <label for="Secteur" class="col-sm-2" >Secteur:</label>
    <select class="form-control" id="Secteur" style="max-width: 220px; width: 220px;" v-model="product.id_secteur">
        <option value="0" >Toute la ville</option>
        <option v-for="secteur in secteurs" v-bind:value="secteur.id" >{{secteur.secteur}}</option>
    </select>  
</div>