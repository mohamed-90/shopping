
<style>

    ._3Vcbh{padding:10px;padding:0px;margin-top:5px;margin-top:5px;-webkit-border-radius:4px;border-radius:4px;-webkit-border-radius:.4rem;border-radius:.4rem;border:1px solid #ccc;background:#fff;position:absolute;z-index:10000;left:0;right:0}
    ._3Vcbh>div{width:20%;display:inline-block;vertical-align:top}
    ._3Vcbh>div:not(:first-child){padding-left:5px;padding-left:5px}
    ._3Vcbh>div>ul:not(:first-child){margin-top:1rem}
    ._3Vcbh>div>ul li{cursor:pointer}
    ._3Vcbh>div>ul li._1_1B4{height:30px;line-height:30px;margin-bottom:5px;text-transform:uppercase;text-align:center;background:#f2f2f2;font-family:OpenSansSemiBold,sans-serif;font-weight:600;font-size:14px;padding:0.1px;color:#369;-webkit-transition:all .3s;transition:all .3s;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}
    ._3Vcbh>div>ul li._1_1B4:hover{color:#3873bd}
    ._3Vcbh>div>ul li._11G4C{color:#f56b2a!important}    
    ._3Vcbh>div>ul li:hover{text-decoration:underline;outline:none}
    ._3Vcbh>div>ul li.tT3Ya,._3Vcbh>div>ul li.tT3Ya a,._3Vcbh>div>ul li.tT3Ya a:hover,._3Vcbh>div>ul li.tT3Ya a:visited{color:#369}
    ._3Vcbh>div>ul li.tT3Ya sup{color:#f56b2a}
    ._3Vcbh>div>ul li.tT3Ya sup:before{content:" "}
    @media (max-width:971px){.SiZLq>._3X-Yv{display:none}  }
    .tT3Ya {color: #369;}
    ._26tGy { position: absolute; right: 1rem; top: 5px;    }
    ._26tGy, ._26tGy span {line-height: 20px;    } 

    .SiZLq{position:relative}
    .SiZLq>._1CJVw.egIn7{position:relative;z-index:1;opacity:0}
    .SiZLq>._1CJVw.egIn7:focus+._3X-Yv{outline:1px solid #f56b2a}
    .SiZLq>._1CJVw option._1_1B4{text-transform:uppercase;background:#dcdcc3}
    .SiZLq>._1CJVw option[disabled]{background:#e6e6e6}
    .SiZLq ._1CJVw.egIn7{opacity:1}
    ._1etKl{position:relative;width:100%;height:38px;background:#fff;border:1px solid #ccc;border-radius:.4rem}


    ._2gTTZ{position:absolute;width:100%;height:100%;z-index:1}
    ._2gTTZ>div,._2gTTZ>select{font-size:16px;width:100%;height:100%;padding:10px;border:none;background:transparent;outline:none;-webkit-appearance:none;-moz-appearance:none;cursor:pointer}
    ._2gTTZ>div{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-align:center;-webkit-align-items:center;-ms-flex-align:center;align-items:center}

    li {display: list-item;text-align: -webkit-match-parent;   list-style: none  }
    ol, ul {margin: 0;padding: 0;list-style-type: none; list-style: none   }
    ul, menu, dir {display: block;       list-style-type: disc;       margin-block-start: 1em;margin-block-end: 1em;margin-inline-start: 0px;margin-inline-end: 0px;padding-inline-start: 10px;    }
    ._3X-Yv{position:absolute;top:0;left:0;right:0;z-index:1}
    ._2jG3V svg {width: 12px;height: 12px;  }
    ._1vK7W {  display: inline-block;}
</style>


<div class="row" style="font-size: 16px; background: orange">
    <div class="col col-12 col-sm-12  col-md-3 col-lg-4">
        <input class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="q" value=""  size="20" id="searchtext" type="text" placeholder="Que recherchez-vous ?">
    </div>
    <!--col col-12 col-sm-12 col-md-3 col-lg-3.5-->
    <div class="col col-12 col-sm-12  col-md-3 col-lg-4">
        <div data-reactid="82">
            <div class="SiZLq">
                <div class="_1CJVw egIn7" data-qa-id="select-toggle_category">
                    <div class="_1etKl">

                        <div class="_26tGy">
                            <span class="_1vK7W _2jG3V" name="menuDown">
                                <svg height="32" width="32" viewBox="0 0 32 32">  
                                <path d="M0 8l16 16L32 8H0z" fill="#000">
                                </path>
                                </svg>
                            </span>
                        </div><!--  class="_2gTTZ"-->

                        <div >
                            <select id="_selector" autocomplete="off">
                                <option  value="0">Toutes les catégories</option>

                                <option class="_1_1B4" value="2000">-- VEHICULES --</option>
                                <option class="tT3Ya" value="2010">Voitures</option>
                                <option class="tT3Ya" value="2030">Motos</option>
                                <option class="tT3Ya" value="2060">Vélos</option>
                                <option class="tT3Ya" value="2070">Véhicules Professionnels</option>
                                <option class="tT3Ya" value="2050">Nautisme</option>
                                <option class="tT3Ya" value="2040">Equipements et pièces pour véhicules</option>
                                <option class="tT3Ya" value="2040">Equipements et pièces pour moto</option>
                                <option class="tT3Ya" value="2040">Equipements et pièces nautisme</option>

                                <option class="_1_1B4" value="1000">-- IMMOBILIER --</option>
                                <option class="tT3Ya" value="1010">Appartements</option>
                                <option class="tT3Ya" value="1020">Maisons et Villas</option>
                                <option class="tT3Ya" value="1050">Bureaux et Plateaux</option>
                                <option class="tT3Ya" value="1060">Magasins, Commerces et Locaux industriels</option>
                                <option class="tT3Ya" value="1080">Terrains et Fermes</option>
                                <option class="tT3Ya" value="1090">Autre Immobilier</option>

                                <option class="_1_1B4" value="9000">-- VACANCES --</option>
                                <option class="tT3Ya" value="6100">Location et gites</option>
                                <option class="tT3Ya" value="6090">Chambres d'hôtes</option>
                                <option class="tT3Ya" value="6120">Hôtels</option>
                                <option class="_1_1B4" value="7000">Voyages organisés (services)</option>

                                <option class="_1_1B4" value="3000">-- POUR LA MAISON ET JARDIN --</option>
                                <option class="tT3Ya" value="3020">Ameublement et Décoration</option>
                                <option class="tT3Ya" value="3010">Electroménager et Vaisselles</option>
                                <option class="tT3Ya" value="3040">Jardin et Outils de bricolage</option>

                                <option class="_1_1B4" value="8000">-- HABILLEMENT ET BIEN ETRE --</option>
                                <option class="tT3Ya" value="3050">Vêtements</option>
                                <option class="tT3Ya" value="3150">Chaussures</option>
                                <option class="tT3Ya" value="3160">Montres et Bijoux</option>
                                <option class="tT3Ya" value="3060">Sacs et Accessoires</option>
                                <option class="tT3Ya" value="3030">Vêtements pour enfant et bébé</option>
                                <option class="tT3Ya" value="3070">Produits de beauté</option>

                                <option class="_1_1B4" value="5000">-- INFORMATIQUE ET MULTIMEDIA --</option>
                                <option  class="tT3Ya" value="5010">Téléphones</option>
                                <option class="tT3Ya" value="5080">Tablettes</option>
                                <option class="tT3Ya" value="5030">Ordinateurs portables</option>
                                <option class="tT3Ya" value="5050">Ordinateurs de bureau</option>
                                <option class="tT3Ya" value="5060">Accessoires informatique et Gadgets</option>
                                <option class="tT3Ya" value="5040">Jeux vidéo et Consoles</option>
                                <option class="tT3Ya" value="5070">Appareils photo et Caméras</option>
                                <option class="tT3Ya" value="5090">Télévisions</option>
                                <option class="tT3Ya" value="5020">Image &amp; Son</option>

                                <option class="_1_1B4" value="4000">-- LOISIRS --</option>
                                <option class="tT3Ya" value="4030">Animaux</option>
                                <option class="tT3Ya" value="4010">Sports et Loisirs</option>
                                <option class="tT3Ya" value="4060">Art et Collections</option>
                                <option class="tT3Ya" value="4070">Instruments de Musique</option>
                                <option class="tT3Ya" value="4060">Jeux video et consoles</option>
                                <option class="tT3Ya" value="4050">Image et son</option>
                                <option class="tT3Ya" value="4040">Films, Livres, Magazines</option>

                                <option class="_1_1B4" value="6000">-- EMPLOI ET SERVICES --</option>
                                <option class="tT3Ya" value="6010">Offres d'emploi</option>
                                <option class="tT3Ya" value="6020">Demandes d'emploi</option>
                                <option class="tT3Ya" value="6130">Stages</option>

                                <option class="_1_1B4" value="9000">-- ENTREPRISES --</option>
                                <option class="tT3Ya" value="6100">Business et Affaires commerciales</option>
                                <option class="tT3Ya" value="6090">Matériels Professionnels</option>
                                <option class="tT3Ya" value="6120">Stocks et Vente en gros</option>

                                <option class="_1_1B4" value="6000">-- SERVICES --</option>
                                <option class="tT3Ya" value="6010">Prestations de services</option>
                                <option class="tT3Ya" value="6020">Billetterie</option>
                                <option class="tT3Ya" value="6130">Evenements et traiteurs</option>
                                <option class="tT3Ya" value="6130">Cours particuliers</option>
                                <option class="tT3Ya" value="6130">Covoiturage</option>
                                <option class="tT3Ya" value="6130">Location voiture</option>
                                <option class="_1_1B4" value="7000">-- Autres --</option>option
                                <option class="tT3Ya" value="7010">AUTRES</option>

                            </select>
                        </div>
                    </div>
                </div>

                <div class="_3X-Yv" >
                    <div class=" _1etKl" data-qa-id="select-toggle_category">
                        <div class="_26tGy">
                            <span class="_1vK7W _2jG3V" name="menuDown">
                                <svg height="32" width="32" viewBox="0 0 32 32"><path d="M0 8l16 16L32 8H0z" fill="#000"></path></svg>
                            </span>
                        </div>
                        <div  class="_2gTTZ">
                            <div id="comboType">Toutes catégories</div>    
                        </div>    
                    </div>
                </div>
            </div>
        </div>   
    </div>


    <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
        <label class="form-check-label" for="defaultCheck1">
            Avec photos
        </label>
    </div>
    <div style="width: 100px; float: right"><!--class="col-12 col-md-auto"-->
        <button type="button" class="btn btn-primary" style="width: 100px">Rechercher</button>
    </div>


</div>
<div class="row _selector" style="position:relative">     
    <div class="_3Vcbh" style="display: flex; flex-direction: row;  box-sizing: inherit;  ">
        <div>
            <ul>
                <li class="_11G4C _1_1B4"><a>Toutes catégories</a></li>
            </ul>
            <ul>
                <li data-qa-id="2000" class="_1_1B4">VEHICULES</li>
                <li data-qa-id="2010" class="tT3Ya">Voitures</li>
                <li data-qa-id="2030" class="tT3Ya">Motos</li>
                <li data-qa-id="2060" class="tT3Ya">Vélos</li>
                <li data-qa-id="2070" class="tT3Ya">Véhicules Professionnels</li>
                <li data-qa-id="2050" class="tT3Ya">Nautisme</li>
                <li data-qa-id="2040" class="tT3Ya">Equipements et pièces pour véhicules</li>
                <li data-qa-id="2040" class="tT3Ya">Equipements et pièces pour moto</li>
                <li data-qa-id="2040" class="tT3Ya">Equipements et pièces nautism</li>
            </ul>
            <ul>
                <li data-qa-id="categorylist_cat_8" class="_1_1B4">IMMOBILIER</li>
                <li data-qa-id="categorylist_cat_9" class="tT3Ya">Ventes immobilières</li>
                <li class="tT3Ya"><a href="https://immobilierneuf.leboncoin.fr">Immobilier Neuf</a><sup>nouveau</sup></li>
                <li data-qa-id="categorylist_cat_10" class="tT3Ya">Locations</li>
                <li data-qa-id="categorylist_cat_11" class="tT3Ya">Colocations</li>
                <li data-qa-id="categorylist_cat_13" class="tT3Ya">Bureaux &amp; Commerces</li>
            </ul>


        </div>
        <div>

            <ul>
                <li data-qa-id="categorylist_cat_66" class="_1_1B4">VACANCES</li>
                <li data-qa-id="categorylist_cat_12" class="tT3Ya">Locations &amp; Gîtes</li>
                <li data-qa-id="categorylist_cat_67" class="tT3Ya">Chambres d'hôtes</li>
                <li data-qa-id="categorylist_cat_68" class="tT3Ya">Campings</li>
                <li data-qa-id="categorylist_cat_69" class="tT3Ya">Hôtels</li>
                <li data-qa-id="categorylist_cat_70" class="tT3Ya">Hébergements insolites</li>
            </ul>
            <ul>
                <li data-qa-id="categorylist_cat_18" class="_1_1B4">MAISON</li>
                <li data-qa-id="categorylist_cat_19" class="tT3Ya">Ameublement</li>
                <li data-qa-id="categorylist_cat_20" class="tT3Ya">Electroménager</li>
                <li data-qa-id="categorylist_cat_45" class="tT3Ya">Arts de la table</li>
                <li data-qa-id="categorylist_cat_39" class="tT3Ya">Décoration</li>
                <li data-qa-id="categorylist_cat_46" class="tT3Ya">Linge de maison</li>
                <li data-qa-id="categorylist_cat_21" class="tT3Ya">Bricolage</li>
                <li data-qa-id="categorylist_cat_52" class="tT3Ya">Jardinage</li>
                <li data-qa-id="categorylist_cat_22" class="tT3Ya">Vêtements</li>
                <li data-qa-id="categorylist_cat_53" class="tT3Ya">Chaussures</li>
                <li data-qa-id="categorylist_cat_47" class="tT3Ya">Accessoires &amp; Bagagerie</li>
                <li data-qa-id="categorylist_cat_42" class="tT3Ya">Montres &amp; Bijoux</li>
                <li data-qa-id="categorylist_cat_23" class="tT3Ya">Equipement bébé</li>
                <li data-qa-id="categorylist_cat_54" class="tT3Ya">Vêtements bébé</li>
            </ul>
        </div>
        <div>
            <ul>
                <li data-qa-id="categorylist_cat_14" class="_1_1B4">MULTIMEDIA</li>
                <li data-qa-id="categorylist_cat_15" class="tT3Ya">Informatique</li>
                <li data-qa-id="categorylist_cat_43" class="tT3Ya">Consoles &amp; Jeux vidéo</li>
                <li data-qa-id="categorylist_cat_16" class="tT3Ya">Image &amp; Son</li>
                <li data-qa-id="categorylist_cat_17" class="tT3Ya">Téléphonie</li>
            </ul>
            <ul>
                <li data-qa-id="categorylist_cat_56" class="_1_1B4">MATERIEL PROFESSIONNEL</li>
                <li data-qa-id="categorylist_cat_57" class="tT3Ya">Matériel Agricole</li>
                <li data-qa-id="categorylist_cat_58" class="tT3Ya">Transport - Manutention</li>
                <li data-qa-id="categorylist_cat_59" class="tT3Ya">BTP - Chantier Gros-oeuvre</li>
                <li data-qa-id="categorylist_cat_60" class="tT3Ya">Outillage - Matériaux 2nd-oeuvre</li>
                <li data-qa-id="categorylist_cat_32" class="tT3Ya">Équipements Industriels</li>
                <li data-qa-id="categorylist_cat_61" class="tT3Ya">Restauration - Hôtellerie</li>
                <li data-qa-id="categorylist_cat_62" class="tT3Ya">Fournitures de Bureau</li>
                <li data-qa-id="categorylist_cat_63" class="tT3Ya">Commerces &amp; Marchés</li>
                <li data-qa-id="categorylist_cat_64" class="tT3Ya">Matériel Médical</li>
            </ul>
        </div>
        <div>

            <ul>
                <li data-qa-id="categorylist_cat_24" class="_1_1B4">LOISIRS</li>
                <li data-qa-id="categorylist_cat_25" class="tT3Ya">DVD / Films</li>
                <li data-qa-id="categorylist_cat_26" class="tT3Ya">CD / Musique</li>
                <li data-qa-id="categorylist_cat_27" class="tT3Ya">Livres</li>
                <li data-qa-id="categorylist_cat_28" class="tT3Ya">Animaux</li>
                <li data-qa-id="categorylist_cat_55" class="tT3Ya">Vélos</li>
                <li data-qa-id="categorylist_cat_29" class="tT3Ya">Sports &amp; Hobbies</li>
                <li data-qa-id="categorylist_cat_30" class="tT3Ya">Instruments de musique</li>
                <li data-qa-id="categorylist_cat_40" class="tT3Ya">Collection</li>
                <li data-qa-id="categorylist_cat_41" class="tT3Ya">Jeux &amp; Jouets</li>
                <li data-qa-id="categorylist_cat_48" class="tT3Ya">Vins &amp; Gastronomie</li>
            </ul>
        </div>
        <div>
            <ul>
                <li data-qa-id="categorylist_cat_71" class="_1_1B4">EMPLOI</li>
                <li data-qa-id="categorylist_cat_33" class="tT3Ya">Offres d'emploi</li>
                <li class="tT3Ya"><a href="https://go.onelink.me/3471221858/bcf737d8">Offres d'emploi Cadres</a><sup>nouveau</sup></li>
            </ul>
            <ul>
                <li data-qa-id="categorylist_cat_31" class="_1_1B4">SERVICES</li>
                <li data-qa-id="categorylist_cat_34" class="tT3Ya">Prestations de services</li>
                <li data-qa-id="categorylist_cat_35" class="tT3Ya">Billetterie</li>
                <li data-qa-id="categorylist_cat_49" class="tT3Ya">Evénements</li>
                <li data-qa-id="categorylist_cat_36" class="tT3Ya">Cours particuliers</li>
                <li data-qa-id="categorylist_cat_65" class="tT3Ya">Covoiturage</li>
            </ul>
            <ul>
                <li data-qa-id="categorylist_cat_37" class="_1_1B4">AUTRES</li>
                <li data-qa-id="categorylist_cat_38" class="tT3Ya">Autres</li>
            </ul>
        </div>
    </div>
</div>


