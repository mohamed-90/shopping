<html>
    <head>                
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <style type="text/css">

            .asideclass{ position :absolute;   bottom: 0; right: 0;            }
            .item_image, .oas-nativ-ads .oas-link .oas-nativ-ad .oas-product-picture {  min-width: 100px;min-height: 90px;}
            .item_image, .oas-nativ-ads .oas-link .oas-nativ-ad .oas-product-picture {    position: relative;overflow: hidden;float: left;width: 25%;   min-width: 130px; min-height: 120px;max-height: 100%;background: #f2f2f2;  }
            .item_imagePic {  display: block;   height: 100%;min-height: 120px;   text-align: center;   line-height: 120px;        }
            .item_price {  margin: 10px 0 0 0;  margin: 1rem 0 0 0;font-size: 20px; font-size: 2rem; color: #f56b2a;  font-family: "OpenSansBold",sans-serif; }
            .item_imageNumber { position: absolute;  left: 10px;  bottom: 10px; height: 25px; width: 25px;text-align: center;}
            .item_imageNumber span { font-weight: bold;display: block;margin-top: -18px;color: #f56b2a; font-family: "OpenSansBold",sans-serif; }
            .item_title, .oas-nativ-ads .oas-link .oas-nativ-ad .detail .oas-product-title { margin-bottom: 10px;  margin-bottom: 1rem; font-size: 16px; font-size: 1.6rem; font-family: "OpenSansSemiBold",sans-serif; }
            .blue {color: #4183d7;}
            .list_properties {float: right;}
            .selectWrapper { background: #ffffff url(//static.hamza.fr/img/arrow-select.png) no-repeat right; }
            .selectWrapper.blue {
                border: 1px solid #4183d7;
            }
            .selectWrapper.blue .select { padding-right: 35px; padding-right: 3.5rem;color: #4183d7;font-family: "OpenSansSemiBold",sans-serif;}
            .publish-ad {display: block;   background: url(<?php echo e(url('assets/icons/upload-button.png')); ?>) no-repeat;
            height: 41px; font-size: 20px;line-height: 26px;color: #f2f2f2; margin: 0 0 11px; padding: 14px 11px 0 84px; }
        </style>
        <title>Hamza</title>
        <meta charset="${encoding}">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

               <script src="<?php echo e(asset('global_assets/js/main/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('global_assets/js/main/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('global_assets/js/plugins/loaders/blockui.min.js')); ?>"></script>
    </head>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>"/>
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
 
    <body>
        <div class="container" style="margin-top: 10px">
             <?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
             <br/>
            include('partials.search_product')

            <div class="row"> 
                <div class="col" style="text-align: center">
                    <h2>  Catégorie</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-sm">
                    <span><a id="" href="https://www.hamza.ma/fr/maroc/téléphones-à_vendre">Téléphones </a> <span class="fs12">(78695)</span></span>
                </div>
                <div class="col-sm">
                    <span><a id="" href="https://www.hamza.ma/fr/maroc/tablettes-à_vendre">Tablettes </a> <span class="fs12">(4471)</span></span>
                </div>
                <div class="col-sm">
                    <span><a id="" href="https://www.hamza.ma/fr/maroc/ordinateurs_portables-à_vendre">Ordinateurs Portables </a> <span class="fs12">(32417)</span></span>
                </div>
            </div>
            <div class="row">
                <div class="col-sm">
                    <span><a id="" href="https://www.hamza.ma/fr/maroc/ordinateurs_bureau-à_vendre">Ordinateurs De Bureau </a> <span class="fs12">(19001)</span></span>
                </div>
                <div class="col-sm">
                    <span><a id="" href="https://www.hamza.ma/fr/maroc/accessoires_informatique_et_gadgets-à_vendre">Accessoires Informatique Et Gadgets </a> <span class="fs12">(46071)</span></span>
                </div>
                <div class="col-sm">
                    <span><a id="" href="https://www.hamza.ma/fr/maroc/jeux_vidéo_et_consoles-à_vendre">Jeux Vidéo Et Consoles </a> <span class="fs12">(10673)</span></span>
                </div>
            </div>
            <div class="row">
                <div class="col-sm">
                    <span><a id="" href="https://www.hamza.ma/fr/maroc/appareils_photo_cameras-à_vendre">Appareils Photo Et Caméras </a> <span class="fs12">(11974)</span></span>
                </div>
                <div class="col-sm">
                    <span><a id="" href="https://www.hamza.ma/fr/maroc/télévisions-à_vendre">Télévisions </a> <span class="fs12">(4416)</span></span>
                </div>
                <div class="col-sm">
                    <span><a id="" href="https://www.hamza.ma/fr/maroc/image_et_son-à_vendre">Image &amp; Son </a> <span class="fs12">(7465)</span></span>
                </div>
            </div>

        </div>

        <div class="container" style="margin-top: 20px">   
            <div class="row">
                <div class="col-8">
                    <div class="list-group" >
                        <div style="display: inline">
                            <div style="float:left"> 
                                <ul class="nav nav-tabs">
                                    <li class="nav-item" >
                                        <a class="nav-link active" href="#" style="color: gray !important; ">Toutes, 22145</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link active" href="#"  style="color: gray !important; ">Particulier, 11112</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#"  style="color: gray !important; ">Professionnel,565659</a>
                                    </li>                       
                                </ul>
                            </div>

                            <div class="selectWrapper blue" style="float: right;margin-top: 10">

                                <select id="listSorting" class="select" onchange="listSortingChange(this); xt_click(this, 'C', '8', 'ad_search::' + this.options[this.selectedIndex].getAttribute('data-value'), 'N');">
                                    <option value="//www.hamza.fr/annonces/offres/picardie/?sp=0" data-value="trier_par_date" selected="">Trier par : Date</option>
                                    <option value="//www.hamza.fr/annonces/offres/picardie/?sp=1" data-value="trier_par_prix">Trier par : Prix</option>
                                </select>
                            </div>
                        </div>
                        <?php ($i = 0); ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php (++$i); ?>
                        <?php if($i ===4): ?>
                        <div style="height: 240px; background: lightblue;text-align: center">
                            <p>            <h5>Publicité</h5>                </p>
                        </div>

                        <?php endif; ?>
                        <div id="li-item-1" class="list-group-item list-group-item-action" style="height: 140px" >  
                            <div class="item_image">
                                <span class="item_imagePic">
                                    <span style="display:block; width:100%; height:100%;" data-imgsrc="<?php echo e(asset('assets/icons/pc.jpg')); ?>" data-imgalt="À SAISIR ! Nouvelle M4 série FROZEN garantie 2020">

                                        <img style="display: block; background: lightgray" content="<?php echo e(asset('assets/icons/pc.jpg')); ?>" src="<?php echo e(asset('assets/icons/pc.jpg')); ?>" alt="À SAISIR ! Nouvelle M4 série FROZEN garantie 2020">

                                    </span>                                                           
                                </span>
                                <span class="item_imageNumber">
                                    <i class="fas fa-camera" style="color: lightblue ;  font-size: 25px;"></i>
                                    <span >3</span>
                                </span>  
                                <?php if($product->is_premium ===1): ?>   
                                <span class="badge badge-warning" style="display: block;position: absolute;left: 0px;top: 0px;">PREMIUM</span>
                                <?php endif; ?>
                            </div>
                           
                            <div class="item-info ctext1" style="margin-left: 10px">
                                <div class="ctext3 fs12" >
                                    <h2 class="item_title">
                                        <a href="https://www.hamza.ma/fr/casablanca/téléphones/SAMSUNG_J2__D_Ori___8G_28921550.htm"> <?php echo e($product->reference); ?> </a>
                                    </h2>                       
                                    <?php if(!is_null($product->ville)): ?>
                                    <span class="item-info-extra fs14">
                                        <small>

                                            <a href="<?php echo e(url('offres/ville/'.$product->ville->libelle)); ?>" ><?php echo e($product->ville->libelle); ?></a>
                                        </small>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                <h3 class="item_price" itemprop="price" content="30">
                                    <?php echo e(number_format($product->price, 0)); ?>&nbsp;DH
                                </h3>
                            </div>   

                            <aside class="item_absolute asideclass" >
                                <p class="item_supp" itemprop="availabilityStarts" content="2018-06-23">                                                                    
                                    <strong>Aujourd'hui,</strong><br><?php echo e(date('h:m', strtotime($product->date_add))); ?>  
                                </p>                                                            
                            </aside>
                        </div>     
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-center">
                            <li class="page-item disabled">
                                <a class="page-link" href="#" aria-label="Précédent" >
                                    <span aria-hidden="true">&laquo;</span>
                                    <span class="sr-only">Précédent</span>
                                </a>
                            </li>
                            <li class="page-item"><a class="page-link" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo e(url('paginate_next')); ?>" aria-label="Suivant">
                                    <span aria-hidden="true">&raquo;</span>
                                    <span class="sr-only">Suivant</span>
                                </a>
                            </li>
                        </ul>
                    </nav>                 
                </div>
                <div class="container col-4" style="background: green">
                    <div class="row">
                        <a href="<?php echo e(url('/offres/add')); ?>">
                            <div class="publish-ad">Publiez votre annonce</div>
                        </a>    
                    </div>
                    <div class="row card">
                        <h5 class="card-header">Annonces Premium</h5>                                                                    
                        <div class="card-body">                                                                        
                            <div class="gallery-box">                                                                           
                                <?php $__currentLoopData = $premium_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                                                      
                                <a href="https://hamza.ma/vi/30589234.htm" id="gallery-item">                                                                     
                                    <img alt="<?php echo e($product->reference); ?>" class="gallery-item-img" src="<?php echo e(asset('assets/icons/pc.jpg')); ?>" >                                                                  
                                    <p class="gallery-item-title truncate"><?php echo e($product->reference); ?>  <?php echo e($product->ville->libelle); ?> </p>                                                               
                                    <p class="gallery-item-location"></p>                                                              
                                    <p class="gallery-item-price"><?php echo e(number_format($product->price, 0)); ?>&nbsp;000<span style="padding-left: 5px;">Dhs</span></p>                                                               
                                </a>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>                                                              
                        </div>                                                            
                    </div>                                                       
                </div>                                                   
            </div>

            <script src="<?php echo e(asset('assets/css/jquery-3.3.1.min.js')); ?>" type="text/javascript"></script>                                                   
            <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>" type="text/javascript"></script>       
            
            
        </body>                                         
</html>