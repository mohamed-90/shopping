<div style="">
</script>
<style>
    .container{
        margin-top:20px;
        width:100%
    }
    .image-preview-input {
        position: relative;
        overflow: hidden;
        margin: 0px;    
        color: #333;
        background-color: #fff;
        border-color: #ccc;    
    }
    .image-preview-input input[type=file] {
        position: absolute;
        top: 0;
        right: 0;
        margin: 0;
        padding: 0;
        font-size: 20px;
        cursor: pointer;
        opacity: 0;
        filter: alpha(opacity=0);
    }
    .image-preview-input-title {
        margin-left:2px;
    }
</style>
<div  class="container">
    <hr>
    <button type="button" class="btn btn-success choose_file" onclick="addImage()">Ajouter les photos</button>
    <hr>
    <form method="post" action="<?php echo e(url('/my_annonce')); ?>" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <table>
            <tr>
                <td >
                    <div class="panel panel-default" style='display: none' id="img_1">
                        <div class="panel-body">
                            <div class="form-group">
                                <div class="">
                                    <div class="fileupload fileupload-new" data-provides="fileupload">
                                        <div class="fileupload-preview thumbnail" style="width: 200px; height: 150px;"></div>
                                        <div>
                                            <span class="btn btn-file btn-success"><span class="fileupload-new">Select image</span><span class="fileupload-exists">Change</span><input id="btn_1" type="file" name="file_1"></span>
                                            <a href="#" class="btn btn-danger fileupload-exists" data-dismiss="fileupload">Remove</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
                <td >
                    <div class="panel panel-default" style='display: none' id="img_2">
                        <div class="panel-body">
                            <div class="form-group">
                                <div class="">
                                    <div class="fileupload fileupload-new" data-provides="fileupload">
                                        <div class="fileupload-preview thumbnail" style="width: 200px; height: 150px;"></div>
                                        <div>
                                            <span class="btn btn-file btn-success" ><span class="fileupload-new">Select image</span><span class="fileupload-exists">Change</span><input id="btn_2" type="file" name="file_2"></span>
                                            <a href="#" class="btn btn-danger fileupload-exists" data-dismiss="fileupload">Remove</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="panel panel-default"  style='display: none' id="img_3">
                        <div class="panel-body">
                            <div class="form-group">
                                <div class="">
                                    <div class="fileupload fileupload-new" data-provides="fileupload">
                                        <div class="fileupload-preview thumbnail" style="width: 200px; height: 150px;"></div>
                                        <div>
                                            <span class="btn btn-file btn-success"><span class="fileupload-new">Select image</span><span class="fileupload-exists">Change</span><input  id="btn_3" type="file" name="file_3"></span>
                                            <a href="#" class="btn btn-danger fileupload-exists" data-dismiss="fileupload">Remove</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
                <td >
                    <div class="panel panel-default" style='display: none' id="img_4">
                        <div class="panel-body">
                            <div class="form-group">
                                <div class="">
                                    <div class="fileupload fileupload-new" data-provides="fileupload">
                                        <div class="fileupload-preview thumbnail" style="width: 200px; height: 150px;"></div>
                                        <div>
                                            <span class="btn btn-file btn-success" ><span class="fileupload-new">Select image</span><span class="fileupload-exists">Change</span><input id="btn_4" type="file" name="file_4"></span>
                                            <a href="#" class="btn btn-danger fileupload-exists" data-dismiss="fileupload">Remove</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
                <td >
                    <div class="panel panel-default" style='display: none' id="img_5">
                        <div class="panel-body">
                            <div class="form-group">
                                <div class="">
                                    <div class="fileupload fileupload-new" data-provides="fileupload">
                                        <div class="fileupload-preview thumbnail" style="width: 200px; height: 150px;"></div>
                                        <div>
                                            <span class="btn btn-file btn-success" ><span class="fileupload-new">Select image</span><span class="fileupload-exists">Change</span><input id="btn_5" type="file" name="file_5"></span>
                                            <a href="#" class="btn btn-danger fileupload-exists" data-dismiss="fileupload">Remove</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
            </tr>
        </table>
        <input type="submit" id="up_file" class="" value="add image" style='display: none'>
    </form>
    <script>
        function addImage()
        {
            var img_1 = document.getElementById("img_1");
            var img_2 = document.getElementById("img_2");
            var img_3 = document.getElementById("img_3");
            var img_4 = document.getElementById("img_4");
            var img_5 = document.getElementById("img_5");

            var btn_1 = document.getElementById("btn_1");
            var btn_2 = document.getElementById("btn_2");
            var btn_3 = document.getElementById("btn_3");
            var btn_4 = document.getElementById("btn_4");
            var btn_5 = document.getElementById("btn_5");

            if (img_1.style.display === "none")
            {
                img_1.style.display = "block";
                btn_1.click();
            } else
            {
                if (img_2.style.display === "none")
                {
                    img_2.style.display = "block";
                    btn_2.click();
                } else
                {
                    if (img_3.style.display === "none")
                    {
                        img_3.style.display = "block";
                        btn_3.click();
                    } else
                    {
                        if (img_4.style.display === "none")
                        {
                            img_4.style.display = "block";
                            btn_4.click();
                        } else
                        {
                            if (img_5.style.display === "none")
                            {
                                img_5.style.display = "block";
                                btn_5.click();
                            }
                        }
                    }
                }
            }
        }
    </script>
    <hr>
    <br />

    <script src="<?php echo e(asset('assets/js/jquery-1.10.2.js')); ?>"></script>
  
    <script src="<?php echo e(asset('assets/js/bootstrap-fileupload.js')); ?>"></script>
    
    <script src="<?php echo e(asset('assets/js/jquery.metisMenu.js')); ?>"></script>
 
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
</div>
</div>