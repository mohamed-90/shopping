<html>
    <head>
        <title>annonce</title>
        <meta charset="${encoding}">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </head>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>"/>

    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <body>
       
        <div class="container" id="app">
                        <?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                   <?php echo e(csrf_field()); ?>

           

            <br>
            <div class="d-flex justify-content-center">
                <h3>Liste des offres</h3>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <table class="table">
                        <thead>
                        <th>#</th>
                        <th>Title</th>
                        <th>description</th>
                        <th>prix</th>
                        <th>Created At</th>
                        <th></th>
                        </thead>

                        <tbody>

                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <th><?php echo e($product->id_product); ?></th>
                                <td><?php echo e($product->titre); ?></td>
                                <td><?php echo e(substr($product->description, 0, 50)); ?><?php echo e(strlen($product->description) > 50 ? "..." : ""); ?></td>
                                <td>(<?php echo e(number_format($product->price, 0)); ?> HT)</td>
                                <td><?php echo e(date('M j, Y', strtotime($product->created_at))); ?></td>
                                <td><a href="#" class="btn btn-default btn-sm">View</a> <a href="#" class="btn btn-default btn-sm">Edit</a><a href="#" class="btn btn-default btn-sm">Delit</a></td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
            <hr>
            <div class="d-flex justify-content-center"><?php echo $products->links();; ?></div>
            <hr>
            <div class="row" style="background: rosybrown; height: 100px">

            </div>
        </div>

        <script src="<?php echo e(asset('assets/css/jquery-3.3.1.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
        <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </body>

    <script src="<?php echo e(asset('js/vue.js')); ?>" ></script>
    <script src="<?php echo e(asset('js/veeValidate.js')); ?>" ></script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>

    <script>

Vue.use(VeeValidate);

window.Laravel = <?php echo json_encode([
        'csrfToken' => csrf_token(),
//    'idProduct' => $id_product,
'url' => url('/')
]); ?>

;
    </script>
    <script src="<?php echo e(asset('js/index.js')); ?>"></script>


</html>   
