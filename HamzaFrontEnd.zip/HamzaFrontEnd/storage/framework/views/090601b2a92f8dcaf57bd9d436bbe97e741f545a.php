<html>
    <head>
        <style type="text/css">

            .asideclass{
                position :absolute;
                bottom: 0;
                right: 0;
            }
            .item_imagePic {
                min-height: 90px;
                line-height: 90px;
            }

            .item_image, .oas-nativ-ads .oas-link .oas-nativ-ad .oas-product-picture {
                min-width: 100px;
                min-height: 90px;
            }
            .item_image, .oas-nativ-ads .oas-link .oas-nativ-ad .oas-product-picture {
                position: relative;
                overflow: hidden;
                float: left;
                width: 25%;
                min-width: 130px;
                min-height: 120px;
                max-height: 100%;
                background: #f2f2f2;
            }
            .item_imagePic {
                display: block;
                height: 100%;
                min-height: 120px;
                text-align: center;
                line-height: 120px;
            }
            .item_price {
                margin: 10px 0 0 0;
                margin: 1rem 0 0 0;
                font-size: 20px;
                font-size: 2rem;
                color: #f56b2a;
                font-family: "OpenSansBold",sans-serif;
            }
            .item_imageNumber {
                position: absolute;
                left: 10px;
                bottom: 10px;
                height: 25px;
                width: 25px;
                text-align: center;
            }
            .item_imageNumber span {
                display: block;
                margin-top: -18px;
                color: #f56b2a;
                font-family: "OpenSansBold",sans-serif;
            }
            .item_title, .oas-nativ-ads .oas-link .oas-nativ-ad .detail .oas-product-title {
                margin-bottom: 10px;
                margin-bottom: 1rem;
                font-size: 16px;
                font-size: 1.6rem;
                font-family: "OpenSansSemiBold",sans-serif;
            }
            .blue {
                color: #4183d7;
            }
            .list_properties {
                float: right;
            }


            .selectWrapper {
                background: #ffffff url(//static.leboncoin.fr/img/arrow-select.png) no-repeat right;
            }
            .selectWrapper.blue {
                border: 1px solid #4183d7;
            }
            .selectWrapper.blue .select {
                padding-right: 35px;
                padding-right: 3.5rem;
                color: #4183d7;
                font-family: "OpenSansSemiBold",sans-serif;
            }
        </style>
        <title>Hamza</title>
        <meta charset="${encoding}">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </head>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>"/>

    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">

    <body>
        <div class="container" style="margin-top: 10px">
            <div class="row"> 
                <div class="col" style="text-align: center">
                    <h2>  Catégorie</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-sm">
                    <span><a id="" href="https://www.hamza.ma/fr/maroc/téléphones-à_vendre">Téléphones </a> <span class="fs12">(78695)</span></span>
                </div>
                <div class="col-sm">
                    <span><a id="" href="https://www.hamza.ma/fr/maroc/tablettes-à_vendre">Tablettes </a> <span class="fs12">(4471)</span></span>
                </div>
                <div class="col-sm">
                    <span><a id="" href="https://www.hamza.ma/fr/maroc/ordinateurs_portables-à_vendre">Ordinateurs Portables </a> <span class="fs12">(32417)</span></span>
                </div>
            </div>
            <div class="row">
                <div class="col-sm">
                    <span><a id="" href="https://www.hamza.ma/fr/maroc/ordinateurs_bureau-à_vendre">Ordinateurs De Bureau </a> <span class="fs12">(19001)</span></span>
                </div>
                <div class="col-sm">
                    <span><a id="" href="https://www.hamza.ma/fr/maroc/accessoires_informatique_et_gadgets-à_vendre">Accessoires Informatique Et Gadgets </a> <span class="fs12">(46071)</span></span>
                </div>
                <div class="col-sm">
                    <span><a id="" href="https://www.hamza.ma/fr/maroc/jeux_vidéo_et_consoles-à_vendre">Jeux Vidéo Et Consoles </a> <span class="fs12">(10673)</span></span>
                </div>
            </div>
            <div class="row">
                <div class="col-sm">
                    <span><a id="" href="https://www.hamza.ma/fr/maroc/appareils_photo_cameras-à_vendre">Appareils Photo Et Caméras </a> <span class="fs12">(11974)</span></span>
                </div>
                <div class="col-sm">
                    <span><a id="" href="https://www.hamza.ma/fr/maroc/télévisions-à_vendre">Télévisions </a> <span class="fs12">(4416)</span></span>
                </div>
                <div class="col-sm">
                    <span><a id="" href="https://www.hamza.ma/fr/maroc/image_et_son-à_vendre">Image &amp; Son </a> <span class="fs12">(7465)</span></span>
                </div>
            </div>

        </div>

        <div class="container" style="margin-top: 20px">   
            <div class="list-group" >
                <div style="display: inline">
                    <div style="float:left"> <ul class="nav nav-tabs">
                        <li class="nav-item">
                            <a class="nav-link active" href="#">Toutes, 22145</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="#">Particulier, 11112</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Professionnel,565659</a>
                        </li>                       
                    </ul></div>
                   
                     <div class="selectWrapper blue" style="float: right;margin-top: 10">
                        <select id="listSorting" class="select" onchange="listSortingChange(this); xt_click(this, 'C', '8', 'ad_search::' + this.options[this.selectedIndex].getAttribute('data-value'), 'N');">
                            <option value="//www.leboncoin.fr/annonces/offres/picardie/?sp=0" data-value="trier_par_date" selected="">Trier par : Date</option>
                            <option value="//www.leboncoin.fr/annonces/offres/picardie/?sp=1" data-value="trier_par_prix">Trier par : Prix</option>
                        </select>
                    </div>
                </div>
                 <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="li-item-1" class="list-group-item list-group-item-action" style="height: 140px" >  
                    <div class="item_image">
                        <span class="item_imagePic">
                            <span class="lazyload loaded" style="display:block; width:100%; height:100%;" data-imgsrc="https://img1.leboncoin.fr/ad-thumb/e98a9a9da4af7edea15b552bce1fe3fc92899d88.jpg" data-imgalt="À SAISIR ! Nouvelle M4 série FROZEN garantie 2020"><img itemprop="image" content="https://img1.leboncoin.fr/ad-thumb/e98a9a9da4af7edea15b552bce1fe3fc92899d88.jpg" src="https://img1.leboncoin.fr/ad-thumb/e98a9a9da4af7edea15b552bce1fe3fc92899d88.jpg" alt="À SAISIR ! Nouvelle M4 série FROZEN garantie 2020"></span>
                        </span>
                        <span class="item_imageNumber">
                            <i class="fas fa-camera" style="color: white ;  font-size: 25px;"></i>

                            <span>3</span>
                        </span>      
                    </div>
                    <div class="item-info ctext1">
                        <div class="ctext2">
                            <div class="ctext3 fs12">
                                <h2 class="item_title"><a href="https://www.hamza.ma/fr/casablanca/téléphones/SAMSUNG_J2__D_Ori___8G_28921550.htm"> SAMSUNG J2 D'Ori 8G </a></h2>
                                <span class="item-info-extra fs14">
                                    <small>
                                        <a href="https://www.hamza.ma/fr/casablanca/">Casablanca</a>
                                    </small>
                                </span>
                            </div>
                        </div>
                        <h3 class="item_price" itemprop="price" content="30">
                            30&nbsp;€
                        </h3>
                    </div>

                    <aside class="item_absolute asideclass" >
                        <p class="item_supp" itemprop="availabilityStarts" content="2018-06-23">		                            
                            <strong>Aujourd'hui,</strong><br> 19:30
                        </p>
                    </aside>
                </div>     
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <script src="<?php echo e(asset('assets/css/jquery-3.3.1.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>" type="text/javascript"></script>

    </body>
</html>