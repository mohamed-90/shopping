<html>
    <head>
        <title>Déposez une annonce</title>
        <meta charset="${encoding}">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </head>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>"/>

    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">

    <link href="<?php echo e(asset('assets/css/bootstrap-fileupload.min.css')); ?>" rel="stylesheet" />
    <!--CUSTOM BASIC STYLES-->
    <link href="<?php echo e(asset('assets/css/basic.css')); ?>" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="<?php echo e(asset('assets/css/custom.css')); ?>" rel="stylesheet" />
    <body style="background: #e1e1ea">

        <div class="container" id="app">
            <?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>            
            <br>
            <form v-on:submit.prevent="validateForm('fortest')" data-vv-scope="fortest">
                <div class="card">
                    <h6 class="card-header">Créez votre annonce</h6>            
                    <div class="card-body">
                        <div class="form-group row">
                            <label for="exampleFormControlSelect1" class="col-sm-2" >Catégorie</label>
                            <select class="form-control" id="exampleFormControlSelect1" @change="onChange()" style="max-width: 220px; width: 220px;" v-model="product.id_category">
                                <option value="11001">Prestation de services</option>
                                <option value="11002">Evenement st traiteurs</option>
                                <option value="11003">Cours particuliers</option>
                                <option value="11004">Covoiturages</option>
                            </select>     
                        </div>

                        <?php echo $__env->make('partials.product.c_Ville', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        <div class="form" id="form_11001" >
                            <?php echo $__env->make('categorys.Entreprises1.entreprises_div', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                        <div class="form" id="form_11002" style="display: none;">
                            <?php echo $__env->make('categorys.Entreprises1.entreprises_div', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
                        </div>
                        <div class="form" id="form_11003" style="display: none;">
                            <?php echo $__env->make('categorys.Entreprises1.entreprises_div', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                        <div class="form" id="form_11004" style="display: none;">
                            <?php echo $__env->make('categorys.Entreprises1.entreprises_div', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                    </div>
                </div>
                <br>
                <?php echo $__env->make('partials.product.VosCoordonnees', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <button type="submit" id='Annonce'  style="float: right; display: none" >send</button>
            </form>

            <?php echo $__env->make('partials.product.A_Photos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <br>
            <button class="btn btn-primary" id='poublie'  style="float: right">Publier mon annonce</button>
            <br>
            <br>
        </div>

        <script src="<?php echo e(asset('assets/css/jquery-3.3.1.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
        <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </body>


    <script src="<?php echo e(asset('js/vue.js')); ?>" ></script>
    <script src="<?php echo e(asset('js/veeValidate.js')); ?>" ></script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>

    <script>
Vue.use(VeeValidate);

window.Laravel = <?php echo json_encode([
        'csrfToken' => csrf_token(),
//    'idProduct' => $id_product,
'url' => url('/')
]); ?>

;
    </script>
    <script src="<?php echo e(asset('js/index.js')); ?>"></script>

</html>