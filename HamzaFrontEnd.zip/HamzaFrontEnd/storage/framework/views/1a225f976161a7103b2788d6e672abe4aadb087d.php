<div>

    <div class="flex-center flex-column"  style="background: #009999">
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" style=" color: #0d0d0d" id="final-tab" data-toggle="tab" href="#final" role="tab" aria-controls="final" aria-selected="true"><i class="fa fa-caret-square-o-up" aria-hidden="true"></i> Actives(1)</a>
            </li>
            <li class="nav-item">
                <a class="nav-link " style=" color: #0d0d0d" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false"><i class="fa fa-close" aria-hidden="true"></i> Rejetées(0)</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" style=" color: #0d0d0d" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false"><i class="fa fa-caret-square-o-down" aria-hidden="true"></i> Désactivées(0)</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" style=" color: #0d0d0d" id="follow-tab" data-toggle="tab" href="#follow" role="tab" aria-controls="follow" aria-selected="false"><i class="fa fa-circle-o-notch" aria-hidden="true"></i> Dans la modération(0)</a>
            </li>

        </ul>
    </div>     

    <div class="tab-content" id="myTabContent">
        <div class="tab-pane fade show active" id="final" role="tabpanel" aria-labelledby="final-tab">
            <?php echo $__env->make('client.tablue', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>                      
        </div>
        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
            <?php echo $__env->make('categorys.EmploiService.Stages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            bbbbbbbbbb
        </div>
        <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
            <?php echo $__env->make('categorys.EmploiService.Stages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            ggggggggggg
        </div>
        <div class="tab-pane fade" id="follow" role="tabpanel" aria-labelledby="follow-tab">
            <?php echo $__env->make('categorys.EmploiService.OffreDemploi', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            hhhhhhh
        </div>

    </div>



</div>