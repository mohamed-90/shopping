<html>
    <head>
        <title>Hamza</title>
        <meta charset="${encoding}">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>"/>

    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <style >
        .media-preview {
            float: left;
            width: 128px;
            height: 130px;
            overflow: auto;
            overflow-y: auto;
        }
        .media-preview {
            border: thin dashed #777;
            margin: .5em;
            padding: .5em;
            border-radius: 1em;
            background: rgba(255,255,255,.7);
            overflow: auto;
            position: relative;
        }

        .media-preview-image {
            margin: auto;
            min-height: 6.25em;
            min-width: 6.25em;
            text-align: center;
            overflow: hidden;
            padding-top: 5px;
        }
        .media-delete {
            display: block;
            position: absolute;
            top: 2px;
            right: 2px;
        }
        .media-editable-saved {
            opacity: 0;
            transition-duration: 0.3s;
            position: absolute;
            bottom: .3em;
            left: 1em;
            background-color: white;
            border: thin solid #777;
            z-index: 5;
        }
        .clearfix:before,
        .clearfix:after {
            content: " "; /* 1 */
            display: table; /* 2 */
        }

        .clearfix:after {
            clear: both;
        }

        /*
         * For IE 6/7 only
         * Include this rule to trigger hasLayout and contain floats.
         */

        .clearfix {
            *zoom: 1;
        }

    </style>
    <body>
        <div class="container" id="app">

            <?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo e(csrf_field()); ?>

            <br>
            <div class="card">
                <h6 class="card-header">Publier une annonce</h6>
                <div class="card-body">
                    <!--  <h6 class="card-title">Special title treatment</h6>-->
                    <div class="form-group row">
                        <label for="exampleFormControlSelect1" class="col-sm-2" >Vous êtes un *</label>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="0" v-model="user.type_client">
                            <label class="form-check-label" for="inlineRadio1">Particulier</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="1" v-model="user.type_client">
                            <label class="form-check-label" for="inlineRadio2">Professionnel</label>
                        </div>

                        <hr class="input-xxlarge">
                    </div>
                    <hr>
                    <div class="form-group row">
                        <label for="exampleFormControlSelect1" class="col-sm-2" v-model="product.id_category" >Catégorie</label>
                        <select class="form-control" id="exampleFormControlSelect1" style="max-width: 220px; width: 220px;">
                            <option>Emploi</option>
                            <option>Auto - Moto</option>
                            <option>Vente immobilier</option>
                            <option>Location immobilier</option>
                            <option>Multi Services</option>
                            <option>Ventes diverses</option>
                            <option>Multimédia</option>
                        </select>
                    </div>
                    <div class="form-group row">
                        <label for="validationCustom01" class="col-sm-2" >Titre </label>                            
                        <input type="text" class="form-control col-sm-10" id="validationCustom01" v-model="product.titre" style="max-width: 220px; width: 220px;" maxlength="50" required>
                    </div>
                    <div class="form-group row">
                        <label for="exampleFormControlTextarea1" class="col-sm-2" >Description </label>
                        <textarea class="form-control col-sm-10" style="max-width: 430px; width: 430px;" id="exampleFormControlTextarea1" rows="3" maxlength="2000" v-model="product.description"></textarea>
                    </div>
                    <div class="form-group row">
                        <label for="exampleFormControlSelect1" class="col-sm-2" >Prix </label>
                        <div class="input-group" style="max-width: 220px; width: 220px;">
                            <input type="text" class="form-control" id="validationDefault05" aria-label="Prix en DH" aria-describedby="btnGroupAddon" v-model="product.price" required>
                            <div class="input-group-append">
                                <span class="input-group-text" id="basic-addon2">DH</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <div class="card">
                <h6 class="card-header"><i class="far fa-address-card mr-2"></i>Vos coordonnées</h6>
                <div class="card-body">
                    <div class="form-group row">
                        <label for="edtNom" class="col-sm-2" >Nom </label>
                        <input type="text" class="form-control" id="edtNom" style="width: 270px" v-model="user.nom" maxlength="100" required>
                    </div>
                    <div class="form-group row">                           
                        <label for="exampleInputEmail1" class="col-sm-2">Email </label>
                        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" style="width: 270px" maxlength="100" v-model="user.email">
                    </div>
                    <div class="form-group row">
                        <label for="edtPhone" class="col-sm-2" >Téléphone </label>
                        <div  style="padding: 0px;width: 270px" >
                            <input type="text" class="form-control" id="edtPhone" v-model="user.phone" required>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" v-model="user.hide_phone" id="defaultCheck1" maxlength="50">
                                <label class="form-check-label" for="defaultCheck1">
                                    Cacher numéro
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="edtVille" class="col-sm-2" >Ville </label>
                        <select class="form-control" id="edtVille" style="width: 270px" v-model="user.id_ville">
                            <option value="2"> </option>
                            <option value="3" selected="">Toutes les villes</option>
                            <option style="background-color:#dcdcc3;" value="0" disabled="disabled">-- AUTRES VILLES --</option>
                            <option id="searcharea_expanded_fisrt_option" value="10005"> Casablanca</option>
                            <option value="10013"> Agadir</option>
                            <option value="10017"> Al Hoceïma</option>
                            <option value="10014"> Béni Mellal</option>
                            <option value="10007"> El Jadida</option>
                            <option value="10018"> Errachidia</option>
                            <option value="10003"> Fès</option>
                            <option value="10004"> Kénitra</option>
                            <option value="10019"> Khénifra</option>
                            <option value="10001"> Khouribga</option>
                            <option value="10020"> Larache</option>
                            <option value="10008"> Marrakech</option>
                            <option value="10009"> Meknès</option>
                            <option value="10021"> Nador</option>
                            <option value="10022"> Ouarzazate</option>
                            <option value="10010"> Oujda</option>
                            <option value="10012"> Rabat</option>
                            <option value="10002"> Safi</option>
                            <option value="10023"> Settat</option>
                            <option value="10006"> Salé</option>
                            <option value="10015"> Tanger</option>
                            <option value="10016"> Taza</option>
                            <option value="10011"> Tétouan</option>
                            <option value="other" style="color: red">Choisir une autre ville...</option>
                        </select>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-2">
                            <label for="exampleInputPassword1" >Mot de passe </label>
                            <small id="passwordHelp" class="form-text text-muted">[minimum 6 caractères]</small>
                        </div>
                        <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Entrer un mot de passe" style="width: 437px" v-model="user.password" maxlength="100">
                    </div>
                </div>
            </div>
            <br>
            <div class="card">
                <h6 class="card-header">Ajouter jusqu'a 10 photos</h6>
                <div class="card-body">
                    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                    <a href="#" type="file" class="btn btn-primary">Ajouter des photos</a>
                    <div id="imagesUploaded" class="media-preview-container clearfix ui-sortable"   style="display: block">
                        <div class="media-preview clearfix" style="padding: 0px" v-for="item of pictures" :id="'imagesPreview_'+item.id" >
                            <div class="media-editable-saved"><img src="geo_templates/default/external/images/saved-check.png" alt=""></div>
                            <a href="http://www.hamza.com/AJAX.php?controller=UploadImage&amp;action=upload&amp;adminId=0&amp;userId=0&amp;ua=Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Chrome%2F69.0.3497.100+Safari%2F537.36#7281938" class="deleteImage media-delete">
                                <img alt="Supprimer Image" src="<?php echo e(asset('assets/icons/trash.png')); ?>">
                            </a>
                            <small >  <b class="badge">Photo:</b></small>
                          
                            <input style="width: 40;height: 20px" type="number" class="media-editable-sorting editImageSort" value="1" size="2" min="1" max="8">
                            <br>
                            <div style="background: blue; padding: 0px" class="media-preview-image">
                                <a href="user_images/9885833.jpg" class="lightUpImg">		
                                    <img src="user_images/7951841.jpg" width="100" height="37" alt="">
                                </a>		
                            </div>
                        </div>         
                    </div>
                    <div class="row">
                        <p><i class="fas fa-exclamation-triangle mr-2"></i>
                            En validant mon annonce, j'accepte les <a href="/conditions-utilisation.html" target="_blank" title="Règles d'utilisation">Règles d'utilisation</a> 
                            du site hamza.ma, et j'autorise hamza.ma à diffuser mon annonce</p>
                    </div>
                    <a href="/link-to/whatever-address/" id="cancel" name="cancel" class="btn btn-default" >Annuler</a>
                </div>
            </div>

            <button  class="btn btn-primary"  style="float: right" @click="addProduct">Publier mon annonce</button>
        </div>

        <script src="<?php echo e(asset('assets/css/jquery-3.3.1.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
    </body>


    <script src="<?php echo e(asset('js/vue.js')); ?>" ></script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>

    <script>
window.Laravel = <?php echo json_encode([
        'csrfToken' => csrf_token(),
//    'idProduct' => $id_product,
'url' => url('/')
]); ?>

;
    </script>

    <script>
        var vm = new Vue({
            el: '#app',
            data: {
                //  message: 'je suis fahd',
                product: {
                    id_product: 0,
                    titre: '',
                    description: '',
                    price: 0,
                    id_ville: 2
                },
                user: {
                    id: 0,
                    type_client: 0,
                    nom: '',
                    email: '',
                    password: '',
                    phone: '',
                    hide_phone: 0,
                    id_ville: 2,
                    created_at: null,
                    updated_at: null,
                    deleted_at: null
                },
                pictures: [
                    {
                        id: 0,
                        photo_path: '',
                        is_principal: 0,
                        nom: 'photo 0'
                    },
                    {
                        id: 1,
                        photo_path: '',
                        is_principal: 1,
                        nom: 'photo 1'
                    },
                    {
                        id: 2,
                        photo_path: '',
                        is_principal: 2,
                        nom: 'photo 2'
                    },
                    {
                        id: 3,
                        photo_path: '',
                        is_principal: 3,
                        nom: 'photo 3'
                    }
                ]
            },
            methods: {
                addProduct: function ()
                {
                    //    alert(window.Laravel.url );
                    axios.post(window.Laravel.url + '/add_product', this.product)
                            //     axios.post('/toto/add_product',this.product)
                            .then(response =>
                            {
                                //  this.product = response.data;
                                alert('Goood ');
                                // this.$router.push('/offres');
                                location.href = window.Laravel.url + '/offres'
                                //   window.location =  response.data.redirect;//window.Laravel.url + '/offres'

                            })
                            .catch(error =>
                            {
                                console.log('errors : ', error);
                            })
                },

                deleteParcelle: function (product)
                {
                    swal({
                        title: 'Etes vous sûr de vouloir supprimer l enregistrement ?',
                        text: "Supprimer l enregistrement?",
                        type: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Oui, supprimer!'
                    }).then((result) => {
                        if (result.value) {
                            axios.delete(window.Laravel.url + '/deleteproduct/' + product.id_product + ';' + product.id_user_createby).then(product =>
                            {
                                if (product.data.etat)
                                {
                                    var position = this.productss.indexOf(product);
                                    this.products.splice(position, 1);
                                }
                            })
                                    .catch(error => {
                                        console.log(error)
                                    })
                            swal(
                                    'Enregistrement supprimé!',
                                    'L enregistrement a été supprimé avec succès.',
                                    'success'
                                    )
                        }
                    })
                },
                submit() {
                    //if you want to send any data into server before redirection then you can do it here
                    this.$router.push();
                }

            },
            mounted: function () {
                //   this.addProduct();
            }

        });


    </script>
</html>