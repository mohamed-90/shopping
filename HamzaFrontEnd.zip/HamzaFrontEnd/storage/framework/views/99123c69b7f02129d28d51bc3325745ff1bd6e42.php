<html>
    <head>
        <title>Déposez une annonce</title>
        <meta charset="${encoding}">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </head>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>"/>

    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <body>

        <div class="container" id="app">
            <?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo e(csrf_field()); ?>


            <br>
            <div class="card">
                <h6 class="card-header">Publier une annonce</h6>
                <div class="card-body">

                    <div class="form-group row">
                        <label for="exampleFormControlSelect1" class="col-sm-2" >Catégorie</label>
                        <select class="form-control" id="exampleFormControlSelect1" style="max-width: 220px; width: 220px;" v-model="product.id_category">
                            <option value="8001" selected>Appartements</option>
                            <option value="8002">Maisons et Villas</option>
                            <option value="8003">Locations de vacances</option>
                            <option value="8004">Bureaux et Plateaux</option>
                            <option value="8005">Magasins, Commerces et Locaux industriels</option>
                            <option value="8005">Terrains et Fermes</option>
                            <option value="8005">Colocations</option>
                        </select>                         
                    </div>

                    <?php echo $__env->make('partials.product.c_Ville', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <div style="display: none;">   {{this.totals=5}}</div>

                    <div  >
                        <?php echo $__env->make('categorys.ToutForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                   
                </div>
            </div>
            <br>
            <?php echo $__env->make('partials.product.VosCoordonnees', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <br>
                  <?php echo $__env->make('partials.product.A_Photos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
           <br>    
            <button  class="btn btn-primary"  style="float: right" @click="addProduct">Publier mon annonce</button>
            <br> 
            <div>
                <br>            
            </div> 

        </div>

        <script src="<?php echo e(asset('assets/css/jquery-3.3.1.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
        <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </body>

    <script src="<?php echo e(asset('js/vue.js')); ?>" ></script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    <script src="<?php echo e(asset('js/index.js')); ?>"></script>
    <script>
window.Laravel = <?php echo json_encode([
        'csrfToken' => csrf_token(),
//    'idProduct' => $id_product,
'url' => url('/')
]); ?>

;
    </script>

</html>