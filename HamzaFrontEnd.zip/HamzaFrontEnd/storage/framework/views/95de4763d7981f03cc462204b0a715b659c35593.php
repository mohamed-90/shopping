<html>
    <head>
        <title>Hamza</title>
        <meta charset="${encoding}">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>"/>

    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <body>

        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <span class="navbar-text">
                 <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                       
                         Bienvenue  <a href="<?php echo e(route('login')); ?>">Connectez-vous</a>  ou <a href="<?php echo e(route('register')); ?>">inscrivez-vous</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
               
            </span>
            <!--            <a class="navbar-brand" href="#">Navbar</a>-->
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item active">
                        <a class="nav-link" href="#">DÉPOSER UNE ANNONCE <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('offres')); ?>">OFFRES</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">DEMANDES</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">BOUTIQUES</a>
                    </li>

                    <!-- <form class="form-inline">
                                <button class="btn btn-outline-success" type="button">Se connecter</button>
                                <button class="btn btn-sm btn-outline-secondary" type="button">S'inscrire</button>
                            </form> 
                    <li class="nav-item">
                                <a class="nav-link disabled" href="#">Disabled</a>
                            </li>-->     
                </ul>
            </div>
        </nav>


        <div >
            <div class="container">
                <div class="row">
                    <div class="col col-12 col-sm-12  col-md-3 col-lg-4">
                        <input class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="q" value=""  size="20" id="searchtext" type="text" placeholder="Que recherchez-vous ?">
                    </div>
                    <div class="col col-12 col-sm-12 col-md-3 col-lg-3.5">
                        <select name="cg" id="catgroup" class="form-control">
                            <option value="0">Toutes les catégories</option>
                            <option style="background-color:#dcdcc3; font-weight: bold;" value="5000">-- INFORMATIQUE ET MULTIMEDIA --</option>
                            <option value="5010">Téléphones</option>
                            <option value="5080">Tablettes</option>
                            <option value="5030">Ordinateurs portables</option>
                            <option value="5050">Ordinateurs de bureau</option>
                            <option value="5060">Accessoires informatique et Gadgets</option>
                            <option value="5040">Jeux vidéo et Consoles</option>
                            <option value="5070">Appareils photo et Caméras</option>
                            <option value="5090">Télévisions</option>
                            <option value="5020">Image &amp; Son</option>
                            <option style="background-color:#dcdcc3; font-weight: bold;" value="2000">-- VEHICULES --</option>
                            <option value="2010">Voitures</option>
                            <option value="2030">Motos</option>
                            <option value="2060">Vélos</option>
                            <option value="2070">Véhicules Professionnels</option>
                            <option value="2050">Bateaux</option>
                            <option value="2040">Pièces et Accessoires pour véhicules</option>
                            <option style="background-color:#dcdcc3; font-weight: bold;" value="1000">-- IMMOBILIER --</option>
                            <option value="1010">Appartements</option>
                            <option value="1020">Maisons et Villas</option>
                            <option value="1050">Bureaux et Plateaux</option>
                            <option value="1060">Magasins, Commerces et Locaux industriels</option>
                            <option value="1080">Terrains et Fermes</option>
                            <option value="1030">Locations de vacances</option>
                            <option value="1100">Colocations</option>
                            <option value="1090">Autre Immobilier</option>
                            <option style="background-color:#dcdcc3; font-weight: bold;" value="3000">-- POUR LA MAISON ET JARDIN --</option>
                            <option value="3010">Electroménager et Vaisselles</option>
                            <option value="3020">Meubles et Décoration</option>
                            <option value="3040">Jardin et Outils de bricolage</option>
                            <option style="background-color:#dcdcc3; font-weight: bold;" value="8000">-- HABILLEMENT ET BIEN ETRE --</option>
                            <option value="3050">Vêtements</option>
                            <option value="3150">Chaussures</option>
                            <option value="3160">Montres et Bijoux</option>
                            <option value="3060">Sacs et Accessoires</option>
                            <option value="3030">Vêtements pour enfant et bébé</option>
                            <option value="3130">Equipements pour enfant et bébé</option>
                            <option value="3070">Produits de beauté</option>
                            <option style="background-color:#dcdcc3; font-weight: bold;" value="4000">-- LOISIRS ET DIVERTISSEMENT --</option>
                            <option value="4010">Sports et Loisirs</option>
                            <option value="4030">Animaux</option>
                            <option value="4070">Instruments de Musique</option>
                            <option value="4060">Art et Collections</option>
                            <option value="4050">Voyages et Billetterie</option>
                            <option value="4040">Films, Livres, Magazines</option>
                            <option style="background-color:#dcdcc3; font-weight: bold;" value="6000">-- EMPLOI ET SERVICES --</option>
                            <option value="6010">Offres d'emploi</option>
                            <option value="6020">Demandes d'emploi</option>
                            <option value="6130">Stages</option>
                            <option value="6030">Services</option>
                            <option value="6040">Cours et Formations</option>
                            <option style="background-color:#dcdcc3; font-weight: bold;" value="9000">-- ENTREPRISES --</option>
                            <option value="6100">Business et Affaires commerciales</option>
                            <option value="6090">Matériels Professionnels</option>
                            <option value="6120">Stocks et Vente en gros</option>
                            <option style="background-color:#dcdcc3; font-weight: bold;" value="7000">-- Autres --</option>
                            <option value="7010">AUTRES</option>

                        </select>

                    </div>
                    <div class="col col-12 col-sm-12  col-md-3 col-lg-3.5">
                        <select name="w" id="searcharea_expanded" class="form-control" >
                            <option value="2"> </option>
                            <option value="3" selected="">Tout le Maroc</option>
                            <option style="background-color:#dcdcc3;" value="0" disabled="disabled">-- AUTRES VILLES --</option>
                            <option id="searcharea_expanded_fisrt_option" value="10005"> Casablanca</option>
                            <option value="10013"> Agadir</option>
                            <option value="10017"> Al Hoceïma</option>
                            <option value="10014"> Béni Mellal</option>
                            <option value="10007"> El Jadida</option>
                            <option value="10018"> Errachidia</option>
                            <option value="10003"> Fès</option>
                            <option value="10004"> Kénitra</option>
                            <option value="10019"> Khénifra</option>
                            <option value="10001"> Khouribga</option>
                            <option value="10020"> Larache</option>
                            <option value="10008"> Marrakech</option>
                            <option value="10009"> Meknès</option>
                            <option value="10021"> Nador</option>
                            <option value="10022"> Ouarzazate</option>
                            <option value="10010"> Oujda</option>
                            <option value="10012"> Rabat</option>
                            <option value="10002"> Safi</option>
                            <option value="10023"> Settat</option>
                            <option value="10006"> Salé</option>
                            <option value="10015"> Tanger</option>
                            <option value="10016"> Taza</option>
                            <option value="10011"> Tétouan</option>
                            <option value="other" style="color: red">Choisir une autre ville...</option>
                        </select>

                    </div>
                    <div class="col-12 col-md-auto">
                        <button type="button" class="btn btn-primary">Rechercher</button>
                    </div>
                </div>

                <div class="row">
                    <div class="col" style="text-align: center">
                        <h2>Toutes les catégories que vous imaginez</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm">      
                        <div class="card bg-light mb-3" style="text-align: center">                                

                            <div class="card-body">
                                <h1>   <i class="fas fa-car"></i><i class="fas fa-motorcycle"></i></h1>
                                <h5 class="card-title" style="text-align: center" >VEHICULES</h5>
<!--                                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                <a  class="list-group-item list-group-item-action" href="#" class="btn btn-primary">Go somewhere</a>-->
                            </div>
                        </div>
                    </div>
                    <div class="col-sm">  
                        <div class="card bg-light mb-3" style="text-align: center"> <!--style="width: 16rem;text-align: center"-->                               

                            <div class="card-body">
                                <h1>   <i class="fas fa-home"></i></h1>
                                <h5 class="card-title">IMMOBILIER</h5>
    <!--                                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                <a  class="list-group-item list-group-item-action" href="#" class="btn btn-primary">Go somewhere</a>-->
                            </div>
                        </div></div>
                    <div class="col-sm">  
                        <div class="card bg-light mb-3" style="text-align: center">                                

                            <div class="card-body">
                                <h1> <i class="far fa-building"></i></h1>
                                <h5 class="card-title">MAISON</h5>
    <!--                                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                <a  class="list-group-item list-group-item-action" href="#" class="btn btn-primary">Go somewhere</a>-->
                            </div>
                        </div>
                    </div>
                    <div class="col-sm">          
                        <div class="card bg-light mb-3" style="text-align: center">                                

                            <div class="card-body">
                                <h1>   <i class="fas fa-laptop"></i></h1>
                                <h5 class="card-title">ELECTRONIQUE</h5>
    <!--                                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                <a  class="list-group-item list-group-item-action" href="#" class="btn btn-primary">Go somewhere</a>-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">     
                    <div class="col-sm">
                        <div class="card bg-light mb-3" style="text-align: center">                                

                            <div class="card-body">
                                <h1>  <i class="fas fa-bicycle"></i></h1>
                                <h5 class="card-title">LOISIRS ET SPORTS</h5>
    <!--                                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                <a  class="list-group-item list-group-item-action" href="#" class="btn btn-primary">Go somewhere</a>-->
                            </div>
                        </div>
                    </div>
                    <div class="col-sm">  
                        <div class="card bg-light mb-3" style="text-align: center">                                

                            <div class="card-body">
                                <h1>   <i class="fas fa-briefcase"></i></h1>
                                <h5 class="card-title">EMPLOI ET SERVICES</h5>
    <!--                                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                <a  class="list-group-item list-group-item-action" href="#" class="btn btn-primary">Go somewhere</a>-->
                            </div>
                        </div>
                    </div>
                  <div class="col-sm">
                    <div class="card bg-light mb-3" style="text-align: center">                                


                        <div class="card-body">
                            <h1>   <i class="fas fa-briefcase"></i></h1>
                            <h5 class="card-title">AUTRES</h5>
<!--                                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                            <a  class="list-group-item list-group-item-action" href="#" class="btn btn-primary">Go somewhere</a>-->
                        </div>
                    </div>
                  </div>
                     <div class="col-sm">
                    <div class="card bg-light mb-3" style="text-align: center">                                


                        <div class="card-body">
                            <h1>   <i class="fas fa-briefcase"></i></h1>
                            <h5 class="card-title">AUTRES</h5>
<!--                                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                            <a  class="list-group-item list-group-item-action" href="#" class="btn btn-primary">Go somewhere</a>-->
                        </div>
                    </div>
                  </div>
              
               </div>
               </div>
            </div>
            <div class="container">
                <div class="row"> 
                    <div class="col" style="text-align: center">
                        <h2>  Sélectionner la ville</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col">     
                        <div class="list-group"  id="region_list_1" class="region_list span3 pull-left">
                            <a  class="list-group-item list-group-item-action" id="region_5" href="https://www.hamza.ma/fr/casablanca/">Casablanca</a>
                            <a  class="list-group-item list-group-item-action" id="region_13" href="https://www.hamza.ma/fr/agadir/">Agadir</a>
                            <a  class="list-group-item list-group-item-action" id="region_17" href="https://www.hamza.ma/fr/al_hociema/">Al Hoceïma</a>
                            <a  class="list-group-item list-group-item-action" id="region_14" href="https://www.hamza.ma/fr/béni_mellal/">Béni Mellal</a>
                            <a  class="list-group-item list-group-item-action" id="region_7" href="https://www.hamza.ma/fr/el_jadida/">El Jadida</a>
                            <a  class="list-group-item list-group-item-action" id="region_18" href="https://www.hamza.ma/fr/errachidia/">Errachidia</a>
                            <a  class="list-group-item list-group-item-action" id="region_3" href="https://www.hamza.ma/fr/fès/">Fès</a>
                            <a  class="list-group-item list-group-item-action" id="region_4" href="https://www.hamza.ma/fr/kénitra/">Kénitra</a>
                            <a  class="list-group-item list-group-item-action" id="region_19" href="https://www.hamza.ma/fr/khénifra/">Khénifra</a>
                            <a  class="list-group-item list-group-item-action" id="region_1" href="https://www.hamza.ma/fr/khouribga/">Khouribga</a>
                            <a  class="list-group-item list-group-item-action" id="region_20" href="https://www.hamza.ma/fr/larache/">Larache</a>
                            <a  class="list-group-item list-group-item-action" id="region_8" href="https://www.hamza.ma/fr/marrakech/">Marrakech</a>
                            <a  class="list-group-item list-group-item-action" id="region_9" href="https://www.hamza.ma/fr/meknès/">Meknès</a>
                        </div>
                    </div>
                    <div class="col">       
                        <div class="list-group" id="region_list_2" class="region_list span3 pull-right">
                            <a  class="list-group-item list-group-item-action" id="region_9" href="https://www.hamza.ma/fr/meknès/">Meknès</a>
                            <a  class="list-group-item list-group-item-action" id="region_21" href="https://www.hamza.ma/fr/nador/">Nador</a>
                            <a  class="list-group-item list-group-item-action" id="region_22" href="https://www.hamza.ma/fr/ouarzazate/">Ouarzazate</a>
                            <a  class="list-group-item list-group-item-action" id="region_10" href="https://www.hamza.ma/fr/oujda/">Oujda</a>
                            <a  class="list-group-item list-group-item-action" id="region_12" href="https://www.hamza.ma/fr/rabat/">Rabat</a>
                            <a  class="list-group-item list-group-item-action" id="region_2" href="https://www.hamza.ma/fr/safi/">Safi</a>
                            <a  class="list-group-item list-group-item-action" id="region_23" href="https://www.hamza.ma/fr/settat/">Settat</a>
                            <a  class="list-group-item list-group-item-action" id="region_6" href="https://www.hamza.ma/fr/salé/">Salé</a>
                            <a  class="list-group-item list-group-item-action" id="region_15" href="https://www.hamza.ma/fr/tanger/">Tanger</a>
                            <a  class="list-group-item list-group-item-action" id="region_16" href="https://www.hamza.ma/fr/taza/">Taza</a>
                            <a  class="list-group-item list-group-item-action" id="region_11" href="https://www.hamza.ma/fr/tétouan/">Tétouan</a>
                            <a  class="list-group-item list-group-item-action" id="colorlink" href="#" onclick="view_other_region_selector()">&gt; Autre ville...</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-content" id="pills-tabContent">
            <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">...</div>
            <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">...</div>
            <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">...</div>
        </div>

        <script src="<?php echo e(asset('assets/css/jquery-3.3.1.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
    </body>
</html>

