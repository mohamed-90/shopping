<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Model_marque_vehicule extends Model
{
    //
}
