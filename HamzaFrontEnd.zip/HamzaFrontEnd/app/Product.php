<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    public $timestamps = true;
     public function ville()
    {     
         return $this->belongsTo('App\Ville', 'id_ville');
    }
    public function Marque_vehicule()
    {     
         return $this->belongsTo('App\Marque_vehicule', 'id_marque');
    }
    public function Model_marque_vehicule()
    {     
         return $this->belongsTo('App\Model_marque_vehicule', 'id_model');
    }
}
