<?php

namespace App\Http\Controllers;

use Auth;
use File;
use DirectoryIterator;
use SplFileInfo;
use Directory;
use Illuminate\Support\Facades\Input as Input;
use AdvanceSearch\AdvanceSearchProvider\Facades\SearchFacades as Search;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\User as Authenticatable;

class ProductController extends Controller {

    public function index() {
        $listItems = \App\Product::with('villes')->orderBy('is_premium', 'DESC')->get();
        //  $listprojets =DB::table('projets_fillbyview')->get();
        return view('products.search_by_criteria', ['products' => $listItems]);
    }

    public function add_product(Request $request) {
        $product = new \App\Product;
        $product->id_client = $request->id_client;
        $product->id_category = $request->id_category;
        $product->price = $request->price;
        $product->width = $request->width;
        $product->height = $request->height;
        $product->weight = $request->weight;
        $product->show_price = $request->show_price;
        $product->show_telephone = $request->show_telephone;
        $product->id_ville = $request->id_ville;
        $product->id_secteur = $request->id_secteur;
        $product->titre = $request->titre;
        $product->reference = $request->titre;
        $product->description = $request->description;
        $product->type_annonce = $request->type_annonce;
        $product->is_premium = $request->is_premium;
        $product->nb_photos = 5;
        $product->id_marque = $request->id_marque;
        $product->id_model = $request->id_model;
        $product->type_carburant = $request->type_carburant;
        $product->km = $request->km;
        $product->annee = $request->annee;
        $product->n_pieces = $request->n_pieces;
        $product->superficie = $request->superficie;
        $product->save();
    }

//    public function create() {
//        return view('products.add');
//    }

    public function EmploiServices() {
//        $test= 'hello';
        return view('categorys.EmploiServices');
    }

    public function Autres() {
        return view('categorys.Autres');
    }

    public function Entreprises() {
        return view('categorys.Entreprises');
    }

    public function HabillementBienEtre() {
        return view('categorys.HabillementBienEtre');
    }

    public function Immobilier() {
        return view('categorys.Immobilier');
    }

    public function InformatiqueMultimedia() {
        return view('categorys.InformatiqueMultimedia');
    }

    public function LoisirsDivertissement() {
        return view('categorys.LoisirsDivertissement');
    }

    public function MaisonJardin() {
        return view('categorys.MaisonJardin');
    }

    public function Vehicules() {
        return view('categorys.Vehicules');
    }

    public function Services() {
        return view('categorys.Services');
    }

    public function Vaconces() {
        return view('categorys.Vaconces');
    }

    public function espace() {

        if (Auth::user()) {
            $id_client = Auth::user()->id;
            $listItems = \App\Product::where('id_client', '=', $id_client)->paginate(8);
            return view('client.Adminee')->withProducts($listItems);
        } else {
            return view('auth.login');
        }
    }

    public function afficher_product($id) {
        $product = \App\Product::where('id', '=', $id)->first();
        $id_client = $product->id_client;

        $phats = public_path() . '/images/' . $id_client . '/' . $id;
        $files = $this->getfiles($phats);
        
        $listPremeom = \App\Product::orderBy('is_premium', 'DESC')->limit(4)->get();

        return view('partials.product.Afficher_product', ['product' => $product, 'files' => $files, 'premium' => $listPremeom]);
    }

    public function listeOffres() {
        $listItems = \App\Product::with('villes')->orderBy('is_premium', 'DESC')->get();

        return view('products.listeOffres', ['products' => $listItems]);
    }

    public function store(Request $request) {
        
    }

    public function show($id) {
        //
    }

    public function edit($id) {
        
    }

    public function update(Request $request) {
        
    }

    public function destroy($id) {
        //
    }

    public function afficher($ville, $nom, $age = 10) {
        echo dump('Hello ' . $nom . ' Ville ' . $ville . '-' . $age);
    }

    public function chekLogin(Request $request) {
        $msg = '0';
        $id = 0;
        $user = null;
        $user = \App\User::where('email', '=', $request->email)->first();

        if ($user === null) {
            $arr = [
                'name' => $request->name,
                'email' => $request->email,
                'phone' => $request->phone,
                'type_client' => $request->type_client,
                'password' => $request->password,];

            $user = app('App\Http\Controllers\Auth\RegisterController')->create($arr);
            $id = $user->id;
            $msg = '0';
            Auth::attempt(['email' => $request->email, 'password' => $request->password]);
        } else {
            if (password_verify($request->password, $user->password)) {
                $msg = '1';
                $id = $user->id;
                Auth::attempt(['email' => $request->email, 'password' => $request->password]);
            } else {
                $msg = '2';
            }
        }

        return [$id, $msg];
    }

    public function upload(Request $request) {
        $id_client = Auth::user()->id;
        $Product = \App\Product::where('id_client', '=', $id_client)
                        ->orderBy('created_at', 'DESC')->first();
        $id_product = $Product->id;

        $path = public_path() . '/images/' . $id_client;
        $path1 = public_path() . '/images/' . $id_client . '/' . $id_product;

        if (File::exists($path)) {
            File::makeDirectory($path1);
        } else {
            File::makeDirectory($path);
            File::makeDirectory($path1);
        }

        $j = 1;
        for ($i = 1; $i <= 5; $i++) {
            if ($request->hasFile('file_' . $i)) {
                $image = $request->file('file_' . $i);
                $fileExtension = $image->getClientOriginalExtension();
                $filename = $j . '.' . $fileExtension;
                $pathImage = $path1;
                $image->move($pathImage, $filename);
                $j++;
                if ($j === 2) {
                    $photo_default = $filename;
                }
            }
        }
        if ($j > 1) {
            $product = \App\Product::find($id_product);
            $product->photo_default = $photo_default;
            $product->nb_photos = $j;
            $product->save();
        }

        return back()->with('success', 'Image Uploaded Successfully');

//        return $this->ProductsClient();
    }

    public function getfiles($derectory) {

        $dir = new DirectoryIterator($derectory);
        return $dir;
        $arr = [];
        foreach ($dir as $fileinfo) {
            if (!$fileinfo->isDot()) {
                array_push($arr, $fileinfo);
            } else {
                array_push($arr, $fileinfo);
            }
        }

        return $arr;
    }

    /*   public function search( $orderBy=  "price") {
      //  $listItems = \App\Product::all();
      //  $listprojets =DB::table('projets_fillbyview')->get();


      // $listItems=  Search::search(
      //  "Product" ,
      //  ['reference' , 'description'] ,
      //   "demo_21",
      //  ['id_product' , 'reference', 'description'],
      //   ['is_premium', 'desc'] ,
      //   true ,
      //    30);
      $keyword ="demo";
      ;// "created_at"; //"price"

      $listItems = \App\Product::where('reference','like',"%".$keyword."%")
      ->orWhere('description', 'like', '%' . $keyword . '%')
      ->orderBy('is_premium', 'DESC')
      ->orderBy($orderBy,$orderBy=="price"? 'ASC' :'DESC')
      ->get();
      $listItemsPremium = \App\Product::where('is_premium', 1)->get();
      return view('products.search_by_criteria', ['products' => $listItems,'premium_products' => $listItemsPremium]);

      } */

//
//    public function paginate_next($listItems) {
//        $listItems->paginate(15);
//    }
//    
    //******************************* Start les search **************************
    

    public function search_titre($titre) {
        if ($titre === "touts") {
            $listItems = \App\Product::where('active', '=', 1)
                     ->orderBy('id', 'DESC')->paginate(10);
            
        } else {
            $listItems = \App\Product::where('titre', 'like', '%' . $titre . '%')
                     ->orderBy('id', 'DESC')->paginate(10);
            
        }
        $listPremeom = \App\Product::orderBy('is_premium', 'DESC')->limit(14)->get();
        return view('products.listeOffres', ['products' => $listItems, 'premium_products' => $listPremeom]);
    }

    public function search_ville($ville) {
        $listItems = \App\Product::where('id_ville', '=', $ville)
                        ->where('active', '=', 1)
                 ->orderBy('id', 'DESC')->paginate(10);
        $listPremeom = \App\Product::orderBy('is_premium', 'DESC')->limit(14)->get();
        return view('products.listeOffres', ['products' => $listItems, 'premium_products' => $listPremeom]);
    }
     public function searchAll($titre, $id_category) {
        if ($titre === "touts") {
            $listItems = \App\Product::where('active', '=', 1)
                            ->where('id_category', '=', $id_category)
                            ->orderBy('id', 'DESC')->paginate(10);
        } else {
            $listItems = \App\Product::where('titre', 'like', '%' . $titre . '%')
                            ->where('active', '=', 1)
                            ->where('id_category', '=', $id_category)
                            ->orderBy('id', 'DESC')->paginate(10);
        }
        $listPremeom = \App\Product::orderBy('is_premium', 'DESC')->limit(14)->get();

        return view('products.listeOffres', ['products' => $listItems, 'premium_products' => $listPremeom]);
    }
    
    
    public function prodct_category($category) {
        $type = $category;
        $val_1 = 0;
        $val_2 = 0;
        switch ($type) {
            case "Immobilier":
                $val_1 = 1000;
                $val_2 = 1999;
                break;
            case "Vehicules":
                $val_1 = 2000;
                $val_2 = 2999;
                break;
            case "Maison":
                $val_1 = 3000;
                $val_2 = 3999;
                break;
            case "Informatique":
                $val_1 = 4000;
                $val_2 = 4999;
                break;
            case "EmploiServices":
                $val_1 = 5000;
                $val_2 = 5999;
                break;
            case "loisirsDivertissement":
                $val_1 = 6000;
                $val_2 = 6999;
                break;
            case "location-de-voiture":
                $val_1 = 10004;
                $val_2 = 10004;
                break;
            case "evénments-traiteurs":
                $val_1 = 11002;
                $val_2 = 11002;
                break;
        }
        $listItems = \App\Product::whereBetween('id_category', [$val_1, $val_2])
                        ->orderBy('is_premium', 'DESC')->paginate(10);
        ;
        $listPremeom = \App\Product::orderBy('is_premium', 'DESC')->limit(14)->get();
        return view('products.listeOffres', ['products' => $listItems, 'premium_products' => $listPremeom]);
    }

    //******************************** End les search **************************



    public function welcome() {
        $listItems = \App\Product::orderBy('is_premium', 'DESC')->limit(14)->get();
        $items_1 = $listItems->splice(0, 4);
        $items_2 = $listItems->splice(0, 4);
        return view('welcome', ['products_1' => $items_1, 'products_2' => $items_2]);
    }

    public function ProductsClient() {
        if (Auth::user()) {
            $id_client = Auth::user()->id;
            $listItems = \App\Product::where('id_client', '=', $id_client)->paginate(8);
            return view('client.espace_client')->withProducts($listItems);
        } else {
            return view('auth.login');
        }
    }

    public function liste_product($id) {
        $listItems = \App\Product::where('id_ville', '=', $id)
                        ->orderBy('is_premium', 'DESC')->get();

        $listPremeom = \App\Product::orderBy('is_premium', 'DESC')->limit(14)->get();

        return view('products.listeOffres', ['products' => $listItems, 'premium_products' => $listPremeom]);
    }

   

}

?>