<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SecteurController extends Controller
{
    //
    
      public function sectuer(Request $request) {
         $id = $request->id_ville;

          $listSectuer = \App\Secteur::where('id_ville', '=', $id)->get();
         
        return  $listSectuer;
    }
    
    
     public function model(Request $request) {
         $id = $request->id_marque;

          $listModel = \App\Model_marque_vehicule::where('id_marque', '=', $id)->get();
         
        return  $listModel;
    }
    
    
    public function marque() {
       
          $listMarque = \App\Marque_vehicule::all();
         
        return  $listMarque;
    } 
    
    
    
    
    
}
