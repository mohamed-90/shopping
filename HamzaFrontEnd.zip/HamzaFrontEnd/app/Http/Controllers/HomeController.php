<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('welcome');
    }
    
//       public function index()
//    {
//        $listItems = \App\Product::orderBy('is_premium', 'DESC')->limit(8)->get();
//        $items_1 =  $listItems->splice(0, 4);
//        $items_2 = $listItems->splice(0, 4);
//        
//        return view('welcome', ['products_1' => $items_1, 'products_2' => $items_2]);
//    }
    
 
}
