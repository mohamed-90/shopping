<html>
    <head>
        <title>Hamza</title>
        <meta charset="${encoding}">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/bootstrap.min.css')}}"/>
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">

    <body style="background: #e1e1ea">
        <div id='up_menu' style='height: 360px; width: 100%;  text-align: center; display: inline-block;'>
            <img src="{{asset('images/appImages/PUB1.JPG')}}" alt="" style="width: 30%; height: 350px">
            <img src="{{asset('images/appImages/PUB2.JPG')}}" alt="" style="width: 30%; height: 350px">
            <img src="{{asset('images/appImages/PUB3.jpg')}}" alt="" style="width: 30%; height: 350px">
        </div>
             <!-- Trigger the modal with a button -->
                <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button>

                <!-- Modal -->
                <div id="myModal" class="modal fade" role="dialog">
                    <div class="modal-dialog">

                        <!-- Modal content-->
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title">Modal Header</h4>
                            </div>
                            <div class="modal-body">
                                <p>Some text in the modal.</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            </div>
                        </div>

                    </div>
                </div>
        <div class="container" style="z-index: 100">
            @include('partials.header')
            <br/>
            @include('partials.search_menu')
            <hr>
             @include('recherchVehicule')
            <div class="row">
                <div class="col" style="text-align: center">
                    <h3>CHOISIR UNE CATEGORIE</h3>
                </div>
            </div>
            <div class="row">
                <div class="col-sm">      
                    <div class="card bg-light mb-3" style="text-align: center">                                

                        <div class="card-body">
                            <img src="{{asset('images/appImages/vehicule.PNG')}}" alt="" style="width: 150px; height: 90px">
                            <a href="{{url('/offres/Vehicules')}}"> <h5 class="card-title" style="text-align: center" >Vehicules</h5></a>

                        </div>
                    </div>
                </div>
                <div class="col-sm">  
                    <div class="card bg-light mb-3" style="text-align: center"> <!--style="width: 16rem;text-align: center"-->                               

                        <div class="card-body">
                            <img src="{{asset('images/appImages/imobiler.PNG')}}" alt="" style="width: 150px; height: 90px">
                            <a href="{{url('/offres/Immobilier')}}"> <h5 class="card-title" style="text-align: center" >Immobilier</h5></a>

                        </div>
                    </div></div>
                <div class="col-sm">  
                    <div class="card bg-light mb-3" style="text-align: center">                                

                        <div class="card-body">
                            <img src="{{asset('images/appImages/maison3.JPG')}}" alt="" style="width: 150px; height: 90px">
                            <a href="{{url('/offres/Maison')}}"> <h5 class="card-title" style="text-align: center" >Maison</h5></a>
                        </div>
                    </div>
                </div>
                <div class="col-sm">          
                    <div class="card bg-light mb-3" style="text-align: center">                                

                        <div class="card-body">
                            <img src="{{asset('images/appImages/informatique.JPG')}}" alt="" style="width: 150px; height: 90px">
                            <a href="{{url('/offres/Informatique')}}"> <h5 class="card-title" style="text-align: center" >Informatique</h5></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">     
                <div class="col-sm">
                    <div class="card bg-light mb-3" style="text-align: center">                                

                        <div class="card-body">
                            <img src="{{asset('images/appImages/loisir.png')}}" alt="" style="width: 150px; height: 90px">
                            <a href="{{url('/offres/loisirsDivertissement')}}"> <h5 class="card-title" style="text-align: center" >Loisirs & Divers</h5></a>
                        </div>
                    </div>
                </div>
                <div class="col-sm">  
                    <div class="card bg-light mb-3" style="text-align: center">                                

                        <div class="card-body">
                            <img src="{{asset('images/appImages/emploie.png')}}" alt="" style="width: 150px; height: 90px">
                            <a href="{{url('/offres/EmploiServices')}}"> <h5 class="card-title" style="text-align: center" >Emploi et Services</h5></a>
                        </div>
                    </div>
                </div>
                <div class="col-sm">
                    <div class="card bg-light mb-3" style="text-align: center">                                


                        <div class="card-body">
                            <img src="{{asset('images/appImages/car.png')}}" alt="" style="width: 150px; height: 90px">
                            <a href="{{url('/offres/location-de-voiture')}}"> <h5 class="card-title" style="text-align: center" >Location de voitures</h5></a>
                        </div>
                    </div>
                </div>
                <div class="col-sm">
                    <div class="card bg-light mb-3" style="text-align: center">                                


                        <div class="card-body">
                            <img src="{{asset('images/appImages/serveurs.jpg')}}" alt="" style="width: 150px; height: 90px">
                            <a href="{{url('/offres/evénments-traiteurs')}}"> <h5 class="card-title" style="text-align: center" >Evénments & Traiteurs</h5></a>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div class="container">
            <hr>
            <div class="row"  style=""> 
                <div  style="width: 70%;  padding: 10 10 10 10">
                    <div class="row">
                        <div class="col" style="text-align: left">
                            <h5>Nous vous recommandons:</h5>
                        </div>
                    </div>
                    <div class="row" style=" padding: 0 10 0 10;">
                        @foreach($products_1 as $product)
                        <div class="col-sm" style=" padding: 5 5 5 5;">      
                            <div class="card bg-light mb-3" style="text-align: center; ">                                
                                <div class="card-body" style="text-align: center; padding: 15 5 5 5;">                                   
                                    <img src="{{asset('images/' . $product->id_client.'/' . $product->id.'/'.$product->photo_default)}}" alt="" style="width: 150px; height: 90px">
                                    <h6 class="card-title" style="margin: 5 0 5 0" >{{number_format($product->price, 2)}}&nbsp;DH</h6>
                                    <a  href="{{url('/offres/affiche/'. $product->id)}}" style="color: black">{{$product->titre}}</a>
                                </div>
                            </div>
                        </div>                       
                        @endforeach       
                    </div>
                    <div class="row" style=" padding: 0 10 0 10;">
                        @foreach($products_2 as $product)
                        <div class="col-sm" style=" padding: 5 5 5 5;">      
                            <div class="card bg-light mb-3" style="text-align: center; ">                                
                                <div class="card-body" style="text-align: center; padding: 15 5 5 5;">                                   
                                    <img src="{{asset('images/' . $product->id_client.'/' . $product->id.'/'.$product->photo_default)}}" alt="" style="width: 150px; height: 90px">
                                    <h6 class="card-title" style="margin: 5 0 5 0" >{{number_format($product->price, 2)}}&nbsp;DH</h6>
                                    <a  href="{{url('/offres/affiche/'. $product->id)}}" style="color: black">{{$product->titre}}</a>
                                </div>
                            </div>
                        </div>                       
                        @endforeach       
                    </div>

                </div>
                <div  style="width: 30%;">
                    <div  style="text-align: center">
                        <h2>  Sélectionner une ville</h2>
                    </div>
                    <div class="row" style="padding: 10 10 10 80"> 
                        <ul style="list-style-type:circle">
                            <li>* <a id="1"  href="{{url('/search_ville/'. 1)}}">Agadir</a></li>                          
                            <li>* <a  id="2" href="{{url('/search_ville/'. 2)}}">Al Hoceïma</a></li>                           
                            <li>* <a  id="3" href="{{url('/search_ville/'. 3)}}">Béni Mellal</a></li>
                            <li>* <a  id="4" href="{{url('/search_ville/'. 4)}}">Casablanca</a></li>
                            <li>* <a id="5"  href="{{url('/search_ville/'. 5)}}">El Jadida</a></li>
                            <li>* <a  id="6" href="{{url('/search_ville/'. 6)}}">Errachidia</a></li>
                            <li>* <a  id="7" href="{{url('/search_ville/'. 7)}}">Fès</a></li>
                            <li>* <a  id="8" href="{{url('/search_ville/'. 8)}}">Kénitra</a></li>
                            <li>* <a  id="9" href="{{url('/search_ville/'. 9)}}">Khénifra</a></li>
                            <li>* <a id="10"  href="{{url('/search_ville/'. 10)}}">Khouribga</a></li>
                            <li>* <a id="11"  href="{{url('/search_ville/'. 11)}}">Larache</a></li>
                            <li>* <a  id="12" href="{{url('/search_ville/'. 12)}}">Marrakech</a></li>  
                            <li>* <a id="13"  href="{{url('/search_ville/'. 13)}}">Meknès</a></li>
                            <li>* <a  id="14" href="{{url('/search_ville/'. 14)}}">Nador</a></li>
                        </ul>  
                        <ul style="list-style-type:circle">                                                        
                            <li>* <a id="15"  href="{{url('/search_ville/'. 15)}}">Ouarzazate</a></li>
                            <li>* <a  id="16" href="{{url('/search_ville/'. 16)}}">Oujda</a></li>
                            <li>* <a  id="17" href="{{url('/search_ville/'. 17)}}">Rabat</a></li>
                            <li>* <a id="18"  href="{{url('/search_ville/'. 18)}}">Safi</a></li>
                            <li>* <a  id="19" href="{{url('/search_ville/'. 19)}}">Settat</a></li>
                            <li>* <a  id="20" href="{{url('/search_ville/'. 20)}}">Salé</a></li>
                            <li>* <a id="21"  href="{{url('/search_ville/'. 21)}}">Tanger</a></li>
                            <li>* <a  id="22" href="{{url('/search_ville/'. 22)}}">Taza</a></li>
                            <li>* <a  id="23" href="{{url('/search_ville/'. 23)}}">Tétouan</a></li>
                            <li>* <a  id="24" href="{{url('/search_ville/'. 24)}}">Sebta</a></li>
                            <li>* <a  id="25" href="{{url('/search_ville/'. 25)}}">Melilla</a></li>
                            <li>* <a  id="25" href="{{url('/search_ville/'. 26)}}">Martil/M'diq/Fnideq</a></li>
                            <li>* <a  id="25" href="{{url('/search_ville/'. 27)}}">Chefchaouen</a></li>
                            <li>* <a id="0"  href="{{url('/search_ville/'. 0)}}">&gt; Autre ville...</a></li>
                        </ul> 
                    </div>

                </div>
            </div>
            <div class="row"> 
                <div  style="text-align: center">
                    <h2>  </h2>
                </div>
            </div>
            <hr>
        </div>

        @include('partials.footer')
        <script src="{{asset('assets/css/jquery-3.3.1.min.js')}}" type="text/javascript"></script>
       <script src="{{asset('assets/js/bootstrap.min.js')}}" type="text/javascript"></script>
        <script src="{{asset('js/commands.js')}}" type="text/javascript"></script>
        <script src="{{asset('js/vue.js')}}" ></script>
        <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    </body>
</html>

