<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Espace client</title>
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <!-- Bootstrap core CSS -->
        <link href="{{asset('assets/mdB/css/bootstrap.min.css')}}" rel="stylesheet">
        <!-- Material Design Bootstrap -->
        <link href="{{asset('assets/mdB/css/mdb.min.css')}}" rel="stylesheet">
        <!-- Your custom styles (optional) -->
        <link href="{{asset('assets/mdB/css/style.css')}}" rel="stylesheet">
    </head>
    <style>
/*        .tab-pane {
 background-image: url("images/images.jpg");
        }*/
    </style>
    
    <body>
        <div style="height: 100vh">
            <nav class="mb-1 navbar navbar-expand-lg navbar-dark info-color">
                <a class="navbar-brand" href="{{url('/')}}">LOGO</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-4" aria-controls="navbarSupportedContent-4" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent-4">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link waves-effect waves-light" href="{{url('/espace')}}">
                                <i class="fa fa-envelope"></i> Contact
                                <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link waves-effect waves-light" href="#">
                                <i class="fa fa-gear"></i> Settings</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle waves-effect waves-light" id="navbarDropdownMenuLink-4" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fa fa-user"></i> {{ Auth::user()->name }} </a>
                            <div class="dropdown-menu dropdown-menu-right dropdown-info" aria-labelledby="navbarDropdownMenuLink-4">
                                <a class="dropdown-item waves-effect waves-light" href="{{ route('login') }}">Change account</a>
                                <a class="dropdown-item" href="{{ route('logout') }}"
                       onclick="event.preventDefault();
                                       document.getElementById('logout-form').submit();"><i class="icon-switch2"></i> 
                        {{ __('Logout') }}
                    </a>
                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                        @csrf
                    </form>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
            <div class="row">
                <div  style="width: 10%; background: #00141a; padding: 10px 10px 10px 10px; min-width: 100px">
                    <div  class="navi">
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item" style="width: 100%; height: 80px">
                                    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true"><i class="fa fa-tasks" aria-hidden="true"></i> <span class="hidden-xs hidden-sm"> Mes Annonce</span></a>
                                </li>
                                <li class="nav-item" style="width: 100%; height: 80px">
                                    <a class="nav-link" id="pro-tab" data-toggle="tab" href="#pro" role="tab" aria-controls="pro" aria-selected="false"><i class="fa fa-bar-chart" aria-hidden="true"></i><span class="hidden-xs hidden-sm"> Statistics</span></a>
                                </li>
                                <li class="nav-item" style="width: 100%; height: 80px">
                                    <a class="nav-link" id="messages-tab" data-toggle="tab" href="#messages" role="tab" aria-controls="messages" aria-selected="false"><i class="fa fa-calendar" aria-hidden="true"></i><span class="hidden-xs hidden-sm"> Calender</span></a>
                                </li>
                                <li class="nav-item" style="width: 100%; height: 80px">
                                    <a class="nav-link" id="settings-tab" data-toggle="tab" href="#settings" role="tab" aria-controls="settings" aria-selected="false"><i class="fa fa-cog" aria-hidden="true"></i><span class="hidden-xs hidden-sm"> Réblages</span></a>
                                </li>
                            </ul>
                        </div>
                </div>
                <div  style="width: 90%; padding: 10px 10px 10px 0px">
                    <hr>
                    <div class="tab-content" >
                        <div class="tab-pane active" id="home" role="tabpanel" aria-labelledby="home-tab">
                            @include('client.mes_annonce')
                        </div>
                        <div class="tab-pane" id="pro" role="tabpanel" aria-labelledby="pro-tab">
                            @include('categorys.EmploiService.Stages')
                        </div>
                        <div class="tab-pane" id="messages" role="tabpanel" aria-labelledby="messages-tab">
                            @include('categorys.EmploiService.OffreDemploi')
                        </div>
                        <div class="tab-pane" id="settings" role="tabpanel" aria-labelledby="settings-tab">
                            @include('categorys.EmploiService.Stages')
                            @include('categorys.EmploiService.Stages')
                            @include('categorys.EmploiService.Stages')
                        </div>
                    </div>
                </div>

                <script>
                    $(function () {
                        $('#myTab li:last-child a').tab('show')
                    })
                </script>
            </div>
            <!-- Footer -->
<footer class="page-footer font-small cyan darken-3">

    <!-- Footer Elements -->
    <div class="container">

      <!-- Grid row-->
      <div class="row">

        <!-- Grid column -->
        <div class="col-md-12 py-5">
          <div class="mb-5 flex-center">

            <!-- Facebook -->
            <a class="fb-ic">
              <i class="fa fa-facebook fa-lg white-text mr-md-5 mr-3 fa-2x"> </i>
            </a>
            <!-- Twitter -->
            <a class="tw-ic">
              <i class="fa fa-twitter fa-lg white-text mr-md-5 mr-3 fa-2x"> </i>
            </a>
            <!-- Google +-->
            <a class="gplus-ic">
              <i class="fa fa-google-plus fa-lg white-text mr-md-5 mr-3 fa-2x"> </i>
            </a>
            <!--Linkedin -->
            <a class="li-ic">
              <i class="fa fa-linkedin fa-lg white-text mr-md-5 mr-3 fa-2x"> </i>
            </a>
            <!--Instagram-->
            <a class="ins-ic">
              <i class="fa fa-instagram fa-lg white-text mr-md-5 mr-3 fa-2x"> </i>
            </a>
            <!--Pinterest-->
            <a class="pin-ic">
              <i class="fa fa-pinterest fa-lg white-text fa-2x"> </i>
            </a>
          </div>
        </div>
        <!-- Grid column -->

      </div>
      <!-- Grid row-->

    </div>
    <!-- Footer Elements -->

    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2018 Copyright:
      <a href="#"> MDBootstrap.com</a>
    </div>
    <!-- Copyright -->

  </footer>
  <!-- Footer -->
        </div>

        <script type="text/javascript" src="{{asset('assets/mdB/js/jquery-3.3.1.min.js')}}"></script>

        <script type="text/javascript" src="{{asset('assets/mdB/js/popper.min.js')}}"></script>

        <script type="text/javascript" src="{{asset('assets/mdB/js/bootstrap.min.js')}}"></script>

        <script type="text/javascript" src="{{asset('assets/mdB/js/mdb.min.js')}}"></script>
    </body>

</html>