<div class="container" style="padding: 50px 50px 50px 50px">    
    <!--Table-->
    <div class="row">
        <div class="col-md-12">
            <table id="tablePreview" class="table table-hover table-striped table-bordered">
                <thead>
                <th>Nomber d'annonce</th>
                <th>Title</th>
                <th>description</th>
                <th>prix</th>
                <th>Created At</th>                                     
                </thead>
                <tbody>
                    <?php $cout = 1; ?>
                    @foreach ($products as $product)

                    <tr scope="row">
                        <th>{{ $cout}}</th>						
                        <td>{{ $product->titre }}</td>
                        <td>{{ substr($product->description, 0, 50) }}{{ strlen($product->description) > 50 ? "..." : "" }}</td>
                        <td>{{ date('M j, Y', strtotime($product->created_at)) }}</td>
                        <td>
                            <a href="#"  class="btn btn-primary btn-sm" data-toggle="modal" data-target="#basicExampleModal" >View</a>
                            <a href="#" class="btn btn-default btn-sm" data-toggle="modal" data-target="#editModal" >Edit</a>
                            <a href="#" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#modalConfirmDelete">Supprimer</a>
                        </td>
                    </tr>
                    <?php $cout++; ?>
                    @endforeach

                </tbody>
            </table>
        </div>
        <hr>
        <div style=" text-align: center">{!! $products->links(); !!}</div>
        <hr> 
    </div>
    <script>
        // popovers Initialization
        $(function () {
            $('[data-toggle="popover"]').popover()
        })

        $('#exampleModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget) // Button that triggered the modal
            var recipient = button.data('whatever') // Extract info from data-* attributes
            // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
            // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
            var modal = $(this)
            modal.find('.modal-title').text('New message to ' + recipient)
            modal.find('.modal-body input').val(recipient)
        })
    </script>
    <!--Table-->
</div>
<div class="modal fade" id="basicExampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-fluid modal-notify modal-success" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                ...
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>                     
<div class="modal fade" id="modalConfirmDelete" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm modal-notify modal-danger" role="document">
        <div class="modal-content text-center">
            <div class="modal-header d-flex justify-content-center">
                <p class="heading"> are you sre?</p>
            </div>
            <div class="modal-body">
                <i class="fa fa-times fa-4x animated rotateIn"></i>
            </div>
            <div class="modal-footer flex-center">
                <a href="#" class="btn btn-outline-danger waves-effect waves-light">Yes</a>
                <a type="button" class="btn btn-danger waves-effect" data-dismiss="modal">No</a>
            </div>
        </div>
    </div>
</div>