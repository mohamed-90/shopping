<html>
    <head>
        <title>Déposez une annonce</title>
        <meta charset="${encoding}">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </head>
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/bootstrap.min.css')}}"/>

    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">

    <link href="{{asset('assets/css/bootstrap-fileupload.min.css')}}" rel="stylesheet" />
    <!--CUSTOM BASIC STYLES-->
    <link href="{{asset('assets/css/basic.css')}}" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="{{asset('assets/css/custom.css')}}" rel="stylesheet" />
    <body style="background: #e1e1ea">

        <div class="container" id="app">
            @include('partials.header')            
            <br>
            <button style=" display: none" type="button" id="mdl" class="btn btn-primary" data-toggle="modal" data-target="#uploadModal" data-whatever="@mdo" >Open</button>
            <div style="width: 100%; height: 100%; background-image: url('{{asset('images/appImages/loader.gif')}}'); background-position: center;  background-repeat: no-repeat; background-attachment: fixed;" class="modal fade" id="uploadModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            </div>
            <form v-on:submit.prevent="validateForm('fortest')" data-vv-scope="fortest">
                <div class="card">
                    <h6 class="card-header">Créez votre annonce</h6>            
                    <div class="card-body">
                        <div class="form-group row">
                            <label for="exampleFormControlSelect1" class="col-sm-2" >Catégorie</label>
                            <select class="form-control" id="exampleFormControlSelect1" @change="onChange()" style="max-width: 220px; width: 220px;" v-model="product.id_category">
                                <option value="11001">Prestation de services</option>
                                <option value="11002">Billetterie</option>
                                <option value="11003">Evenement st traiteurs</option>
                                <option value="11004">Cours particuliers</option>
                                <option value="11005">Covoiturages</option>
                            </select>     
                        </div>

                        @include('partials.product.c_Ville')

                        <div class="form" id="form_11001" >
                            @include('categorys.Entreprises1.entreprises_div')
                        </div>
                        <div class="form" id="form_11002" style="display: none;">
                            @include('categorys.Entreprises1.entreprises_div') 
                        </div>
                        <div class="form" id="form_11003" style="display: none;">
                            @include('categorys.Entreprises1.entreprises_div')
                        </div>
                        <div class="form" id="form_11004" style="display: none;">
                            @include('categorys.Entreprises1.entreprises_div')
                        </div>
                         <div class="form" id="form_11005" style="display: none;">
                            @include('categorys.Entreprises1.entreprises_div')
                        </div>
                    </div>
                </div>
                <br>
                @include('partials.product.VosCoordonnees')
                <button type="submit" id='Annonce'  style="float: right; display: none" >send</button>
            </form>

            @include('partials.product.A_Photos')
            <br>
            <button class="btn btn-primary" id='poublie'  style="float: right">Publier mon annonce</button>
            <br>
            <br>
        </div>

        <script src="{{asset('assets/css/jquery-3.3.1.min.js')}}" type="text/javascript"></script>
        <script src="{{asset('assets/js/bootstrap.min.js')}}" type="text/javascript"></script>
        @include('partials.footer')
    </body>


    <script src="{{asset('js/vue.js')}}" ></script>
    <script src="{{asset('js/veeValidate.js')}}" ></script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>

    <script>
Vue.use(VeeValidate);

window.Laravel = {!! json_encode([
        'csrfToken' => csrf_token(),
//    'idProduct' => $id_product,
'url' => url('/')
]) !!}
;
    </script>
    <script src="{{asset('js/index.js')}}"></script>

</html>