<div  style="background: white; padding: 15px" >
    <style>
        .styled-select {
            background: url(http://i62.tinypic.com/15xvbd5.png) no-repeat 96% 0;
            height: 29px;
            overflow: hidden;
            width: 160px;
        }
        .styled-select select {
            background: transparent;
            border: none;
            font-size: 14px;
            height: 29px;
            padding: 5px; /* If you add too much padding here, the options won't show in IE */
            width: 188px;
        }
        .styled-select.slate {
            background: url(http://i62.tinypic.com/2e3ybe1.jpg) no-repeat right center;
            height: 34px;
            width: 160px;
        }
        .styled-select.slate select {
            border: 1px solid #ccc;
            font-size: 16px;
            height: 34px;
            width: 188px;
        }

    </style>
    <div class="row">
        <div class="col-md-3 ">
            <input class="form-control"  aria-describedby="emailHelp" name="titre" value=""  size="20" id="titre" type="text" placeholder="Prix max">
        </div>
        <div class="col-md-3 ">
            <input class="form-control"  aria-describedby="emailHelp" name="titre" value=""  size="20" id="titre" type="text" placeholder="Prix min">
        </div>
        <div class="col-md-3 ">
            <input class="form-control"  aria-describedby="emailHelp" name="titre" value=""  size="20" id="titre" type="text" placeholder="Recherche...">
        </div>
        <div class="col-md-3 " style=" text-align: center">
            <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
            <label class="form-check-label" for="defaultCheck1">
                Avec photos
            </label>
            <button type="button" id="sarche" class="btn btn-outline-danger" style="width: 100px" v-on:click="searchProduct" >Rechercher</button>
        </div>     
    </div>
    <br>
    <div class="row">
        <div class="col-md-2">
            <div class="styled-select slate">
                <select>
                    <option>first option</option>
                    <option>The second option</option>
                    <option>The third option</option>
                </select>
            </div> 

        </div>   
        <div class="col-md-2">
            <div class="styled-select slate">
                <select>
                    <option>first option</option>
                    <option>The second option</option>
                    <option>The third option</option>
                </select>
            </div> 

        </div>
        <div class="col-md-2">
            <div class="styled-select slate">
                <select>
                    <option>first option</option>
                    <option>The second option</option>
                    <option>The third option</option>
                </select>
            </div> 

        </div>
        <div class="col-md-2">
            <div class="styled-select slate">
                <select>
                    <option>first option</option>
                    <option>The second option</option>
                    <option>The third option</option>
                </select>
            </div> 

        </div>
        <div class="col-md-2">
            <div class="styled-select slate">
                <select>
                    <option>first option</option>
                    <option>The second option</option>
                    <option>The third option</option>
                </select>
            </div> 

        </div>
        <div class="col-md-2">
            <div class="styled-select slate">
                <select>
                    <option>first option</option>
                    <option>The second option</option>
                    <option>The third option</option>
                </select>
            </div> 

        </div>
    </div> 
    <br>
    <div class="row">
        <div class="col-md-2">
            <div class="styled-select slate">
                <select>
                    <option>first option</option>
                    <option>The second option</option>
                    <option>The third option</option>
                </select>
            </div> 

        </div>   
        <div class="col-md-2">
            <div class="styled-select slate">
                <select>
                    <option>first option</option>
                    <option>The second option</option>
                    <option>The third option</option>
                </select>
            </div> 

        </div>
        <div class="col-md-2">
            <div class="styled-select slate">
                <select>
                    <option>first option</option>
                    <option>The second option</option>
                    <option>The third option</option>
                </select>
            </div> 

        </div>
        <div class="col-md-2">
            <div class="styled-select slate">
                <select>
                    <option>first option</option>
                    <option>The second option</option>
                    <option>The third option</option>
                </select>
            </div> 

        </div>
        <div class="col-md-2">
            <div class="styled-select slate">
                <select>
                    <option>first option</option>
                    <option>The second option</option>
                    <option>The third option</option>
                </select>
            </div> 

        </div>
        <div class="col-md-2">
            <div class="styled-select slate">
                <select>
                    <option>first option</option>
                    <option>The second option</option>
                    <option>The third option</option>
                </select>
            </div> 

        </div>
    </div>
</div>


