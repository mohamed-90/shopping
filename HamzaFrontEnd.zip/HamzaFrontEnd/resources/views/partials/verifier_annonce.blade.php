<html>
    <head>
        <title>annonce</title>
        <meta charset="${encoding}">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </head>
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/bootstrap.min.css')}}"/>

    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <body>

        <div class="container" id="app">

            @include('partials.header')
            {{csrf_field()}}
            <br>
            
            <div class="container">
                <div class="row text-center">
                    <div class="col-md-12 set-pad" >
                        <strong class="error-txt">ERROR ! 404</strong>
                        <p class="p-err">Lorem ipsum dolor sit amet posuere lectus et, fringilla augue.</p>
                        <a href="index.html" class="btn btn-danger" ><i class="fa fa-mail-reply"></i>&nbsp;PLEASE GO BACK</a>
                    </div>
                </div>
            </div>
            <div class="c-err">
                <div class="container">
                    <!--Search Section Start-->
                    <div class="row ">
                        <div class="form-group input-group col-md-6 col-md-offset-3">
                            <input type="text" class="form-control" placeholder="Enter Keywords" />
                            <span class="input-group-btn">
                                <a class="btn btn-primary" href="index.html">
                                    <i class="fa fa-gear fa-spin"></i>&nbsp;&nbsp;SEARCH HERE
                                </a>
                            </span>
                        </div>
                        <br />

                    </div>
                    <!--Search Section end-->
                </div>
            </div>
            <div class="container">
                <div class="row text-center">
                    <div class="col-md-12">
                        <br />
                        <br />
                        <a class="btn btn-success" href="index.html">
                            PLEASE GO BACK TO WEBSITE ! NOTHING HERE
                        </a>
                        <br />
                        <br />
                    </div>

                </div>
            </div>
            <hr />
        </div>

        <script src="{{asset('assets/css/jquery-3.3.1.min.js')}}" type="text/javascript"></script>
        <script src="{{asset('assets/js/bootstrap.min.js')}}" type="text/javascript"></script>
        @include('partials.footer')
    </body>

    <script src="{{asset('js/vue.js')}}" ></script>
    <script src="{{asset('js/veeValidate.js')}}" ></script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>

    <script>

Vue.use(VeeValidate);

window.Laravel = {!! json_encode([
        'csrfToken' => csrf_token(),
//    'idProduct' => $id_product,
'url' => url('/')
]) !!}
;
    </script>
    <script src="{{asset('js/index.js')}}"></script>


</html>   
