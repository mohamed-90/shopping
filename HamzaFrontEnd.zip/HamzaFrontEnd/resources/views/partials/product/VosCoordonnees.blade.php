<div>
    <div class="card">
        <h6 class="card-header"><i class="far fa-address-card mr-2"></i>Vos coordonnées</h6>
        <div class="card-body">
            <div class="form-group row">
                <label for="exampleFormControlSelect1" class="col-sm-2" >Vous êtes un *</label>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="type_client" id="inlineRadio1" value="0" v-model="user.type_client">
                    <label class="form-check-label" for="inlineRadio1">Particulier</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="type_client" id="inlineRadio2" value="1" v-model="user.type_client">
                    <label class="form-check-label" for="inlineRadio2">Professionnel</label>
                </div>

                <hr class="input-xxlarge">
            </div>
            <hr>
            <div class="form-group row">
                <label for="edtNom" class="col-sm-2" >Nom </label>
                <input type="text" name="name" v-validate="'required'" class="form-control" id="edtNom" placeholder="Nom" style="width: 270px" v-model="user.name" maxlength="100" required>
                <label class="control-label" style="color: red"  v-show="errors.has('fortest.name')">@{{ errors.first('fortest.name')}}</label>  
            </div>
            <div class="form-group row">                           
                <label for="email" class="col-sm-2">Email </label>
                <input type="email" class="form-control" v-validate="'required|email'" id="email" name="email" aria-describedby="emailHelp" placeholder="Enter email" style="width: 270px" maxlength="100" v-model="user.email">
                <label class="control-label" style="color: red"  v-show="errors.has('fortest.email')">@{{ errors.first('fortest.email')}}</label>  
            </div>
            <div class="form-group row">
                <label for="edtPhone" class="col-sm-2" >Téléphone </label>
                <div  style="padding: 0px;width: 270px" >
                    <input type="text" name="phone" v-validate="'required|numeric'" class="form-control" id="edtPhone" placeholder="2126 00 00 00 00" v-model="user.phone" required>
                    <label class="control-label" style="color: red"  v-show="errors.has('fortest.phone')">@{{ errors.first('fortest.phone')}}</label>  
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="0" v-model="product.show_telephone" id="defaultCheck1" maxlength="50">
                        <label class="form-check-label" for="defaultCheck1">
                            Cacher numéro
                        </label>
                    </div>
                </div>             
            </div>

            <div class="form-group row">
                <div class="col-sm-2">
                    <label for="Password" >Mot de passe </label>
                    <small id="passwordHelp" class="form-text text-muted">[minimum 6 caractères]</small>
                </div>
                <input type="password" class="form-control" v-validate="'required|min:6'" name="Password" id="Password" placeholder="Entrer un mot de passe" style="width: 437px" v-model="user.password" maxlength="6">
                <label class="control-label" style="color: red"  v-show="errors.has('fortest.Password')">@{{ errors.first('fortest.Password')}}</label>  
            </div>
        </div>
    </div>

</div>        