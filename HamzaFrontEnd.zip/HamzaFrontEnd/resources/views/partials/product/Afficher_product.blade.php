<html>
    <head>
        <title>Hamza</title>
        <meta charset="${encoding}">
        <!--        <meta name="viewport" content="width=device-width, initial-scale=1.0">-->
    </head>

    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/bootstrap.min.css')}}"/>

    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">

    <body style="background: #e1e1ea">
        <div id='up_menu' style='height: 360px; width: 100%;  text-align: center; display: inline-block;'>
            <img src="{{asset('images/appImages/PUB1.JPG')}}" alt="" style="width: 30%; height: 350px">
            <img src="{{asset('images/appImages/PUB2.JPG')}}" alt="" style="width: 30%; height: 350px">
            <img src="{{asset('images/appImages/PUB3.jpg')}}" alt="" style="width: 30%; height: 350px">
        </div>
        <div class="container">
            @include('partials.header')
        </div>
        <br>
        <br>
        <div class="container" style="background: white">          
            <div class="row">               
                <div  style="width: 70%">
                    <div style="padding: 10px 10% 0px 10%">
                        <br>
                        <h2> {{$product->titre}}</h2>
                        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" style="height: 450px; ">
                            <ol class="carousel-indicators">
                                @php ($nl = 0)
                                @foreach($files as $file)
                                @if (!$file->isDot())                                
                                @if($nl === 0)
                                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                                @else
                                <li data-target="#carouselExampleIndicators" data-slide-to="{{$nl}}"></li>
                                @endif                               
                                @php (++$nl)
                                @endif
                                @endforeach 
                            </ol>                            
                            <div class="carousel-inner">                               
                                @php ($nb = 1)
                                @foreach($files as $file)
                                @if (!$file->isDot())                               
                                @if($nb === 1)
                                <div class="carousel-item active">
                                    <img class="d-block w-100" style="height: 430px; width: 100%" src="{{asset('images/' . $product->id_client . '/' . $product->id . '/' .$product->photo_default)}}" alt="First slide">
                                </div>
                                @else
                                <div class="carousel-item ">
                                    <img class="d-block w-100" style="height: 430px; width: 100%" src="{{asset('images/' . $product->id_client . '/' . $product->id . '/' .$file)}}" alt="Secand slide">
                                </div>
                                @endif                                
                                @php (++$nb)
                                @endif
                                @endforeach 
                            </div>
                            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>
                    </div>                    
                    <div style="padding: 0px 10px 0px 10px">
                        <h5> Prix: {{number_format($product->price, 0)}}&nbsp;DH</h5>
                        <hr>  
                        <div  style=" width: 100%">
                            <div class="row">   
                                <div class="col-8" style="">                               
                                    <p class="justify" > {{$product->description}} </p>
                                </div>
                                <div class="col-4" style="background: #f1f1f1; ru">
                                    @if($product->id_marque > 0)
                                    <h4></h4> <p class="justify" >Ville:  {{$product->ville->libelle}} </p>
                                    <p class="justify" >Marque: {{$product->marque_vehicule->marque}} </p>
                                    <p class="justify" >Modèle: {{$product->model_marque_vehicule->model}}</p>
                                    <p class="justify" >Type carburant: {{$product->type_carburant}} </p>
                                    <p class="justify" >Année-Modèle: {{$product->annee}}</p>
                                    <p class="justify" >Kilométrage: {{$product->km}} </p>
                                    @endif
                                    @if($product->n_pieces > 0)
                                    <p class="justify" >Ville:  {{$product->ville->libelle}} </p>
                                    <p class="justify" >Nombre de pieces: {{$product->n_pieces}} </p>
                                    <p class="justify" >Superficie: {{$product->superficie}} m²</p>
                                    @endif
                                </div>
                            </div>                                                    
                        </div>
                    </div>
                    <hr>
                    <div class="row" style=" padding: 0px 10px 0px 10px;">
                        @foreach($premium as $product)
                        <div class="col-sm" style=" padding: 5 5 5 5;">      
                            <div class="card bg-light mb-3" style="text-align: center; ">                                
                                <div class="card-body" style="text-align: center; padding: 15 5 5 5;">                                   
                                    <img src="{{asset('images/' . $product->id_client.'/' . $product->id.'/'.$product->photo_default)}}" alt="" style="width: 150px; height: 90px">
                                    <h6 class="card-title" style="margin: 5 0 5 0" >{{number_format($product->price, 2)}}&nbsp;DH</h6>
                                    <a  href="{{url('/offres/affiche/'. $product->id)}}" style="color: black">{{$product->titre}}</a>
                                </div>
                            </div>
                        </div>                       
                        @endforeach       
                    </div>
                </div>
                <div class="d-flex align-items-stretch " style="width: 30%; padding: 0 10 0 10;">
                    <div class="container" >                 
                        <div class="row card" style="background: blueviolet; text-align: center; margin: 10 3 10 3">
                            <a class="nav-link white_nav" data-toggle="modal" data-target="#exampleModal" style="color: #009F97 !important" href="#">DÉPOSER UNE ANNONCE </a>

                            <script>
                                $('#myModal').on('shown.bs.modal', function () {
                                    $('#myInput').trigger('focus')
                                })
                            </script>
                            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h3 class="modal-title" id="exampleModalLabel">Choisissez une catégorie </h3>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">                 
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="list-group" id="list-tab" role="tablist">
                                                        <a class="list-group-item list-group-item-action active" id="list-profile-list" href="{{url('Vehicules')}}" role="tab" aria-controls="profile">VEHICULES</a>
                                                        <a class="list-group-item list-group-item-action " id="list-home-list" data-toggle=""  href="{{url('Immobilier')}}" role="tab" aria-controls="home">IMMOBILIER</a>
                                                        <a class="list-group-item list-group-item-action " id="list-home-list" data-toggle=""  href="{{url('Vaconces')}}" role="tab" aria-controls="home">VACANCES</a>
                                                        <a class="list-group-item list-group-item-action" id="list-messages-list"  href="{{url('MaisonJardin')}}" role="tab" aria-controls="messages">POUR LA MAISON ET JARDIN</a>
                                                        <a class="list-group-item list-group-item-action" id="list-profile-list"  href="{{url('InformatiqueMultimedia')}}" role="tab" aria-controls="profile">INFORMATIQUE ET MULTIMEDIA</a>
                                                        <a class="list-group-item list-group-item-action" id="list-home-list"  href="{{url('LoisirsDivertissement')}}" role="tab" aria-controls="home">LOISIRS ET DIVERTISSEMENT</a>
                                                        <a class="list-group-item list-group-item-action" id="list-messages-list"  href="{{url('Emplois')}}" role="tab" aria-controls="messages">EMPLOI ET SERVICES</a>
                                                        <a class="list-group-item list-group-item-action" id="list-settings-list"  href="{{url('HabillementBienEtre')}}" role="tab" aria-controls="settings">HABILLEMENT ET BIEN ETRE</a>
                                                        <a class="list-group-item list-group-item-action" id="list-profile-list"  href="{{url('Entreprises')}}" role="tab" aria-controls="profile">ENTREPRISES</a>
                                                        <a class="list-group-item list-group-item-action" id="list-profile-list"  href="{{url('Services')}}" role="tab" aria-controls="profile">SERVICES</a>
                                                        <a class="list-group-item list-group-item-action" id="list-messages-list" href="{{url('Autres')}}" role="tab" aria-controls="messages">Autres</a>                    
                                                    </div>
                                                </div>                                   
                                            </div>
                                        </div>                          
                                    </div>
                                </div>
                            </div>                                                   
                        </div>  

                        <div class="row card" style=" height: 100%">
                             <img src="{{asset('images/appImages/PUB4.JPG')}}" alt="" style="width: 100%; height: 100%">
                        </div>                                                       
                    </div> 
                </div>
            </div>
        </div>

        @include('partials.footer')
        <script src="{{asset('assets/css/jquery-3.3.1.min.js')}}" type="text/javascript"></script>
        <script src="{{asset('assets/js/bootstrap.min.js')}}" type="text/javascript"></script>
        <script>
                                $(".list-group-item-action").on("click", function (e) {
                                    vmt.searchProduct();
                                });
        </script>
    </body>
</html>

