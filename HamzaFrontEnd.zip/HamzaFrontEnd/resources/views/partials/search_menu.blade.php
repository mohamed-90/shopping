
<style>

    ._3Vcbh{padding:10px;padding:0px;margin-top:5px;margin-top:5px;-webkit-border-radius:4px;border-radius:4px;-webkit-border-radius:.4rem;border-radius:.4rem;border:1px solid #ccc;background:#fff;position:absolute;z-index:10000;left:0;right:0}
    ._3Vcbh>div{width:20%;display:inline-block;vertical-align:top}
    ._3Vcbh>div:not(:first-child){padding-left:5px;padding-left:5px}
    ._3Vcbh>div>ul:not(:first-child){margin-top:1rem}
    ._3Vcbh>div>ul li{cursor:pointer}
    ._3Vcbh>div>ul li._1_1B4{height:30px;line-height:30px;margin-bottom:5px;text-transform:uppercase;text-align:center;background:#f2f2f2;font-family:OpenSansSemiBold,sans-serif;font-weight:600;font-size:14px;padding:0.1px;color:#369;-webkit-transition:all .3s;transition:all .3s;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}
    ._3Vcbh>div>ul li._1_1B4:hover{color:#3873bd}
    ._3Vcbh>div>ul li._11G4C{color:#f56b2a!important}    
    ._3Vcbh>div>ul li:hover{text-decoration:underline;outline:none}
    ._3Vcbh>div>ul li.tT3Ya,._3Vcbh>div>ul li.tT3Ya a,._3Vcbh>div>ul li.tT3Ya a:hover,._3Vcbh>div>ul li.tT3Ya a:visited{color:#369}
    ._3Vcbh>div>ul li.tT3Ya sup{color:#f56b2a}
    ._3Vcbh>div>ul li.tT3Ya sup:before{content:" "}
    @media (max-width:971px){.SiZLq>._3X-Yv{display:none}  }
    .tT3Ya {color: #369;}
    ._26tGy { position: absolute; right: 1rem; top: 5px;    }
    ._26tGy, ._26tGy span {line-height: 20px;    } 

    .SiZLq{position:relative}
    .SiZLq>._1CJVw.egIn7{position:relative;z-index:1;opacity:0}
    .SiZLq>._1CJVw.egIn7:focus+._3X-Yv{outline:1px solid #f56b2a}
    .SiZLq>._1CJVw option._1_1B4{text-transform:uppercase;background:#dcdcc3}
    .SiZLq>._1CJVw option[disabled]{background:#e6e6e6}
    .SiZLq ._1CJVw.egIn7{opacity:1}
    ._1etKl{position:relative;width:100%;height:38px;background:#fff;border:1px solid #ccc;border-radius:.4rem}


    ._2gTTZ{position:absolute;width:100%;height:100%;z-index:1}
    ._2gTTZ>div,._2gTTZ>select{font-size:16px;width:100%;height:100%;padding:10px;border:none;background:transparent;outline:none;-webkit-appearance:none;-moz-appearance:none;cursor:pointer}
    ._2gTTZ>div{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-align:center;-webkit-align-items:center;-ms-flex-align:center;align-items:center}

    li {display: list-item;text-align: -webkit-match-parent;   list-style: none  }
    ol, ul {margin: 0;padding: 0;list-style-type: none; list-style: none   }
    ul, menu, dir {display: block;       list-style-type: disc;       margin-block-start: 1em;margin-block-end: 1em;margin-inline-start: 0px;margin-inline-end: 0px;padding-inline-start: 10px;    }
    ._3X-Yv{position:absolute;top:0;left:0;right:0;z-index:1}
    ._2jG3V svg {width: 12px;height: 12px;  }
    ._1vK7W {  display: inline-block;}

</style>

<div id="srche">
    <div  class="row" style="font-size: 16px">

        <div class="col-md-3 ">
            <input class="form-control"  aria-describedby="emailHelp" name="titre" value=""  size="20" id="titre" type="text" placeholder="Que recherchez-vous ?">
        </div>

        <div class="col-md-3 ">
            <div data-reactid="82">
                <div class="SiZLq">
                    <div class="_1CJVw egIn7" data-qa-id="select-toggle_category">
                        <div class="_1etKl">

                            <div class="_26tGy">
                                <span class="_1vK7W _2jG3V" name="menuDown">
                                    <svg height="32" width="32" viewBox="0 0 32 32">  
                                    <path d="M0 8l16 16L32 8H0z" fill="#000">
                                    </path>
                                    </svg>
                                </span>
                            </div>

                            <div >
                                <select id="_selector" autocomplete="off" @change="searcheCatrgory()" v-model="pro.id_ctgry" style="display: none">
                                    <option  value="0">Toutes les catégories</option>

                                    <option class="_1_1B4" value="2000" >-- VEHICULES --</option>
                                    <option class="tT3Ya" value="2001">Voitures</option>
                                    <option class="tT3Ya" value="2002">Motos</option>
                                    <option class="tT3Ya" value="2003">Véhicules Professionnels</option>
                                    <option class="tT3Ya" value="2004">Nautisme</option>
                                    <option class="tT3Ya" value="2005">Equipement et piéce auto</option>
                                    <option class="tT3Ya" value="2006">Equipement et piéce nautisme</option>   
                                    <option class="tT3Ya" value="2007">Equipement et piéce motos</option>

                                    <option  class="_1_1B4" value="1000">-- IMMOBILIER --</option>
                                    <option class="tT3Ya" value="1001">Appartements</option>
                                    <option class="tT3Ya" value="1002">Maisons et Villas</option>                              
                                    <option class="tT3Ya" value="1003">Magasins, Commerces et Locaux industriels</option>
                                    <option class="tT3Ya" value="1004">Terrains et Fermes</option>
                                    <option class="tT3Ya" value="1005">Autres immobiliers</option>

                                    <option class="_1_1B4" value="10000">-- VACANCES --</option>
                                    <option class="tT3Ya" value="10001">Location et Gites</option>
                                    <option class="tT3Ya" value="10002">Hotels et Appart hotels</option>
                                    <option class="tT3Ya" value="10003">Voyages organisés</option>  
                                    <option class="tT3Ya" value="10004">Location de voitures</option>

                                    <option  class="_1_1B4" value="3000">-- POUR LA MAISON ET JARDIN --</option>
                                    <option class="tT3Ya" value="3001">Electroménager et Vaisselles</option>
                                    <option class="tT3Ya" value="3002">Ameublement et Décoration</option>
                                    <option class="tT3Ya" value="3003">Jardin et Outils de bricolage</option>

                                    <option  class="_1_1B4" value="8000">-- HABILLEMENT ET BIEN ETRE --</option>
                                    <option class="tT3Ya" value="8001">Vêtements</option>
                                    <option class="tT3Ya" value="8002">Chaussures</option>
                                    <option class="tT3Ya" value="8003">Sacs et Accessoires</option>
                                    <option class="tT3Ya" value="8004">Produits de beauté</option>
                                    <option class="tT3Ya" value="8005">Equipements pour enfant et bébé</option>
                                    <option class="tT3Ya" value="8006">Chaussures</option>
                                    <option class="tT3Ya" value="8007">Montres et Bijoux</option>

                                    <option  class="_1_1B4" value="4000">-- INFORMATIQUE ET MULTIMEDIA --</option>
                                    <option class="tT3Ya" value="4001">Téléphones</option>
                                    <option class="tT3Ya" value="4002">Image & Son</option>
                                    <option class="tT3Ya" value="4003">Ordinateurs portables</option>
                                    <option class="tT3Ya" value="4004">Jeux vidéo et Consoles</option>
                                    <option class="tT3Ya" value="4005">Ordinateurs de bureau</option>
                                    <option class="tT3Ya" value="4006">Accessoires informatique et Gadgets</option>
                                    <option class="tT3Ya" value="4007">Appareils photo et Caméras</option>
                                    <option class="tT3Ya" value="4008">Tablettes</option>
                                    <option class="tT3Ya" value="4009">Télévisions</option>

                                    <option class="_1_1B4" value="6000">-- LOISIRS --</option>
                                    <option class="tT3Ya" value="6001">Sports et Loisirs</option>
                                    <option class="tT3Ya" value="6002">Animaux</option>
                                    <option class="tT3Ya" value="6003">Jeux, Livres, consoles</option>
                                    <option class="tT3Ya" value="6004">Material de péche</option>
                                    <option class="tT3Ya" value="6005">Art et Collections</option>
                                    <option class="tT3Ya" value="6006">Instruments de Musique</option>

                                    <option class="_1_1B4" value="5000">-- EMPLOI --</option>
                                    <option class="tT3Ya" value="5001">Offres d'emploi</option>
                                    <option class="tT3Ya" value="5002">Demandes d'emploi</option>
                                    <option class="tT3Ya" value="5003">Cours et Formations</option>
                                    <option class="tT3Ya" value="5004">Stages</option>

                                    <option class="_1_1B4" value="7000">-- ENTREPRISES --</option>
                                    <option class="tT3Ya" value="7001">Matériels Professionnels</option>
                                    <option class="tT3Ya" value="7002">Business et Affaires commerciales</option>
                                    <option class="tT3Ya" value="7003">Stocks et Vente en gros</option>    

                                    <option class="_1_1B4" value="11000">-- SERVICES --</option>
                                    <option class="tT3Ya" value="11001">Prestation de services</option>
                                    <option class="tT3Ya" value="11002">Billetterie</option>
                                    <option class="tT3Ya" value="11003">Evenement st traiteurs</option>
                                    <option class="tT3Ya" value="11004">Cours particuliers</option>
                                    <option class="tT3Ya" value="11005">Covoiturages</option>
                                    <option class="_1_1B4" value="9000">-- Autres --</option>option
                                    <option class="tT3Ya" value="9000">AUTRES</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="_3X-Yv" >
                        <div class=" _1etKl" data-qa-id="select-toggle_category">
                            <div class="_26tGy">
                                <span class="_1vK7W _2jG3V" name="menuDown">
                                    <svg height="32" width="32" viewBox="0 0 32 32"><path d="M0 8l16 16L32 8H0z" fill="#000"></path></svg>
                                </span>
                            </div>
                            <div  class="_2gTTZ">
                                <div id="comboType">Toutes catégories</div>    
                            </div>    
                        </div>
                    </div>
                </div>
            </div>   
        </div>
        <div class="col-md-3 ">

            <select style="width:100%; height: 37px; border-radius: 5px" @change="onChange()" v-model="pro.id_vill">
                <option value="0">Select Ville :</option>
                <option value="1">Agadir</option>
                <option value="2">Al Hoceïma</option>
                <option value="3">Béni Mellal</option>
                <option value="4">Casablanca</option>
                <option value="5">El Jadida</option>
                <option value="6">Errachidia</option>
                <option value="7">Fès</option>
                <option value="8">Kénitra</option>
                <option value="9">Khénifra</option>
                <option value="10">Khouribga</option>
                <option value="11">Larache</option>
                <option value="12">Marrakech</option>
                <option value="13">Meknès</option>
                <option value="14">Nador</option>
                <option value="15">Ouarzazate</option>
                <option value="16">Oujda</option>
                <option value="17">Rabat</option>
                <option value="18">Safi</option>
                <option value="19">Settat</option>
                <option value="20">Salé</option>
                <option value="21">Tanger</option>
                <option value="22">Taza</option>
                <option value="23">Tétouan</option>
                <option value="24">Sebta</option>
                <option value="25">Melilla</option>                   
                <option value="26">Martil/M'diq/Fnideq</option>
                <option value="27">Chefchaouen</option>
                <option value="0">&gt; Autre ville...</option>
            </select>

        </div>
        <div class="col-md-3 ">
            <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
            <label class="form-check-label" for="defaultCheck1">
                Avec photos
            </label>
            <button type="button" id="sarche" class="btn btn-outline-danger" style="width: 100px" v-on:click="searchProduct" >Rechercher</button>
        </div>     
    </div>
    <div class="row _selector" style="position:relative; display: none">     
        <div class="_3Vcbh" style="display: flex; flex-direction: row;  box-sizing: inherit;  ">
            <div>
                <ul>
                    <li class="_11G4C _1_1B4"><a>Toutes catégories</a></li>
                </ul>
                <ul>
                    <li data-qa-id="2000"  class="_1_1B4">VEHICULES</li>
                    <li data-qa-id="2001"  class="tT3Ya">Voitures</li>
                    <li data-qa-id="2002" class="tT3Ya">Motos</li>
                    <li data-qa-id="2003" class="tT3Ya">Véhicules Professionnels</li>
                    <li data-qa-id="2004" class="tT3Ya">Nautisme</li>
                    <li data-qa-id="2005" class="tT3Ya">Equipements et pièces pour véhicules</li>
                    <li data-qa-id="2006" class="tT3Ya">Equipements et pièces pour moto</li>
                    <li data-qa-id="2007" class="tT3Ya">Equipements et pièces nautism</li>
                </ul>
                <ul>
                    <li data-qa-id="3000" class="_1_1B4">POUR LA MAISON ET JARDIN</li>
                    <li data-qa-id="3001" class="tT3Ya">Electroménager et Vaisselles</li>
                    <li data-qa-id="3002" class="tT3Ya">Ameublement et Décoration</li>
                    <li data-qa-id="3003" class="tT3Ya">Jardin et Outils de bricolage</li>
                </ul>                                            
            </div>
            <div>
                <ul>
                    <li data-qa-id="10000" class="_1_1B4">VACANCES</li>
                    <li data-qa-id="10001" class="tT3Ya">Locations &amp; Gîtes</li>
                    <li data-qa-id="10002" class="tT3Ya">Chambres d'hôtes</li>
                    <li data-qa-id="10003" class="tT3Ya">Voyages organisés</li>
                    <li data-qa-id="10004" class="tT3Ya">Location de voitures</li>
                </ul>
                <ul>
                    <li data-qa-id="1000" class="_1_1B4">IMMOBILIER</li>
                    <li data-qa-id="1001" class="tT3Ya">Appartements</li>
                    <li data-qa-id="1002" class="tT3Ya">Maisons et Villas</li>
                    <li data-qa-id="1003" class="tT3Ya">Magasins, Commerces et Locaux industriels</li>
                    <li data-qa-id="1004" class="tT3Ya">Terrains et Fermes</li>
                    <li data-qa-id="1005" class="tT3Ya">Autres immobiliers</li>
                </ul>
            </div>
            <div>
                <ul>
                    <li data-qa-id="4000" class="_1_1B4">MULTIMEDIA</li>
                    <li data-qa-id="4001" class="tT3Ya">Téléphones</li>
                    <li data-qa-id="4002" class="tT3Ya">Image & Son</li>
                    <li data-qa-id="4003" class="tT3Ya">Ordinateurs portables</li>
                    <li data-qa-id="4004" class="tT3Ya">Jeux vidéo et Consoles</li>
                    <li data-qa-id="4005" class="tT3Ya">Ordinateurs de bureau</li>
                    <li data-qa-id="4006" class="tT3Ya">Accessoires informatique et Gadgets</li>
                    <li data-qa-id="4007" class="tT3Ya">Appareils photo et Caméras</li>
                    <li data-qa-id="4008" class="tT3Ya">Tablettes</li>
                    <li data-qa-id="4009" class="tT3Ya">Télévisions</li>
                </ul>
                <ul>
                    <li data-qa-id="7000" class="_1_1B4">ENTREPRISES </li>
                    <li data-qa-id="7001" class="tT3Ya">Matériels Professionnels</li>
                    <li data-qa-id="7002" class="tT3Ya">Business et Affaires commerciales</li>
                    <li data-qa-id="7003" class="tT3Ya">Stocks et Vente en gros</li> 
                </ul>
            </div>
            <div>
                <ul>
                    <li data-qa-id="8000" class="_1_1B4">HABILLEMENT ET BIEN ETRE</li>
                    <li data-qa-id="8001" class="tT3Ya">Vêtements</li>
                    <li data-qa-id="8002" class="tT3Ya">Chaussures</li>
                    <li data-qa-id="8003" class="tT3Ya">Sacs et Accessoires</li>
                    <li data-qa-id="8004" class="tT3Ya">Produits de beauté</li>
                    <li data-qa-id="8005" class="tT3Ya">Equipements pour enfant et bébé</li>
                    <li data-qa-id="8006" class="tT3Ya">Chaussures</li>
                    <li data-qa-id="8007" class="tT3Ya">Montres et Bijoux</li>
                </ul>
                <ul>
                    <li data-qa-id="6000" class="_1_1B4">LOISIRS</li>
                    <li data-qa-id="6001" class="tT3Ya">Sports et Loisirs</li>
                    <li data-qa-id="6002" class="tT3Ya">Animaux</li>
                    <li data-qa-id="6003" class="tT3Ya">Jeux, Livres, consoles</li>
                    <li data-qa-id="6004" class="tT3Ya">Material de péche</li>
                    <li data-qa-id="6005" class="tT3Ya">Art et Collections</li>
                    <li data-qa-id="6006" class="tT3Ya">Instruments de Musique</li>
                </ul>
            </div>
            <div>
                <ul>
                    <li data-qa-id="5000" class="_1_1B4">EMPLOI</li>
                    <li data-qa-id="5001" class="tT3Ya">Offres d emploi</li>
                    <li data-qa-id="5002" class="tT3Ya">Demandes d emploi</li>
                    <li data-qa-id="5003" class="tT3Ya">Cours et Formations</li>
                    <li data-qa-id="5004" class="tT3Ya">Stagoes</li>
                </ul>
                <ul>
                    <li data-qa-id="11000" class="_1_1B4">SERVICES</li>
                    <li data-qa-id="11001" class="tT3Ya">Prestations de services</li>
                    <li data-qa-id="11002" class="tT3Ya">Billetterie</li>
                    <li data-qa-id="11003" class="tT3Ya">Evenement st traiteurs</li>
                    <li data-qa-id="11004" class="tT3Ya">Cours particuliers</li>
                    <li data-qa-id="11005" class="tT3Ya" id="tttt">Covoiturage</li>
                </ul>
                <ul>
                    <li data-qa-id="9000" class="_1_1B4">AUTRES</li>
                    <li data-qa-id="9000" class="tT3Ya">Autres</li>
                </ul>
            </div>
        </div>  
    </div> 
    <script src="{{asset('js/vue.js')}}" ></script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
</div> 
<script src="{{asset('assets/css/jquery-3.3.1.min.js')}}" type="text/javascript"></script>

<script>
window.Laravel = {!! json_encode([
        'csrfToken' => csrf_token(),
//    'idProduct' => $id_product,
'url' => url('/')
]) !!}
;</script>
<script>
    $(document).ready(function () {

        $(".tT3Ya").on("click", function (e) {
            vmt.pro.id_ctgry = e.target.getAttribute("data-qa-id");
            vmt.searcheCatrgory();
        });
    });
    var vmt = new Vue(
            {
                el: '#srche',
                data: {
                    pro: {id_ctgry: 0,
                        id_vill: 0
                    }

                },

                methods: {
                    onChange: function ()
                    {
                        window.location.href = window.Laravel.url + '/search_ville/' + this.pro.id_vill;
                    },

                    searcheCatrgory: function ()
                    {
                        $titre = document.getElementById("titre").value;
                        if ($titre === "")
                        {
                            window.location.href = window.Laravel.url + '/search/touts/' + this.pro.id_ctgry;
                        } else {
                            window.location.href = window.Laravel.url + '/search/' + $titre + '/' + this.pro.id_ctgry;
                        }
                    },

                    searchProduct: function ()
                    {
                        $titre = document.getElementById("titre").value;
                        if ($titre === "")
                        {
                            window.location.href = window.Laravel.url + '/search/touts';
                        } else {
                            window.location.href = window.Laravel.url + '/search/' + $titre;
                        }
                    },

                }
            });
</script> 