<style >

    .navbar navbar-expand-lg navbar-dark primary-color {    color: #3C3C3C !important;  border-left: 1px solid #BDC3C9;}
    .white_nav:hover {    text-decoration: underline;}


</style>
<!-- Just an image -->
<nav  class="navbar navbar-expand-lg navbar-dark default-color" style="background: white">
    <a class="navbar-brand" href="{{url('/')}}" style="width: 150px ">
        <img src="{{asset('images/appImages/LOGO.png')}}" height="45" alt="mdb logo" >
    </a>
    <button class="navbar-toggler" style="background: #ff3377" type="button" data-toggle="collapse" data-target="#basicExampleNav"
            aria-controls="basicExampleNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon" ></span>
    </button>
    <div class="collapse navbar-collapse" id="basicExampleNav" style=" align-content: center">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="navbar-brand" style=" color: #ff3377"  href="{{url('/')}}">Home
                    <span class="sr-only">(current)</span>
                </a> 
            </li>
            <li class="nav-item">
                <a class="nav-link white_nav" data-toggle="modal" data-target="#exampleModal" style="color: orange !important" href="#">DÉPOSER UNE ANNONCE <span class="sr-only">(current)</span></a>
                <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h3 class="modal-title" id="exampleModalLabel">Choisissez une catégorie </h3>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">                 
                                <div class="row">
                                    <div class="col-12">
                                        <div class="list-group" id="list-tab" role="tablist">
                                            <a class="list-group-item list-group-item-action active" id="list-profile-list" href="{{url('Vehicules')}}" role="tab" aria-controls="profile">VEHICULES</a>
                                            <a class="list-group-item list-group-item-action " id="list-home-list" data-toggle=""  href="{{url('Immobilier')}}" role="tab" aria-controls="home">IMMOBILIER</a>
                                            <a class="list-group-item list-group-item-action " id="list-home-list" data-toggle=""  href="{{url('Vaconces')}}" role="tab" aria-controls="home">VACANCES</a>
                                            <a class="list-group-item list-group-item-action" id="list-messages-list"  href="{{url('MaisonJardin')}}" role="tab" aria-controls="messages">POUR LA MAISON ET JARDIN</a>
                                            <a class="list-group-item list-group-item-action" id="list-profile-list"  href="{{url('InformatiqueMultimedia')}}" role="tab" aria-controls="profile">INFORMATIQUE ET MULTIMEDIA</a>
                                            <a class="list-group-item list-group-item-action" id="list-home-list"  href="{{url('LoisirsDivertissement')}}" role="tab" aria-controls="home">LOISIRS ET DIVERTISSEMENT</a>
                                            <a class="list-group-item list-group-item-action" id="list-messages-list"  href="{{url('Emplois')}}" role="tab" aria-controls="messages">EMPLOI ET SERVICES</a>
                                            <a class="list-group-item list-group-item-action" id="list-settings-list"  href="{{url('HabillementBienEtre')}}" role="tab" aria-controls="settings">HABILLEMENT ET BIEN ETRE</a>
                                            <a class="list-group-item list-group-item-action" id="list-profile-list"  href="{{url('Entreprises')}}" role="tab" aria-controls="profile">ENTREPRISES</a>
                                            <a class="list-group-item list-group-item-action" id="list-profile-list"  href="{{url('Services')}}" role="tab" aria-controls="profile">SERVICES</a>
                                            <a class="list-group-item list-group-item-action" id="list-messages-list" href="{{url('Autres')}}" role="tab" aria-controls="messages">Autres</a>                    
                                        </div>
                                    </div>                                   
                                </div>
                            </div>                           
                        </div>
                    </div>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" style=" color: #ff3377" href="{{url('/')}}">Chat</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" style=" color: #ff3377" href="{{url('/')}}">Boutiques</a>
            </li>
            @guest
            <li class="nav-item">
                <a class="nav-link" style=" color: #ff3377" href="{{ route('login') }}">Connectez-vous</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" style=" color: #ff3377" href="{{ route('register') }}">Inscrivez-vous</a>
            </li>
            @else
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle waves-effect waves-light" style=" color: #ff3377" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                    <i class="fa fa-user lr-115"></i> {{ Auth::user()->name }}
                </a>
                <div class="dropdown-menu dropdown-menu-right dropdown-default" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item waves-effect waves-light" href="{{url('/espace_client')}}"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Mon espace</font></font></a>
                    <a class="dropdown-item" href="{{ route('logout') }}"
                       onclick="event.preventDefault();
                               document.getElementById('logout-form').submit();"><i class="icon-switch2"></i> 
                        {{ __('Logout') }}
                    </a>
                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                        @csrf
                    </form>
                </div>
            </li>
            @endguest
        </ul>
    </div>
</nav>





