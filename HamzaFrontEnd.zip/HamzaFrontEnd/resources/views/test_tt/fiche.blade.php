
<html>
    <head>
        <title>Upload Photos</title>
    </head>
    <body>
       <!-- <div class="container">

            <form action="{{url('charger')}}" method="post" enctype="multipart/form-data">
                <label>Select image to charger:</label>
                <input type="file" name="file" id="file">
                <input type="submit" value="Upload" name="submit">
                <input type="hidden" value="{{ csrf_token() }}" name="_token">
            </form>

        </div>-->
        
        <div class="container">

            <form action="{{url('charger/')}}" method="post" enctype="multipart/form-data">
                <label>Select image to charger:</label>
                <input type="file" name="file" id="file">
                <input type="submit" value="Upload" name="submit">
                <input type="hidden" value="{{ csrf_token() }}" name="_token">
            </form>

        </div>
    </body>
</html>


