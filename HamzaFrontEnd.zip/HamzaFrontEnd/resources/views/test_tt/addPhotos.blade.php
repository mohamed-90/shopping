 <style >
        .media-preview {
            float: left;
            width: 128px;
            height: 130px;
            overflow: auto;
            overflow-y: auto;
        }
        .media-preview {
            border: thin dashed #777;
            margin: .5em;
            padding: .5em;
            border-radius: 1em;
            background: rgba(255,255,255,.7);
            overflow: auto;
            position: relative;
        }

        .media-preview-image {
            margin: auto;
            min-height: 6.25em;
            min-width: 6.25em;
            text-align: center;
            overflow: hidden;
            padding-top: 5px;
        }
        .media-delete {
            display: block;
            position: absolute;
            top: 2px;
            right: 2px;
        }
        .media-editable-saved {
            opacity: 0;
            transition-duration: 0.3s;
            position: absolute;
            bottom: .3em;
            left: 1em;
            background-color: white;
            border: thin solid #777;
            z-index: 5;
        }
        .clearfix:before,
        .clearfix:after {
            content: " "; /* 1 */
            display: table; /* 2 */
        }

        .clearfix:after {
            clear: both;
        }

        /*
         * For IE 6/7 only
         * Include this rule to trigger hasLayout and contain floats.
         */

        .clearfix {
            *zoom: 1;
        }

    </style>
   
            <div class="card">
                <h6 class="card-header">Ajouter jusqu'a 10 photos</h6>
                <div class="card-body">
                    
                    
                    
                    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                    <a href="#" type="file" class="btn btn-primary">Ajouter des photos</a>
                    <div id="imagesUploaded" class="media-preview-container clearfix ui-sortable"   style="display: block">
                        <div class="media-preview clearfix" style="padding: 0px" v-for="item of pictures" :id="'imagesPreview_'+item.id" >
                            <div class="media-editable-saved"><img src="geo_templates/default/external/images/saved-check.png" alt=""></div>

                            <a href="http://www.hamza.com/AJAX.php?controller=UploadImage&amp;action=upload&amp;adminId=0&amp;userId=0&amp;ua=Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Chrome%2F69.0.3497.100+Safari%2F537.36#7281938" class="deleteImage media-delete">
                                <img alt="Supprimer Image" src="{{asset('assets/icons/trash.png')}}">
                            </a>
                            <small >  <b class="badge">Photo:</b></small>

                            <input style="width: 40;height: 20px" type="number" class="media-editable-sorting editImageSort" value="1" size="2" min="1" max="8">
                            <br>
                            <div style="background: blue; padding: 0px" class="media-preview-image">
                                <a href="user_images/9885833.jpg" class="lightUpImg">		
                                    <img src="user_images/7951841.jpg" width="100" height="37" alt="">
                                </a>		
                            </div>
                        </div>         
                    </div>
                    <div class="row">
                        <p><i class="fas fa-exclamation-triangle mr-2"></i>
                            En validant mon annonce, j'accepte les <a href="/conditions-utilisation.html" target="_blank" title="Règles d'utilisation">Règles d'utilisation</a> 
                            du site hamza.ma, et j'autorise hamza.ma à diffuser mon annonce</p>
                    </div>
                    <a href="/link-to/whatever-address/" id="cancel" name="cancel" class="btn btn-default" >Annuler</a>
                </div>
            </div>