<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Categore extends Model
{
     protected $table = 'categores';

    protected $fillable = ['type', 'description'];

}
