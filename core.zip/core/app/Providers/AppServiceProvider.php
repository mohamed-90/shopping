<?php

namespace App\Providers;

use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;
use App\GeneralSetting;
use App\Partner;
use App\Payment;
use App\Menu;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Schema::defaultStringLength(191);
        $general = GeneralSetting::first();
        $partner= Partner::all();
        $payment= Payment::first();
        $menu = Menu::all();
        view()->share('general',  $general);
        view()->share('partner',  $partner);
        view()->share('payment',  $payment);
        view()->share('menu',     $menu);
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
