@extends('layouts.user')
@section('style')
<link rel="stylesheet" href="{{ asset('assets/dashboard/css/cus.css') }}">
<style>
    .btn{
        margin-bottom: 10px;
    }
</style>
@endsection
@section('content')


<div class="row" >
    <div class="col-md-12">
        <div class="panel-body">
            <div class="row">
                <div class="col-sm-3 col-xs-6" >

                    <div class="tile-stats tile-red" style="height: 130px ;  background: #041E37;background-position: center; background-size: cover; color: white;">
                        <div class="icon"><i class="fa fa-money"></i></div>
                        <div class="num" data-start="0" data-end="{{ $member->amount }} $" data-postfix="" data-duration="1500" data-delay="0">{{ $member->amount }} $</div>
                        <h3>Total Balance</h3>
                    </div>
                </div>
                <div class="col-sm-3 col-xs-6">

                    <div class="tile-stats tile-green" style="height: 130px ;background: #041E37;background-position: center; background-size: cover; color: white;">
                        <div class="icon"><i class="fa fa-cloud-upload"></i></div>
                        <div class="num" data-start="0" data-end="{{ $total_deposit }} $" data-postfix="" data-duration="1500" data-delay="0">{{ $total_deposit }} $</div>
                        <h3>Total Invest</h3>
                    </div>
                </div>
                <div class="col-sm-3 col-xs-6">

                    <!--                    <div class="tile-stats tile-red" style="height: 130px ;background-image: url('{{asset('assets/images/dd.png')}}');background-position: center; background-size: cover; color: white;">-->
                    <div class="tile-stats tile-red" style="height: 130px ;background: #041E37;background-position: center; background-size: cover; color: white;">   
                        <div class="icon"><i class="fa fa-reply-all"></i></div>
                        <div class="num" data-start="0" data-end="{{ $total_rebeat }} $" data-postfix="" data-duration="1500" data-delay="0">{{ $total_rebeat }} $</div>

                        <h3>Total Profit</h3>
                    </div>
                </div>
                <div class="col-sm-3 col-xs-6">

                    <div class="tile-stats tile-blue" style="height: 130px ;background: #041E37;background-position: center; background-size: cover; color: white;">
                        <div class="icon"><i class="entypo-credit-card"></i></div>
                        <div class="num" data-start="0" data-end="{{ $total_reference }} " data-postfix="" data-duration="1500" data-delay="0">{{ $total_reference }} $</div>

                        <h3>Reference Bonus</h3>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<script type="text/javascript">
    jQuery(document).ready(function ($) {
        var $table4 = jQuery("#table-4");

        $table4.DataTable({
            dom: 'Bfrtip',
            buttons: [
                'copyHtml5',
                'excelHtml5',
                'csvHtml5',
                'pdfHtml5'
            ]
        });
    });
</script>
<div class="row" style=" margin: auto">
    <div class="col-md-1 col-sm-1">        
    </div>   
    <div class="col-md-12 col-sm-12">
        <div class="panel panel-info" data-collapsed="0" style=" background: #041E37; padding: 10px">
            <center>
                <div class="panel-title"><strong style=" color: white; font-size: 20px"> All Activity</strong></div>
            </center>

            <div class="panel-body">

                <table class="table table-striped table-hover table-bordered datatable" id="table-4">
                    <thead>
                        <tr>
                            <th>Sl No</th>
                            <th>Date</th>
                            <th>Balance Type</th>
                            <th>Balance</th>
                            <th>Charge</th>
                            <th>Balance Details</th>
                            <th>Past Balance</th>
                            <th>Present Balance</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php $i = 0;@endphp
                        @foreach($activity as $p)
                        @php $i++;@endphp
                        <tr>
                            <td>{{ $i }}</td>
                            <td width="18%">{{ \Carbon\Carbon::parse($p->created_at)->format('d F Y h:i A') }}</td>
                            <td width="11%">
                                @if($p->balance_type == 1)
                                <span class="label label-info"><i class="fa fa-plus"></i> Fund Add </span>
                                @elseif($p->balance_type == 2)
                                <span class="label label-success"><i class="fa fa-cloud-download"></i> Deposit</span>
                                @elseif($p->balance_type == 3)
                                <span class="label label-success"><i class="fa fa-recycle"></i> Profit</span>
                                @elseif($p->balance_type == 4)
                                <span class="label label-success"><i class="fa fa-reply-all"></i> Withdraw</span>
                                @elseif($p->balance_type == 5)
                                <span class="label label-success"><i class="fa fa-user-circle-o"></i> Bonus</span>
                                @elseif($p->balance_type == 7)
                                <span class="label label-danger"><i class="fa fa-bolt"></i> Refund</span>
                                @elseif($p->balance_type == 8)
                                <span class="label label-success"><i class="fa fa-plus"></i> Bank</span>
                                  @elseif($p->balance_type == 9)
                                <span class="label label-success"><i class="fa fa-user-circle-o"></i> Bitcion</span>
                                @endif
                            </td>
                            <td width="10%">{{ $p->balance }} - {{ $basic->currency }}</td>
                            <td width="9%">
                                @if($p->charge == null)
                                <i>Free</i>
                                @else
                                {{ $p->charge }} - {{ $basic->currency }}
                                @endif
                            </td>
                            <td>
                                @if($p->details == "Add Fund via Block IO")
                                <i>Add Fund via Bitcoin</i>
                                @else
                                {{ $p->details }}
                                @endif
                                </td>
                            <td width="12%">{{ round($p->old_balance,3) }} - {{ $basic->currency }}</td>
                            <td width="12%">{{ round($p->new_balance,3) }} - {{ $basic->currency }}</td>
                        </tr>
                        @endforeach
                    </tbody>

                </table>

            </div>
        </div>
    </div>
    <div class="col-md-1 col-sm-1">

    </div>
</div>

@endsection
@section('scripts')
<link rel="stylesheet" href="{{ asset('assets/dashboard/css/datatables.css') }}">

<script src="{{ asset('assets/dashboard/js/datatables.js') }}"></script>
<script src="{{ asset('assets/dashboard/js/clipboard.min.js') }}"></script>
<script>
     new Clipboard('.has');
</script>
@endsection