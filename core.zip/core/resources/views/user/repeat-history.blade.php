@extends('layouts.user')
@section('style')

<link rel="stylesheet" href="{{ asset('assets/dashboard/css/cus.css') }}">

@endsection
@section('content')
<script type="text/javascript">
    jQuery(document).ready(function ($) {
        var $table4 = jQuery("#table-4");

        $table4.DataTable({
            dom: 'Bfrtip',
            buttons: [
                'copyHtml5',
                'excelHtml5',
                'csvHtml5',
                'pdfHtml5'
            ]
        });
    });
</script>
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default panel-shadow" data-collapsed="0"><!-- to apply shadow add class "panel-shadow" -->

            <!-- panel body -->
            <div class="panel-body">
                <div class="row">
                    <table class="table table-striped table-hover table-bordered datatable" id="table-4">
                        <thead>
                            <tr>
                                <th>Sl No</th>
                                <th>Names</th>
                                <th>Invest</th>
                                <th>Commission</th>
                                <th>Repeat</th>
                                <th>Complete</th>
                                <th>Compound</th>
                                <th>Status</th>
                                <th>View</th>
                            </tr>
                        </thead>
                        <tbody>
                           @php $i = 0 @endphp
                    @foreach($deposit as $p)
                    @php $i++ @endphp
                            <tr>
                                <td>{{ $i }}</td>
                                <td><span class="aaaa"><strong>{{ $p->plan->name }}</strong></span></td>
                                <td>{{ $p->amount }} - {{ $basic->currency }}</td>
                                <td width="13%">{{ $p->percent }} %</td>
                                <td>{{ $p->time }} - times</td>
                                <td>@php $rep = \App\Repeat::whereDeposit_id($p->id)->first() @endphp{{ $rep->rebeat }} times</td>
                                <td><span class="aaaa"><strong>{{ $p->compound->name }}</strong></span></td>
                                
                                <td>
                                    @if($p->status == 0)
                                    <span class="label label-info"> Running</span>
                                    @else
                                    <span class="label label-success"> Completed</span>                                                   
                                    @endif

                                </td>
                                <td>
                                    <a href="{{ route('repeat-table',$p->id) }}" class="btn btn-info btn-block btn-icon icon-left">
                                        <i class="fa fa-mail-forward"></i> View Rebeating Table
                                    </a>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>

                    </table>
                </div>
                
               
                <hr>
                <div class="text-center">
                    {{ $deposit->links() }}
                </div>
            </div>

        </div>
    </div>
</div><!---ROW-->

@endsection
@section('scripts')

<script>
    $(document).ready(function () {

        $(document).on("click", '.delete_button', function (e) {
            var id = $(this).data('id');
            $(".abir_id").val(id);

        });

    });
</script>

<link rel="stylesheet" href="{{ asset('assets/dashboard/css/datatables.css') }}">

<script src="{{ asset('assets/dashboard/js/datatables.js') }}"></script>

@endsection

