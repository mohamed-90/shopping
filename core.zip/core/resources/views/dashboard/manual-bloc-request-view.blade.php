@extends('layouts.dashboard')
@section('style')
    <style>
        span.label{
            font-size: 12px !important;
        }
        td,th{
            font-size: 14px;
        }
    </style>
    <link rel="stylesheet" href="{{ asset('assets/dashboard/css//cus.css') }}">
@endsection
@section('content')


    <table class="table table-striped table-hover table-bordered datatable" id="table-4">
        <thead>
        <tr>
            <th>Date</th>
            <th>Name</th>
            <th>Email</th>
            <th>Amount</th>
            <th>Status</th>
        </tr>
        </thead>
        <tbody>
            <tr>
                <td width="13%">{{ \Carbon\Carbon::parse($blocio->created_at)->format('d-F-y h:i:s A') }}</td>
                <td width="12%">{{ $blocio->user->name }}</td>
                <td width="15%">{{ $blocio->email }}</td>
                <td width="15%">{{ $blocio->amount }}</td>
                <td>
                    @if($blocio->status == 0)
                        <span class="label label-secondary"><i class="fa fa-spinner"></i> Pending</span>
                    @elseif($blocio->status == 1)
                        <span class="label label-success"><i class="fa fa-check" aria-hidden="true"></i> Completed</span>
                    @else
                        <span class="label label-danger"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Refunded</span>
                    @endif
                </td>
            </tr>
        </tbody>

    </table>
        <div>
            <div class="col-md-8 col-md-offset-2 col-sm-12">
                <div class="input-group" style=" width: 200px">
                <label >New Amount</label>
                <input type="text" id="price_amount" value="{{ $blocio->amount }}" class="form-control">
                
               </div>
                <div class="input-group" style=" width: 200px">
                
                <button class="btn btn-danger  btn-lg btn-icon btn-block new_acount" > Confirm amount</button>
               </div>
            </div>
           
        </div>
<br>
<br>
    

    <div class="panel panel-default panel-shadow" data-collapsed="0"><!-- to apply shadow add class "panel-shadow" -->

        <!-- panel head -->
        <div class="panel-heading">
            <div class="panel-title">Bloc IO Prove Preview</div>

            <div class="panel-options">
                <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
                <a href="#" data-rel="close"><i class="entypo-cancel"></i></a>
            </div>
        </div>

        <!-- panel body -->
        <div class="panel-body">

            <div class="row">
                <div class="col-md-8 col-md-offset-2 col-sm-12">
                    <button type="button" class="btn btn-danger  btn-lg btn-icon btn-block icon-left delete_button"
                            data-toggle="modal" data-target="#DelModal"
                            data-id="{{ $blocio->id }}">
                        <i class="fa fa-check"></i> Confirm request
                    </button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="DelModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel"> <i class='fa fa-exclamation-triangle'></i> Confirmation..!</h4>
                </div>

                <div class="modal-body">
                    <strong>Are you sure you want to Confirm This Payment.?</strong>
                </div>

                <div class="modal-footer">
                    <form method="post" action="{{ route('manual-bloc-confirm') }}" class="form-inline">
                        {!! csrf_field() !!}
                        <input type="hidden" name="id" class="abir_id" value="0">
                        <input type="hidden" name="pric" id="n_pric" class="pric_id" value="0">

                        <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        <button type="submit" class="btn btn-danger"><i class="fa fa-check"></i> Yes I'm Sure..!</button>
                    </form>
                </div>

            </div>
        </div>
    </div>


@endsection
@section('scripts')
    <script>
        $(document).ready(function () {

            $(document).on("click", '.delete_button', function (e) {
                var id = $(this).data('id');
                $(".abir_id").val(id);

            });

        });
    </script>
      <script>
        $(document).ready(function () {

            $(document).on("click", '.new_acount', function () {
//                var id = $(this).data('id');
//                
                    var price = document.getElementById("price_amount").value;
                    $(".pric_id").val(price);
                    
                    var n_price = document.getElementById("n_pric").value;
                    alert('Good Edit New amount: ' + n_price);
            });

        });
    </script>

@endsection