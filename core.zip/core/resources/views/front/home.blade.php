
@include('front.header')

<div id="main" >
    <div class="container">
        <div class="content-area">
            <article id="post-1071" class="post-1071 page type-page status-publish hentry">
                <div class="entry-content">
                    <div class="vc_row wpb_row vc_row-fluid">
                        <div class="wpb_column vc_column_container vc_col-sm-12 vc_hidden-xs">
                            <div class="vc_column-inner ">
                                <div class="wpb_wrapper">
                                    <div class="stm-spacing" id="stm-spacing-5cb4bee4a7399">

                                    </div>
                                    <script>
                                        (function ($) {
                                            "use strict";
                                            var spacingID = 'stm-spacing-5cb4bee4a7399',
                                                    lgSpacing = '50px',
                                                    mdSpacing = '0',
                                                    smSpacing = '0',
                                                    xsSpacing = '0';
                                            function stmSpacing() {
                                                if (window.matchMedia("(min-width: 1200px)").matches && lgSpacing) {
                                                    $('#' + spacingID).css("height", lgSpacing);
                                                } else if (window.matchMedia("(max-width: 1199px) and (min-width: 992px )").matches && mdSpacing) {
                                                    $('#' + spacingID).css("height", mdSpacing);
                                                } else if (window.matchMedia("(max-width: 991px) and (min-width: 768px )").matches && smSpacing) {
                                                    $('#' + spacingID).css("height", smSpacing);
                                                } else if (window.matchMedia("(max-width: 767px)").matches && xsSpacing) {
                                                    $('#' + spacingID).css("height", xsSpacing);
                                                } else {
                                                    $('#' + spacingID).css("height", "");
                                                }
                                            }

                                            $(document).ready(function () {
                                                stmSpacing();
                                            });
                                            $(window).resize(function () {
                                                stmSpacing();
                                            });
                                        })(jQuery);
                                    </script>

                                    <div id="carouselExampleControls" class="carousel slid fullscreen-container" style="width: 120%; margin-left: -110px" data-ride="carousel">
                                        <div class="carousel-inner fullscreen-container">

                                            <div class="carousel-item active fullscreen-container" style="margin-left: -110px ;width: 120% ;height: 600px ; background: url('{{asset('assets/images/mage.jpeg')}}'); background-position: center; background-repeat: no-repeat; background-size: cover;">
                                            </div>

                                        </div>
                                        <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                            <span class="sr-only">Previous</span>
                                        </a>
                                        <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                            <span class="sr-only">Next</span>
                                        </a>
                                    </div>
                                </div>                                                        
                            </div>                                                    
                        </div>                                        
                    </div>
                    <div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid vc_custom_1519727271514 vc_row-has-fill">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner ">
                                <div class="wpb_wrapper"><div class="stm-spacing" id="stm-spacing-5cb4bee4b7c8a"></div>
                                    <script>
                                        (function ($) {
                                            "use strict";
                                            var spacingID = 'stm-spacing-5cb4bee4b7c8a',
                                                    lgSpacing = '66',
                                                    mdSpacing = '66',
                                                    smSpacing = '60',
                                                    xsSpacing = '40';
                                            function stmSpacing() {
                                                if (window.matchMedia("(min-width: 1200px)").matches && lgSpacing) {
                                                    $('#' + spacingID).css("height", lgSpacing);
                                                } else if (window.matchMedia("(max-width: 1199px) and (min-width: 992px )").matches && mdSpacing) {
                                                    $('#' + spacingID).css("height", mdSpacing);
                                                } else if (window.matchMedia("(max-width: 991px) and (min-width: 768px )").matches && smSpacing) {
                                                    $('#' + spacingID).css("height", smSpacing);
                                                } else if (window.matchMedia("(max-width: 767px)").matches && xsSpacing) {
                                                    $('#' + spacingID).css("height", xsSpacing);
                                                } else {
                                                    $('#' + spacingID).css("height", "");
                                                }
                                            }

                                            $(document).ready(function () {
                                                stmSpacing();
                                            });
                                            $(window).resize(function () {
                                                stmSpacing();
                                            });
                                        })(jQuery);
                                    </script>

                                    <div class="vc_custom_heading vc_custom_1519706545898 text_align_center" ><h2 style="text-align: center" >What we do</h2></div><div class="vc_row wpb_row vc_inner vc_row-fluid vc_custom_1461325858760"><div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-4 vc_col-md-4"><div class="vc_column-inner vc_custom_1519727499696"><div class="wpb_wrapper"><div class="stm_animation stm_viewport" style="" data-animate="fadeInLeft" data-animation-delay="0.3" data-animation-duration="0.5" data-viewport_position="90" >

                                                        <a href="#" class="icon_box  vc_custom_1554210050457 style_5 clearfix">
                                                            <div class="icon_box_inner">
                                                                <div class="icon  font-color_custom font-color_base_bg" ><i style="font-size:51px; color: #94a6ab;  " class="stm-zurich-darts"></i></div>
                                                                <div class="icon_bg"><i class="stm-zurich-darts"></i></div>
                                                                <h4 style="font-size:18px" class="font-color_base">Raw Spreads</h4>
                                                                <div class="icon_text">
                                                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna</p>
                                                                </div>
                                                                <div class="text_more">
                                                                    Read more <i class="fa fa-angle-right"></i>
                                                                </div>
                                                            </div>
                                                        </a>
                                                    </div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-4 vc_col-md-4"><div class="vc_column-inner vc_custom_1519727504344"><div class="wpb_wrapper"><div class="stm_animation stm_viewport" style="" data-animate="fadeInUp" data-animation-delay="0.3" data-animation-duration="0.5" data-viewport_position="90" >

                                                        <a href="#" class="icon_box  vc_custom_1554210060753 style_5 clearfix">
                                                            <div class="icon_box_inner">
                                                                <div class="icon  font-color_custom font-color_base_bg" ><i style="font-size:51px; color: #94a6ab;  " class="stm-zurich-hourse"></i></div>
                                                                <div class="icon_bg"><i class="stm-zurich-hourse"></i></div>
                                                                <h4 style="font-size:18px" class="font-color_base">No Dealing Desk</h4>
                                                                <div class="icon_text">
                                                                    <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut</p>
                                                                </div>
                                                                <div class="text_more">
                                                                    Read more <i class="fa fa-angle-right"></i>
                                                                </div>
                                                            </div>
                                                        </a>
                                                    </div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-4 vc_col-md-4"><div class="vc_column-inner"><div class="wpb_wrapper"><div class="stm_animation stm_viewport" style="" data-animate="fadeInRight" data-animation-delay="0.3" data-animation-duration="0.5" data-viewport_position="90" >

                                                        <a href="#" class="icon_box  vc_custom_1554210070582 style_5 clearfix">
                                                            <div class="icon_box_inner">
                                                                <div class="icon  font-color_custom font-color_base_bg" ><i style="font-size:51px; color: #94a6ab;  " class="stm-zurich-progress"></i></div>
                                                                <div class="icon_bg"><i class="stm-zurich-progress"></i></div>
                                                                <h4 style="font-size:18px" class="font-color_base">State of the Art</h4>
                                                                <div class="icon_text">
                                                                    <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip commodo consequat. Duis aute irure dolor</p>
                                                                </div>
                                                                <div class="text_more">
                                                                    Read more <i class="fa fa-angle-right"></i>
                                                                </div>
                                                            </div>
                                                        </a>
                                                    </div></div></div></div></div><div class="stm-spacing" id="stm-spacing-5cb4bee4bb5c1"></div>
                                    <script>
                                        (function ($) {
                                            "use strict";
                                            var spacingID = 'stm-spacing-5cb4bee4bb5c1',
                                                    lgSpacing = '21',
                                                    mdSpacing = '21',
                                                    smSpacing = '31',
                                                    xsSpacing = '21';
                                            function stmSpacing() {
                                                if (window.matchMedia("(min-width: 1200px)").matches && lgSpacing) {
                                                    $('#' + spacingID).css("height", lgSpacing);
                                                } else if (window.matchMedia("(max-width: 1199px) and (min-width: 992px )").matches && mdSpacing) {
                                                    $('#' + spacingID).css("height", mdSpacing);
                                                } else if (window.matchMedia("(max-width: 991px) and (min-width: 768px )").matches && smSpacing) {
                                                    $('#' + spacingID).css("height", smSpacing);
                                                } else if (window.matchMedia("(max-width: 767px)").matches && xsSpacing) {
                                                    $('#' + spacingID).css("height", xsSpacing);
                                                } else {
                                                    $('#' + spacingID).css("height", "");
                                                }
                                            }

                                            $(document).ready(function () {
                                                stmSpacing();
                                            });
                                            $(window).resize(function () {
                                                stmSpacing();
                                            });
                                        })(jQuery);
                                    </script>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_row-full-width vc_clearfix">

                    </div>
                    <div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid vc_custom_1554215776644 vc_row-has-fill">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner ">
                                <div class="wpb_wrapper">

                                    <section class="vc_cta3-container" >
                                        <div class="vc_general vc_cta3 third_bg_color vc_cta3-style-flat vc_cta3-shape-square vc_cta3-align-left vc_cta3-color-classic vc_cta3-icon-size-md vc_cta3-actions-right vc_custom_1554215939614">
                                            <div class="vc_cta3_content-container">
                                                <div class="vc_cta3-content">
                                                    <header class="vc_cta3-content-header">
                                                        <div class="vc_custom_heading" ><h2 style="font-size: 25px;color: #ffffff;line-height: 22px" >Looking for a First-Class Business Plan Consultant?</h2></div>                                    </header>
                                                </div>
                                                <div class="vc_cta3-actions"><div class="vc_btn3-container vc_btn3-right" >
                                                        <a class="vc_general vc_btn3 vc_btn3-size-md vc_btn3-shape-rounded vc_btn3-style-flat vc_btn3-block vc_btn3-icon-right vc_btn3-color-white" href="{{ route('contact') }}" title="">Get a Quote <i class="vc_btn3-icon fa fa-angle-right"></i></a></div>
                                                </div>        </div>
                                        </div>
                                    </section>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_row-full-width vc_clearfix">

                    </div>
                    <div class="vc_row wpb_row vc_row-fluid">
                        <div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-6 vc_col-md-6">
                            <div class="vc_column-inner ">


                                <div class="wpb_wrapper"><div class="stm-spacing" id="stm-spacing-5cb4bee4be73e"></div>
                                    <script>
                                        (function ($) {
                                            "use strict";
                                            var spacingID = 'stm-spacing-5cb4bee4be73e',
                                                    lgSpacing = '76',
                                                    mdSpacing = '76',
                                                    smSpacing = '60',
                                                    xsSpacing = '40';
                                            function stmSpacing() {
                                                if (window.matchMedia("(min-width: 1200px)").matches && lgSpacing) {
                                                    $('#' + spacingID).css("height", lgSpacing);
                                                } else if (window.matchMedia("(max-width: 1199px) and (min-width: 992px )").matches && mdSpacing) {
                                                    $('#' + spacingID).css("height", mdSpacing);
                                                } else if (window.matchMedia("(max-width: 991px) and (min-width: 768px )").matches && smSpacing) {
                                                    $('#' + spacingID).css("height", smSpacing);
                                                } else if (window.matchMedia("(max-width: 767px)").matches && xsSpacing) {
                                                    $('#' + spacingID).css("height", xsSpacing);
                                                } else {
                                                    $('#' + spacingID).css("height", "");
                                                }
                                            }

                                            $(document).ready(function () {
                                                stmSpacing();
                                            });
                                            $(window).resize(function () {
                                                stmSpacing();
                                            });
                                        })(jQuery);
                                    </script>

                                    <div class="vc_custom_heading second_font_color vc_custom_1519726708012 text_align_left title_no_stripe" ><h3 style="text-align: left" >Why Choose us</h3></div><div class="stm-spacing" id="stm-spacing-5cb4bee4bea45"></div>
                                    <script>
                                        (function ($) {
                                            "use strict";
                                            var spacingID = 'stm-spacing-5cb4bee4bea45',
                                                    lgSpacing = '32',
                                                    mdSpacing = '32',
                                                    smSpacing = '22',
                                                    xsSpacing = '12';
                                            function stmSpacing() {
                                                if (window.matchMedia("(min-width: 1200px)").matches && lgSpacing) {
                                                    $('#' + spacingID).css("height", lgSpacing);
                                                } else if (window.matchMedia("(max-width: 1199px) and (min-width: 992px )").matches && mdSpacing) {
                                                    $('#' + spacingID).css("height", mdSpacing);
                                                } else if (window.matchMedia("(max-width: 991px) and (min-width: 768px )").matches && smSpacing) {
                                                    $('#' + spacingID).css("height", smSpacing);
                                                } else if (window.matchMedia("(max-width: 767px)").matches && xsSpacing) {
                                                    $('#' + spacingID).css("height", xsSpacing);
                                                } else {
                                                    $('#' + spacingID).css("height", "");
                                                }
                                            }

                                            $(document).ready(function () {
                                                stmSpacing();
                                            });
                                            $(window).resize(function () {
                                                stmSpacing();
                                            });
                                        })(jQuery);
                                    </script>

                                    <div class="stm_animation stm_viewport" style="" data-animate="fadeInUp" data-animation-delay="0.3" data-animation-duration="0.5" data-viewport_position="90" >
                                        <div class="vc_row wpb_row vc_inner vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner vc_custom_1519714463553"><div class="wpb_wrapper">
                                                        <div class="icon_box  vc_custom_1519714543673 style_2 alignment_left clearfix">
                                                            <div class="icon_box_inner">
                                                                <div class="icon  font-color_third font-color_base_bg" style="width:38px"><i style="font-size:23px; " class="stm-zurich-microphone"></i></div>
                                                                <h5 style="font-size:16px;line-height:28px;color:#222222" class="no_stripe">Elusmod Tempor</h5>
                                                            </div>
                                                        </div>


                                                        <div class="wpb_text_column wpb_content_element " >
                                                            <div class="wpb_wrapper">
                                                                <p style="color: #888888; font-size: 13px; line-height: 20px;">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint</p>

                                                            </div>
                                                        </div>
                                                    </div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner vc_custom_1519714469311"><div class="wpb_wrapper">
                                                        <div class="icon_box  vc_custom_1519714622928 style_2 alignment_left clearfix">
                                                            <div class="icon_box_inner">
                                                                <div class="icon  font-color_third font-color_base_bg" style="width:38px"><i style="font-size:23px; " class="stm-zurich-growth"></i></div>
                                                                <h5 style="font-size:16px;line-height:28px;color:#222222" class="no_stripe">Sed do Eismod</h5>
                                                            </div>
                                                        </div>


                                                        <div class="wpb_text_column wpb_content_element " >
                                                            <div class="wpb_wrapper">
                                                                <p style="color: #888888; font-size: 13px; line-height: 20px;">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt labore et dolore magna aliqua.</p>

                                                            </div>
                                                        </div>
                                                    </div></div></div></div><div class="vc_row wpb_row vc_inner vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner vc_custom_1519714474640"><div class="wpb_wrapper">
                                                        <div class="icon_box  vc_custom_1519714589568 style_2 alignment_left clearfix">
                                                            <div class="icon_box_inner">
                                                                <div class="icon  font-color_third font-color_base_bg" style="width:38px"><i style="font-size:23px; " class="stm-zurich-labore"></i></div>
                                                                <h5 style="font-size:16px;line-height:28px;color:#222222" class="no_stripe">Labore et Dolore</h5>
                                                            </div>
                                                        </div>


                                                        <div class="wpb_text_column wpb_content_element " >
                                                            <div class="wpb_wrapper">
                                                                <p style="color: #888888; font-size: 13px; line-height: 20px;">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna</p>

                                                            </div>
                                                        </div>
                                                    </div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner vc_custom_1519714479945"><div class="wpb_wrapper">
                                                        <div class="icon_box  vc_custom_1519714610086 style_2 alignment_left clearfix">
                                                            <div class="icon_box_inner">
                                                                <div class="icon  font-color_third font-color_base_bg" style="width:38px"><i style="font-size:23px; " class="stm-zurich-certificate"></i></div>
                                                                <h5 style="font-size:16px;line-height:28px;color:#222222" class="no_stripe">Duis Ipsum</h5>
                                                            </div>
                                                        </div>


                                                        <div class="wpb_text_column wpb_content_element " >
                                                            <div class="wpb_wrapper">
                                                                <p style="color: #888888; font-size: 13px; line-height: 20px;">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute</p>

                                                            </div>
                                                        </div>
                                                    </div></div></div></div></div><div class="stm-spacing" id="stm-spacing-5cb4bee4c12c7"></div>
                                    <script>
                                        (function ($) {
                                            "use strict";
                                            var spacingID = 'stm-spacing-5cb4bee4c12c7',
                                                    lgSpacing = '70',
                                                    mdSpacing = '70',
                                                    smSpacing = '0',
                                                    xsSpacing = '0';
                                            function stmSpacing() {
                                                if (window.matchMedia("(min-width: 1200px)").matches && lgSpacing) {
                                                    $('#' + spacingID).css("height", lgSpacing);
                                                } else if (window.matchMedia("(max-width: 1199px) and (min-width: 992px )").matches && mdSpacing) {
                                                    $('#' + spacingID).css("height", mdSpacing);
                                                } else if (window.matchMedia("(max-width: 991px) and (min-width: 768px )").matches && smSpacing) {
                                                    $('#' + spacingID).css("height", smSpacing);
                                                } else if (window.matchMedia("(max-width: 767px)").matches && xsSpacing) {
                                                    $('#' + spacingID).css("height", xsSpacing);
                                                } else {
                                                    $('#' + spacingID).css("height", "");
                                                }
                                            }

                                            $(document).ready(function () {
                                                stmSpacing();
                                            });
                                            $(window).resize(function () {
                                                stmSpacing();
                                            });
                                        })(jQuery);
                                    </script>

                                </div></div>
                        </div><div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-6 vc_col-md-6"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="stm-spacing" id="stm-spacing-5cb4bee4c1702"></div>

                                    <script>
                                        (function ($) {
                                            "use strict";
                                            var spacingID = 'stm-spacing-5cb4bee4c1702',
                                                    lgSpacing = '76',
                                                    mdSpacing = '76',
                                                    smSpacing = '0',
                                                    xsSpacing = '0';
                                            function stmSpacing() {
                                                if (window.matchMedia("(min-width: 1200px)").matches && lgSpacing) {
                                                    $('#' + spacingID).css("height", lgSpacing);
                                                } else if (window.matchMedia("(max-width: 1199px) and (min-width: 992px )").matches && mdSpacing) {
                                                    $('#' + spacingID).css("height", mdSpacing);
                                                } else if (window.matchMedia("(max-width: 991px) and (min-width: 768px )").matches && smSpacing) {
                                                    $('#' + spacingID).css("height", smSpacing);
                                                } else if (window.matchMedia("(max-width: 767px)").matches && xsSpacing) {
                                                    $('#' + spacingID).css("height", xsSpacing);
                                                } else {
                                                    $('#' + spacingID).css("height", "");
                                                }
                                            }

                                            $(document).ready(function () {
                                                stmSpacing();
                                            });
                                            $(window).resize(function () {
                                                stmSpacing();
                                            });
                                        })(jQuery);
                                    </script>

                                    <div class="vc_custom_heading second_font_color vc_custom_1519726712177 text_align_left title_no_stripe" ><h3 style="text-align: left" >Strategy Development</h3></div><div class="stm-spacing" id="stm-spacing-5cb4bee4c1a4e"></div>
                                    <script>
                                        (function ($) {
                                            "use strict";
                                            var spacingID = 'stm-spacing-5cb4bee4c1a4e',
                                                    lgSpacing = '26',
                                                    mdSpacing = '26',
                                                    smSpacing = '22',
                                                    xsSpacing = '16';
                                            function stmSpacing() {
                                                if (window.matchMedia("(min-width: 1200px)").matches && lgSpacing) {
                                                    $('#' + spacingID).css("height", lgSpacing);
                                                } else if (window.matchMedia("(max-width: 1199px) and (min-width: 992px )").matches && mdSpacing) {
                                                    $('#' + spacingID).css("height", mdSpacing);
                                                } else if (window.matchMedia("(max-width: 991px) and (min-width: 768px )").matches && smSpacing) {
                                                    $('#' + spacingID).css("height", smSpacing);
                                                } else if (window.matchMedia("(max-width: 767px)").matches && xsSpacing) {
                                                    $('#' + spacingID).css("height", xsSpacing);
                                                } else {
                                                    $('#' + spacingID).css("height", "");
                                                }
                                            }

                                            $(document).ready(function () {
                                                stmSpacing();
                                            });
                                            $(window).resize(function () {
                                                stmSpacing();
                                            });
                                        })(jQuery);
                                    </script>

                                    <div class="stm_animation stm_viewport" style="" data-animate="fadeInUp" data-animation-delay="0.3" data-animation-duration="0.5" data-viewport_position="90" >
                                        <div class="vc_tta-container" data-vc-action="collapse"><div class="vc_general vc_tta vc_tta-accordion vc_tta-color-orange vc_tta-style-classic vc_tta-shape-square vc_tta-o-shape-group vc_tta-controls-align-left vc_tta-o-no-fill"><div class="vc_tta-panels-container"><div class="vc_tta-panels"><div class="vc_tta-panel vc_active" id="1461328856794-2dee9bba-e774" data-vc-content=".vc_tta-panel-body"><div class="vc_tta-panel-heading"><h4 class="vc_tta-panel-title vc_tta-controls-icon-position-right"><a href="#1461328856794-2dee9bba-e774" data-vc-accordion data-vc-container=".vc_tta-container"><span class="vc_tta-title-text">Strategy Development</span><i class="vc_tta-controls-icon vc_tta-controls-icon-plus"></i></a></h4></div><div class="vc_tta-panel-body">
                                                                <div class="wpb_text_column wpb_content_element " >
                                                                    <div class="wpb_wrapper">
                                                                        <p><span style="color: #888888;">We help entrepreneurs get ready to raise capital. Please note that we cannot help our clients raise capital. This usually consists of some or all of our services. This is a service that is heavily regulated.</span></p>

                                                                    </div>
                                                                </div>
                                                            </div></div><div class="vc_tta-panel" id="1461328897545-6227748f-d226" data-vc-content=".vc_tta-panel-body"><div class="vc_tta-panel-heading"><h4 class="vc_tta-panel-title vc_tta-controls-icon-position-right"><a href="#1461328897545-6227748f-d226" data-vc-accordion data-vc-container=".vc_tta-container"><span class="vc_tta-title-text">Strategic Plan Development</span><i class="vc_tta-controls-icon vc_tta-controls-icon-plus"></i></a></h4></div><div class="vc_tta-panel-body">
                                                                <div class="wpb_text_column wpb_content_element " >
                                                                    <div class="wpb_wrapper">
                                                                        <p><span style="color: #888888;">We help entrepreneurs get ready to raise capital. Please note that we cannot help our clients raise capital. This usually consists of some or all of our services. This is a service that is heavily regulated.</span></p>

                                                                    </div>
                                                                </div>
                                                            </div></div><div class="vc_tta-panel" id="1461328919259-f69cd27c-5029" data-vc-content=".vc_tta-panel-body"><div class="vc_tta-panel-heading"><h4 class="vc_tta-panel-title vc_tta-controls-icon-position-right"><a href="#1461328919259-f69cd27c-5029" data-vc-accordion data-vc-container=".vc_tta-container"><span class="vc_tta-title-text">Strategic Plan Execution Management</span><i class="vc_tta-controls-icon vc_tta-controls-icon-plus"></i></a></h4></div><div class="vc_tta-panel-body">
                                                                <div class="wpb_text_column wpb_content_element " >
                                                                    <div class="wpb_wrapper">
                                                                        <p><span style="color: #888888;">We help entrepreneurs get ready to raise capital. Please note that we cannot help our clients raise capital. This usually consists of some or all of our services. This is a service that is heavily regulated.</span></p>

                                                                    </div>
                                                                </div>
                                                            </div></div></div></div></div></div></div><div class="stm-spacing" id="stm-spacing-5cb4bee4c4129"></div>
                                    <script>
                                        (function ($) {
                                            "use strict";
                                            var spacingID = 'stm-spacing-5cb4bee4c4129',
                                                    lgSpacing = '70',
                                                    mdSpacing = '70',
                                                    smSpacing = '60',
                                                    xsSpacing = '40';
                                            function stmSpacing() {
                                                if (window.matchMedia("(min-width: 1200px)").matches && lgSpacing) {
                                                    $('#' + spacingID).css("height", lgSpacing);
                                                } else if (window.matchMedia("(max-width: 1199px) and (min-width: 992px )").matches && mdSpacing) {
                                                    $('#' + spacingID).css("height", mdSpacing);
                                                } else if (window.matchMedia("(max-width: 991px) and (min-width: 768px )").matches && smSpacing) {
                                                    $('#' + spacingID).css("height", smSpacing);
                                                } else if (window.matchMedia("(max-width: 767px)").matches && xsSpacing) {
                                                    $('#' + spacingID).css("height", xsSpacing);
                                                } else {
                                                    $('#' + spacingID).css("height", "");
                                                }
                                            }

                                            $(document).ready(function () {
                                                stmSpacing();
                                            });
                                            $(window).resize(function () {
                                                stmSpacing();
                                            });
                                        })(jQuery);
                                    </script>

                                </div></div></div></div>
                    <div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid overlay_4 fixed_bg vc_custom_1554483728260 vc_row-has-fill">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner ">
                                <div class="wpb_wrapper"><div class="stm-spacing" id="stm-spacing-5cb4bee4c489f"></div>
                                    <script>
                                        (function ($) {
                                            "use strict";
                                            var spacingID = 'stm-spacing-5cb4bee4c489f',
                                                    lgSpacing = '98',
                                                    mdSpacing = '98',
                                                    smSpacing = '60',
                                                    xsSpacing = '40';
                                            function stmSpacing() {
                                                if (window.matchMedia("(min-width: 1200px)").matches && lgSpacing) {
                                                    $('#' + spacingID).css("height", lgSpacing);
                                                } else if (window.matchMedia("(max-width: 1199px) and (min-width: 992px )").matches && mdSpacing) {
                                                    $('#' + spacingID).css("height", mdSpacing);
                                                } else if (window.matchMedia("(max-width: 991px) and (min-width: 768px )").matches && smSpacing) {
                                                    $('#' + spacingID).css("height", smSpacing);
                                                } else if (window.matchMedia("(max-width: 767px)").matches && xsSpacing) {
                                                    $('#' + spacingID).css("height", xsSpacing);
                                                } else {
                                                    $('#' + spacingID).css("height", "");
                                                }
                                            }

                                            $(document).ready(function () {
                                                stmSpacing();
                                            });
                                            $(window).resize(function () {
                                                stmSpacing();
                                            });
                                        })(jQuery);
                                    </script>

                                    <div class="vc_custom_heading text_align_center title_no_stripe" ><h2 style="color: #ffffff;text-align: center" >More than <mark>25 Years</mark><br />
                                            of Experience</h2></div><div class="stm-spacing" id="stm-spacing-5cb4bee4c4bd7"></div>
                                    <script>
                                        (function ($) {
                                            "use strict";
                                            var spacingID = 'stm-spacing-5cb4bee4c4bd7',
                                                    lgSpacing = '50',
                                                    mdSpacing = '50',
                                                    smSpacing = '30',
                                                    xsSpacing = '20';
                                            function stmSpacing() {
                                                if (window.matchMedia("(min-width: 1200px)").matches && lgSpacing) {
                                                    $('#' + spacingID).css("height", lgSpacing);
                                                } else if (window.matchMedia("(max-width: 1199px) and (min-width: 992px )").matches && mdSpacing) {
                                                    $('#' + spacingID).css("height", mdSpacing);
                                                } else if (window.matchMedia("(max-width: 991px) and (min-width: 768px )").matches && smSpacing) {
                                                    $('#' + spacingID).css("height", smSpacing);
                                                } else if (window.matchMedia("(max-width: 767px)").matches && xsSpacing) {
                                                    $('#' + spacingID).css("height", xsSpacing);
                                                } else {
                                                    $('#' + spacingID).css("height", "");
                                                }
                                            }

                                            $(document).ready(function () {
                                                stmSpacing();
                                            });
                                            $(window).resize(function () {
                                                stmSpacing();
                                            });
                                        })(jQuery);
                                    </script>

                                    <div class="vc_row wpb_row vc_inner vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-3"><div class="vc_column-inner vc_custom_1519725632544"><div class="wpb_wrapper"><div class="stm_animation stm_viewport" style="" data-animate="fadeInUp" data-animation-delay="0" data-animation-duration="0.3" data-viewport_position="90" >

                                                        <div class="icon_box  style_2 alignment_center clearfix">
                                                            <div class="icon_box_inner">
                                                                <div class="icon  font-color_secondary font-color_base_bg" style="width:80px"><i style="font-size:48px; " class="stm-zurich-portfolio"></i></div>
                                                                <h5 style="font-size:16px;line-height:20px;color:#ffffff" >321 projects<br />
                                                                    complited</h5>
                                                            </div>
                                                        </div>

                                                    </div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-3"><div class="vc_column-inner vc_custom_1519725642334"><div class="wpb_wrapper"><div class="stm_animation stm_viewport" style="" data-animate="fadeInUp" data-animation-delay="0.2" data-animation-duration="0.3" data-viewport_position="90" >

                                                        <div class="icon_box  style_2 alignment_center clearfix">
                                                            <div class="icon_box_inner">
                                                                <div class="icon  font-color_secondary font-color_base_bg" style="width:68px"><i style="font-size:48px; " class="stm-zurich-employed"></i></div>
                                                                <h5 style="font-size:16px;line-height:20px;color:#ffffff" >27 workers<br />
                                                                    employed</h5>
                                                            </div>
                                                        </div>

                                                    </div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-3"><div class="vc_column-inner vc_custom_1519725649918"><div class="wpb_wrapper"><div class="stm_animation stm_viewport" style="" data-animate="fadeInUp" data-animation-delay="0.4" data-animation-duration="0.3" data-viewport_position="90" >

                                                        <div class="icon_box  style_2 alignment_center clearfix">
                                                            <div class="icon_box_inner">
                                                                <div class="icon  font-color_secondary font-color_base_bg" style="width:64px"><i style="font-size:60px; " class="stm-zurich-stamp"></i></div>
                                                                <h5 style="font-size:16px;line-height:20px;color:#ffffff" >19 awards<br />
                                                                    wining</h5>
                                                            </div>
                                                        </div>

                                                    </div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-3"><div class="vc_column-inner vc_custom_1519725656795"><div class="wpb_wrapper"><div class="stm_animation stm_viewport" style="" data-animate="fadeInUp" data-animation-delay="0.6" data-animation-duration="0.3" data-viewport_position="90" >

                                                        <div class="icon_box  style_2 alignment_center clearfix">
                                                            <div class="icon_box_inner">
                                                                <div class="icon  font-color_secondary font-color_base_bg" style="width:70px"><i style="font-size:55px; " class="stm-zurich-like"></i></div>
                                                                <h5 style="font-size:16px;line-height:20px;color:#ffffff" >280 satisfied<br />
                                                                    customers</h5>
                                                            </div>
                                                        </div>

                                                    </div></div></div></div></div><div class="stm-spacing" id="stm-spacing-5cb4bee4c6777"></div>
                                    <script>
                                        (function ($) {
                                            "use strict";
                                            var spacingID = 'stm-spacing-5cb4bee4c6777',
                                                    lgSpacing = '54',
                                                    mdSpacing = '54',
                                                    smSpacing = '34',
                                                    xsSpacing = '14';
                                            function stmSpacing() {
                                                if (window.matchMedia("(min-width: 1200px)").matches && lgSpacing) {
                                                    $('#' + spacingID).css("height", lgSpacing);
                                                } else if (window.matchMedia("(max-width: 1199px) and (min-width: 992px )").matches && mdSpacing) {
                                                    $('#' + spacingID).css("height", mdSpacing);
                                                } else if (window.matchMedia("(max-width: 991px) and (min-width: 768px )").matches && smSpacing) {
                                                    $('#' + spacingID).css("height", smSpacing);
                                                } else if (window.matchMedia("(max-width: 767px)").matches && xsSpacing) {
                                                    $('#' + spacingID).css("height", xsSpacing);
                                                } else {
                                                    $('#' + spacingID).css("height", "");
                                                }
                                            }

                                            $(document).ready(function () {
                                                stmSpacing();
                                            });
                                            $(window).resize(function () {
                                                stmSpacing();
                                            });
                                        })(jQuery);
                                    </script>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_row-full-width vc_clearfix">

                    </div>
                    <div class="vc_row wpb_row vc_row-fluid">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner ">
                                <div class="wpb_wrapper"><div class="stm-spacing" id="stm-spacing-5cb4bee4c6e14"></div>
                                    <script>
                                        (function ($) {
                                            "use strict";
                                            var spacingID = 'stm-spacing-5cb4bee4c6e14',
                                                    lgSpacing = '81',
                                                    mdSpacing = '81',
                                                    smSpacing = '60',
                                                    xsSpacing = '40';
                                            function stmSpacing() {
                                                if (window.matchMedia("(min-width: 1200px)").matches && lgSpacing) {
                                                    $('#' + spacingID).css("height", lgSpacing);
                                                } else if (window.matchMedia("(max-width: 1199px) and (min-width: 992px )").matches && mdSpacing) {
                                                    $('#' + spacingID).css("height", mdSpacing);
                                                } else if (window.matchMedia("(max-width: 991px) and (min-width: 768px )").matches && smSpacing) {
                                                    $('#' + spacingID).css("height", smSpacing);
                                                } else if (window.matchMedia("(max-width: 767px)").matches && xsSpacing) {
                                                    $('#' + spacingID).css("height", xsSpacing);
                                                } else {
                                                    $('#' + spacingID).css("height", "");
                                                }
                                            }

                                            $(document).ready(function () {
                                                stmSpacing();
                                            });
                                            $(window).resize(function () {
                                                stmSpacing();
                                            });
                                        })(jQuery);
                                    </script>

                                    <div class="vc_custom_heading vc_custom_1519798194690 text_align_center" ><h2 style="text-align: center" >Featured Works</h2></div><div class="stm_animation stm_viewport" style="" data-animate="fadeInUp" data-animation-delay="0.3" data-animation-duration="0.5" data-viewport_position="90" >
                                        <div id="stm_works_5cb4bee4c8d29" class="stm_works_wr cols_4 grid style_2">


                                            <div class="stm_works_masonry_disabled">
                                                <div class="item">
                                                    <img class="" src="{{ asset('assets/index/wp-content/uploads/2016/06/placeholder-550x525.gif') }}" width="550" height="525" alt="placeholder" title="placeholder" />                                <a href="">
                                                        <span class="work-title">
                                                            Leading consumer products companies                                                                                    <span class="work-description">Financial Services</span>
                                                        </span>
                                                    </a>
                                                </div>
                                                <div class="item">
                                                    <img class="" src="{{ asset('assets/index/wp-content/uploads/2016/06/placeholder-545x255.gif') }}" width="545" height="255" alt="placeholder" title="placeholder" />                                <a href="">
                                                        <span class="work-title">
                                                            Bain helps transportation &#038; logistics companies                                                                                    <span class="work-description">Surface Transport &amp; Logistics</span>
                                                        </span>
                                                    </a>
                                                </div>
                                                <div class="item">
                                                    <img class="" src="{{ asset('assets/index/wp-content/uploads/2016/06/placeholder-265x255.gif') }}" width="265" height="255" alt="placeholder" title="placeholder" />                                <a href="">
                                                        <span class="work-title">
                                                            Developing a strategy and roadmap for clients                                                                                    <span class="work-description">Energy &amp; Environment</span>
                                                        </span>
                                                    </a>
                                                </div>
                                                <div class="item">
                                                    <img class="" src="{{ asset('assets/index/wp-content/uploads/2016/06/placeholder-265x255.gif') }}" width="265" height="255" alt="placeholder" title="placeholder" />                                <a href="">
                                                        <span class="work-title">
                                                            Constructing the best-in-class global assets                                                                                    <span class="work-description">Business Services</span>
                                                        </span>
                                                    </a>
                                                </div>
                                            </div>


                                            <script type="text/javascript">
                                                jQuery(document).ready(function ($) {
                                                    var $container = $("#stm_works_5cb4bee4c8d29 .stm_works");
                                                    var originLeft = true;
                                                    if ($('body').hasClass('rtl')) {
                                                        originLeft = false;
                                                    }
                                                    $container.isotope({
                                                        layoutMode: 'fitRows',
                                                        itemSelector: '.item',
                                                        transitionDuration: '0.7s',
                                                        isOriginLeft: originLeft,
                                                    });
                                                    $container.imagesLoaded().progress(function () {
                                                        $container.isotope('layout');
                                                    });
                                                    $container.isotope('layout');
                                                    $('#stm_works_5cb4bee4c8d29 .works_filter a').on('click', function () {
                                                        var i = 0;
                                                        if (!$(this).hasClass("stm_works_grid_switcher")) {

                                                            $(this).closest('ul').find('li.active').removeClass('active');
                                                            $(this).parent().addClass('active');
                                                            var sort = $(this).attr('href');
                                                            sort = sort.substring(1);
                                                            $container.isotope({
                                                                filter: '.' + sort
                                                            });
                                                            return false;
                                                        }
                                                    });
                                                    $(document).on('click', '.stm_works_grid_switcher', function () {
                                                        $(this).toggleClass('active');
                                                        var $container_wrapper = $(this).closest('.stm_works_wr');
                                                        if ($('body').hasClass('boxed_layout')) {
                                                            $container_wrapper.toggleClass('wide');
                                                        } else {
                                                            $container_wrapper.toggleClass('wide container');
                                                        }
                                                        //$container_wrapper.find('.stm_works_grid_switcher').closest('.works_filter').toggleClass('container');
                                                        $container.isotope('layout');
                                                        $container.closest('.stm_works').animate({'height': $container.height() + $('#stm_works_stm_works_5cb4bee4c8d29 .stm_works').height()}, 300);
                                                        return false;
                                                    });
                                                    $('#stm_works_5cb4bee4c8d29 .item .category a').on('click', function () {
                                                        if (!$(this).hasClass("stm_works_grid_switcher")) {
                                                            var sort = $(this).attr('href');
                                                            sort = sort.substring(1);
                                                            $('#stm_works_5cb4bee4c8d29 .works_filter li.active').removeClass('active');
                                                            $('#stm_works_5cb4bee4c8d29 .works_filter li a[href="#' + sort + '"]').closest('li').addClass('active');
                                                            $container.isotope({
                                                                filter: '.' + sort
                                                            });
                                                            return false;
                                                        }
                                                    });
                                                });
                                            </script>
                                        </div>
                                    </div><div class="stm-spacing" id="stm-spacing-5cb4bee4cbad8"></div>
                                    <script>
                                        (function ($) {
                                            "use strict";
                                            var spacingID = 'stm-spacing-5cb4bee4cbad8',
                                                    lgSpacing = '47',
                                                    mdSpacing = '47',
                                                    smSpacing = '60',
                                                    xsSpacing = '40';
                                            function stmSpacing() {
                                                if (window.matchMedia("(min-width: 1200px)").matches && lgSpacing) {
                                                    $('#' + spacingID).css("height", lgSpacing);
                                                } else if (window.matchMedia("(max-width: 1199px) and (min-width: 992px )").matches && mdSpacing) {
                                                    $('#' + spacingID).css("height", mdSpacing);
                                                } else if (window.matchMedia("(max-width: 991px) and (min-width: 768px )").matches && smSpacing) {
                                                    $('#' + spacingID).css("height", smSpacing);
                                                } else if (window.matchMedia("(max-width: 767px)").matches && xsSpacing) {
                                                    $('#' + spacingID).css("height", xsSpacing);
                                                } else {
                                                    $('#' + spacingID).css("height", "");
                                                }
                                            }

                                            $(document).ready(function () {
                                                stmSpacing();
                                            });
                                            $(window).resize(function () {
                                                stmSpacing();
                                            });
                                        })(jQuery);
                                    </script>

                                    <div class="stm_animation stm_viewport" style="" data-animate="fadeInUp" data-animation-delay="0.3" data-animation-duration="0.5" data-viewport_position="90" >
                                        <div class="vc_row wpb_row vc_inner vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-2"><div class="vc_column-inner"><div class="wpb_wrapper"></div></div></div><div class="wpb_column vc_column_container vc_col-sm-8"><div class="vc_column-inner"><div class="wpb_wrapper">
                                                        <div class="wpb_text_column wpb_content_element " >
                                                            <div class="wpb_wrapper">
                                                                <p style="text-align: center; line-height: 26px; font-size: 16px;">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo <a href="#">consequat</a>.</p>

                                                            </div>
                                                        </div>
                                                    </div></div></div><div class="wpb_column vc_column_container vc_col-sm-2"><div class="vc_column-inner"><div class="wpb_wrapper"></div></div></div></div></div><div class="stm-spacing" id="stm-spacing-5cb4bee4cc820"></div>
                                    <script>
                                        (function ($) {
                                            "use strict";
                                            var spacingID = 'stm-spacing-5cb4bee4cc820',
                                                    lgSpacing = '56',
                                                    mdSpacing = '56',
                                                    smSpacing = '60',
                                                    xsSpacing = '50';
                                            function stmSpacing() {
                                                if (window.matchMedia("(min-width: 1200px)").matches && lgSpacing) {
                                                    $('#' + spacingID).css("height", lgSpacing);
                                                } else if (window.matchMedia("(max-width: 1199px) and (min-width: 992px )").matches && mdSpacing) {
                                                    $('#' + spacingID).css("height", mdSpacing);
                                                } else if (window.matchMedia("(max-width: 991px) and (min-width: 768px )").matches && smSpacing) {
                                                    $('#' + spacingID).css("height", smSpacing);
                                                } else if (window.matchMedia("(max-width: 767px)").matches && xsSpacing) {
                                                    $('#' + spacingID).css("height", xsSpacing);
                                                } else {
                                                    $('#' + spacingID).css("height", "");
                                                }
                                            }

                                            $(document).ready(function () {
                                                stmSpacing();
                                            });
                                            $(window).resize(function () {
                                                stmSpacing();
                                            });
                                        })(jQuery);
                                    </script>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid vc_custom_1519731513354 vc_row-has-fill">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner ">
                                <div class="wpb_wrapper">
                                    <div class="vc_image_carousel_wr grayscale">
                                        <div class="vc_image_carousel style_1" id="owl-5cb4bee4cd143">
                                            @foreach($partner as $p)
                                            <div class="item">
                                                <a href="">
                                                    <img class="" src="{{ asset('assets/images') }}/{{ $p->image }}" width="180" height="96" alt="placeholder" title="placeholder" />					</a>
                                            </div>

                                            @endforeach
                                        </div>
                                        <script type="text/javascript">
                                            jQuery(document).ready(function ($) {
                                                $(window).load(function () {
                                                    var owlRtl = false;
                                                    if ($('body').hasClass('rtl')) {
                                                        owlRtl = true;
                                                    }
                                                    $("#owl-5cb4bee4cd143").owlCarousel({
                                                        rtl: owlRtl,
                                                        dots: false,
                                                        autoplayTimeout: 5000,
                                                        smartSpeed: 250,
                                                        responsive: {
                                                            0: {
                                                                items: 1},
                                                            768: {
                                                                items: 4},
                                                            980: {
                                                                items: 5},
                                                            1199: {
                                                                items: 6}
                                                        }
                                                    });
                                                });
                                            });
                                        </script>
                                    </div></div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_row-full-width vc_clearfix">

                    </div>
                    <div class="vc_row wpb_row vc_row-fluid">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner ">
                                <div class="wpb_wrapper"><div class="stm-spacing" id="stm-spacing-5cb4bee4ce4f4"></div>
                                    <script>
                                        (function ($) {
                                            "use strict";
                                            var spacingID = 'stm-spacing-5cb4bee4ce4f4',
                                                    lgSpacing = '80',
                                                    mdSpacing = '80',
                                                    smSpacing = '60',
                                                    xsSpacing = '40';
                                            function stmSpacing() {
                                                if (window.matchMedia("(min-width: 1200px)").matches && lgSpacing) {
                                                    $('#' + spacingID).css("height", lgSpacing);
                                                } else if (window.matchMedia("(max-width: 1199px) and (min-width: 992px )").matches && mdSpacing) {
                                                    $('#' + spacingID).css("height", mdSpacing);
                                                } else if (window.matchMedia("(max-width: 991px) and (min-width: 768px )").matches && smSpacing) {
                                                    $('#' + spacingID).css("height", smSpacing);
                                                } else if (window.matchMedia("(max-width: 767px)").matches && xsSpacing) {
                                                    $('#' + spacingID).css("height", xsSpacing);
                                                } else {
                                                    $('#' + spacingID).css("height", "");
                                                }
                                            }

                                            $(document).ready(function () {
                                                stmSpacing();
                                            });
                                            $(window).resize(function () {
                                                stmSpacing();
                                            });
                                        })(jQuery);
                                    </script>

                                    <div class="vc_custom_heading text_align_center" >
                                        <h2 style="text-align: center" >Testimonials</h2>
                                    </div><div class="stm-spacing" id="stm-spacing-5cb4bee4ce7cb"></div>
                                    <script>
                                        (function ($) {
                                            "use strict";
                                            var spacingID = 'stm-spacing-5cb4bee4ce7cb',
                                                    lgSpacing = '8',
                                                    mdSpacing = '8',
                                                    smSpacing = '8',
                                                    xsSpacing = '8';
                                            function stmSpacing() {
                                                if (window.matchMedia("(min-width: 1200px)").matches && lgSpacing) {
                                                    $('#' + spacingID).css("height", lgSpacing);
                                                } else if (window.matchMedia("(max-width: 1199px) and (min-width: 992px )").matches && mdSpacing) {
                                                    $('#' + spacingID).css("height", mdSpacing);
                                                } else if (window.matchMedia("(max-width: 991px) and (min-width: 768px )").matches && smSpacing) {
                                                    $('#' + spacingID).css("height", smSpacing);
                                                } else if (window.matchMedia("(max-width: 767px)").matches && xsSpacing) {
                                                    $('#' + spacingID).css("height", xsSpacing);
                                                } else {
                                                    $('#' + spacingID).css("height", "");
                                                }
                                            }

                                            $(document).ready(function () {
                                                stmSpacing();
                                            });
                                            $(window).resize(function () {
                                                stmSpacing();
                                            });
                                        })(jQuery);
                                    </script>

                                    <div class="vc_row wpb_row vc_inner vc_row-fluid">
                                        <div class="wpb_column vc_column_container vc_col-sm-2">
                                            <div class="vc_column-inner">
                                                <div class="wpb_wrapper">

                                                </div>

                                            </div>

                                        </div>
                                        <div class="wpb_column vc_column_container vc_col-sm-8">
                                            <div class="vc_column-inner">
                                                <div class="wpb_wrapper">
                                                    <div class="wpb_text_column wpb_content_element " >
                                                        <div class="wpb_wrapper">
                                                            <p style="text-align: center; line-height: 26px; font-size: 16px;">Looking cautiously round, to ascertain that they were not overheard, the two hags cowered nearer to the fire, and chuckled heartily.</p>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="wpb_column vc_column_container vc_col-sm-2">
                                            <div class="vc_column-inner">
                                                <div class="wpb_wrapper">

                                                </div>                                                 
                                            </div>                                                
                                        </div>                                           
                                    </div>
                                    <div class="stm-spacing" id="stm-spacing-5cb4bee4cf1fd"></div>
                                    <script>
                                        (function ($) {
                                            "use strict";
                                            var spacingID = 'stm-spacing-5cb4bee4cf1fd',
                                                    lgSpacing = '35',
                                                    mdSpacing = '35',
                                                    smSpacing = '55',
                                                    xsSpacing = '55';
                                            function stmSpacing() {
                                                if (window.matchMedia("(min-width: 1200px)").matches && lgSpacing) {
                                                    $('#' + spacingID).css("height", lgSpacing);
                                                } else if (window.matchMedia("(max-width: 1199px) and (min-width: 992px )").matches && mdSpacing) {
                                                    $('#' + spacingID).css("height", mdSpacing);
                                                } else if (window.matchMedia("(max-width: 991px) and (min-width: 768px )").matches && smSpacing) {
                                                    $('#' + spacingID).css("height", smSpacing);
                                                } else if (window.matchMedia("(max-width: 767px)").matches && xsSpacing) {
                                                    $('#' + spacingID).css("height", xsSpacing);
                                                } else {
                                                    $('#' + spacingID).css("height", "");
                                                }
                                            }

                                            $(document).ready(function () {
                                                stmSpacing();
                                            });
                                            $(window).resize(function () {
                                                stmSpacing();
                                            });
                                        })(jQuery);
                                    </script>

                                    <div class="stm_animation stm_viewport" style="" data-animate="zoomIn" data-animation-delay="0.3" data-animation-duration="0.5" data-viewport_position="90" >
                                        <div class="testimonials_carousel style_1 per_row_3" id="partners_carousel_5cb4bee4d0809">

                                            @foreach ($testimonial as $cat)
                                            <div class="testimonial">
                                                <div class="image">
                                                    <img class="" src="{{ asset('assets/index/wp-content/uploads/2016/06/placeholder-122x122.gif') }}" width="122" height="122" alt="placeholder" title="placeholder" />	
                                                </div>
                                                <div class="info">
                                                    <h4 class="no_stripe"> {{ $cat->name }}</h4>
                                                    <div class="position">{{ $cat->position }}</div>
                                                    <!--                                                    <div class="company">Arcade Systems</div>-->
                                                    <p>&#8220;{{ $cat->description }}.&#8221;</p>
                                                </div>
                                            </div>
                                            @endforeach

                                        </div>
                                        <script type="text/javascript">
                                            jQuery(document).ready(function ($) {
                                                "use strict";
                                                var partners_carousel_5cb4bee4d0809 = $("#partners_carousel_5cb4bee4d0809");
                                                var slickRtl = false;
                                                if ($('body').hasClass('rtl')) {
                                                    slickRtl = true;
                                                }


                                                partners_carousel_5cb4bee4d0809.slick({
                                                    rtl: slickRtl,
                                                    dots: false,
                                                    infinite: true,
                                                    arrows: true, prevArrow: "<div class=\"slick_prev\"><i class=\"fa fa-chevron-left\"></i></div>", nextArrow: "<div class=\"slick_next\"><i class=\"fa fa-chevron-right\"></i></div>", autoplaySpeed: 5000,
                                                    autoplay: false,
                                                    slidesToShow: 3,
                                                    cssEase: "cubic-bezier(0.455, 0.030, 0.515, 0.955)",
                                                    responsive: [
                                                        {
                                                            breakpoint: 769,
                                                            settings: {
                                                                slidesToShow: 1
                                                            }
                                                        }
                                                    ]
                                                });
                                            });
                                        </script>
                                    </div><div class="stm-spacing" id="stm-spacing-5cb4bee4d303e"></div>
                                    <script>
                                        (function ($) {
                                            "use strict";
                                            var spacingID = 'stm-spacing-5cb4bee4d303e',
                                                    lgSpacing = '84',
                                                    mdSpacing = '84',
                                                    smSpacing = '70',
                                                    xsSpacing = '50';
                                            function stmSpacing() {
                                                if (window.matchMedia("(min-width: 1200px)").matches && lgSpacing) {
                                                    $('#' + spacingID).css("height", lgSpacing);
                                                } else if (window.matchMedia("(max-width: 1199px) and (min-width: 992px )").matches && mdSpacing) {
                                                    $('#' + spacingID).css("height", mdSpacing);
                                                } else if (window.matchMedia("(max-width: 991px) and (min-width: 768px )").matches && smSpacing) {
                                                    $('#' + spacingID).css("height", smSpacing);
                                                } else if (window.matchMedia("(max-width: 767px)").matches && xsSpacing) {
                                                    $('#' + spacingID).css("height", xsSpacing);
                                                } else {
                                                    $('#' + spacingID).css("height", "");
                                                }
                                            }

                                            $(document).ready(function () {
                                                stmSpacing();
                                            });
                                            $(window).resize(function () {
                                                stmSpacing();
                                            });
                                        })(jQuery);
                                    </script>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </article>
        </div>

    </div> <!--.container-->
</div> <!--#main-->

@include('front.footer')