@include('front.header')  

<section id="main-content" class="" style="width: 100%">
    <div id="demos" style="width: 100%">
        <div style="width: 100%; height:40px; background-color: #FFFFFF; overflow:hidden; box-sizing: border-box; border: 1px solid #56667F; border-radius: 4px; text-align: right; line-height:14px; block-size:40px; font-size: 12px; box-sizing:content-box; font-feature-settings: normal; text-size-adjust: 100%; box-shadow: inset 0 -20px 0 0 #56667F;padding:1px;padding: 0px; margin: 0px;">
            <div style="height:40px;">
                <iframe src="https://widget.coinlib.io/widget?type=horizontal_v2&theme=light&pref_coin_id=1505&invert_hover=" width="100%" height="40" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" border="0" style="border:0;margin:0;padding:0;">

                </iframe>
            </div>

        </div>
    </div>
</section>

<section id="inner_page_infor" class="innerpage_banner">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="full">
                    <div class="inner_page_info">
                        <h3>FAQS</h3>
                        <ul>
                            <li><a href="{{route('home')}}">Home</a></li>
                            <li><i class="fa fa-angle-right"></i></li>
                            <li><a href="">FAQS</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<!-- section -->
<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800" rel="stylesheet">

<!-- BASE CSS -->
<!--<link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet">-->
<link href="{{ asset('assets/css/style.css') }}" rel="stylesheet">
<!--<link href="{{ asset('assets/css/menu.css') }}" rel="stylesheet">-->
<!--<link href="{{ asset('assets/css/vendors.css') }}" rel="stylesheet">-->
<link href="{{ asset('assets/css/icon_fonts/css/all_icons_min.css') }}" rel="stylesheet">


<main>

    <div class="container margin_60">
        <div class="row">
           

            <div class="col-lg-12" id="faq">
                <div role="tablist" class="add_bottom_45 accordion" id="payment">           
                    <!-- /card -->
                    <div class="card">
                        <div class="card-header" role="tab">
                            <h5 class="mb-0">
                                <a class="collapsed" data-toggle="collapse" href="#collapseOne_payment" aria-expanded="false">
                                    <i class="indicator icon_plus_alt2"></i>IS FBXGLOBAL.COM FREE TO JOIN?
                                </a>
                            </h5>
                        </div>
                        <div id="collapseOne_payment" class="collapse" role="tabpanel" data-parent="#payment">
                            <div class="card-body">
                                <p>No. To join FOBEX GLOBAL and become an investor with them, you must deposit 100$ registration fees before choosing your investment package. </p>
                            </div>
                        </div>
                    </div>
                    <!-- /card -->
                     <div class="card">
                        <div class="card-header" role="tab">
                            <h5 class="mb-0">
                                <a class="collapsed" data-toggle="collapse" href="#collapseT_payment" aria-expanded="false">
                                    <i class="indicator icon_plus_alt2"></i>IS FOBEX GLOBAL  LEGAL?
                                </a>
                            </h5>
                        </div>
                        <div id="collapseT_payment" class="collapse" role="tabpanel" data-parent="#payment">
                            <div class="card-body">
                                <p>Yes, it is legal, We present an investment service that allow Investor to make profit by trusting FOBEX GLOBAL to invest for them and share gains. All Investors that purchase Investment Packs will get guaranteed percentage of the gains. </p>
                            </div>
                        </div>
                    </div>
                    <!-- /card -->
                    <!-- /card -->
                     <div class="card">
                        <div class="card-header" role="tab">
                            <h5 class="mb-0">
                                <a class="collapsed" data-toggle="collapse" href="#collapseR_payment" aria-expanded="false">
                                    <i class="indicator icon_plus_alt2"></i>WHO CAN BE A INVESTOR OF FOBEX GLOBAL?
                                </a>
                            </h5>
                        </div>
                        <div id="collapseR_payment" class="collapse" role="tabpanel" data-parent="#payment">
                            <div class="card-body">
                                <p>Everyone may be Investor of FOBEX GLOBAL, regardless of nationality or residence. The only condition is, you must be of mature age (at least 18 years old) to become our Investor.</p>
                            </div>
                        </div>
                    </div>
                    <!-- /card -->
                    <!-- /card -->
                     <div class="card">
                        <div class="card-header" role="tab">
                            <h5 class="mb-0">
                                <a class="collapsed" data-toggle="collapse" href="#collapseAA_payment" aria-expanded="false">
                                    <i class="indicator icon_plus_alt2"></i>CAN I JOIN WITHOUT A SPONSOR?
                                </a>
                            </h5>
                        </div>
                        <div id="collapseAA_payment" class="collapse" role="tabpanel" data-parent="#payment">
                            <div class="card-body">
                                <p>Yes really. You can only join us by registering at the company website www.fobexglobal.com .</p>
                            </div>
                        </div>
                    </div>
                    <!-- /card -->
                     <!-- /card -->
                     <div class="card">
                        <div class="card-header" role="tab">
                            <h5 class="mb-0">
                                <a class="collapsed" data-toggle="collapse" href="#collapseBB_payment" aria-expanded="false">
                                    <i class="indicator icon_plus_alt2"></i>CAN I HAVE MULTIPLE ACCOUNTS?
                                </a>
                            </h5>
                        </div>
                        <div id="collapseBB_payment" class="collapse" role="tabpanel" data-parent="#payment">
                            <div class="card-body">
                                <p>No. You don’t have the right to open multiple accounts.</p>
                            </div>
                        </div>
                    </div>
                    <!-- /card -->
                     <!-- /card -->
                     <div class="card">
                        <div class="card-header" role="tab">
                            <h5 class="mb-0">
                                <a class="collapsed" data-toggle="collapse" href="#collapseCC_payment" aria-expanded="false">
                                    <i class="indicator icon_plus_alt2"></i>IS MY PERSONAL INFORMATION PROTECTED WITH YOUR COMPANY?
                                </a>
                            </h5>
                        </div>
                        <div id="collapseCC_payment" class="collapse" role="tabpanel" data-parent="#payment">
                            <div class="card-body">
                                <p>Any personal information that you provide us with are privacy protected. Your information will never be shared to anyone.</p>
                            </div>
                        </div>
                    </div>
                    <!-- /card -->
                     <!-- /card -->
                     <div class="card">
                        <div class="card-header" role="tab">
                            <h5 class="mb-0">
                                <a class="collapsed" data-toggle="collapse" href="#collapseEE_payment" aria-expanded="false">
                                    <i class="indicator icon_plus_alt2"></i>WHY HAS MY ACCOUNT BEEN DELETED?
                                </a>
                            </h5>
                        </div>
                        <div id="collapseEE_payment" class="collapse" role="tabpanel" data-parent="#payment">
                            <div class="card-body">
                                <p>Accounts may be deleted for reasons, not limited to, inappropriate behavior/abuse towards other members and/or the administration of FOBEX GLOBAL /filing of payment disputes and several other reasons. If you believe that none of the above is true and still your account has been deleted, please contact us.</p>
                            </div>
                        </div>
                    </div>
                    <!-- /card -->
                     <!-- /card -->
                     <div class="card">
                        <div class="card-header" role="tab">
                            <h5 class="mb-0">
                                <a class="collapsed" data-toggle="collapse" href="#collapseDD_payment" aria-expanded="false">
                                    <i class="indicator icon_plus_alt2"></i>WHAT PAYMENT PROCESSORS ARE USED IN FOBEX GLOBAL?
                                </a>
                            </h5>
                        </div>
                        <div id="collapseDD_payment" class="collapse" role="tabpanel" data-parent="#payment">
                            <div class="card-body">
                                <p>We accept Bitcoin, Perfect money, Bank transfer.</p>
                            </div>
                        </div>
                    </div>
                    <!-- /card -->
                    
                    <!-- /card -->
                     <div class="card">
                        <div class="card-header" role="tab">
                            <h5 class="mb-0">
                                <a class="collapsed" data-toggle="collapse" href="#collapseHH_payment" aria-expanded="false">
                                    <i class="indicator icon_plus_alt2"></i>HOW LONG DOES IT TAKE TO PURCHASE?
                                </a>
                            </h5>
                        </div>
                        <div id="collapseHH_payment" class="collapse" role="tabpanel" data-parent="#payment">
                            <div class="card-body">
                                <p> All creatives are processed from 10 to 20 of each month and the investment package will appear in your account at the beginning of the following month.
If the payment is not processed after the third day of the month at most, please send a support card with complete transaction details.
</p>
                            </div>
                        </div>
                    </div>
                    <!-- /card -->
                    
                     <!-- /card -->
                     <div class="card">
                        <div class="card-header" role="tab">
                            <h5 class="mb-0">
                                <a class="collapsed" data-toggle="collapse" href="#collapseMM_payment" aria-expanded="false">
                                    <i class="indicator icon_plus_alt2"></i>WHAT ABOUT REFERRAL COMMITTEES?
                                </a>
                            </h5>
                        </div>
                        <div id="collapseMM_payment" class="collapse" role="tabpanel" data-parent="#payment">
                            <div class="card-body">
                                <p>The referral commission is 10% for each purchased PLAN. The referral committee is for direct referrals only.</p>
                            </div>
                        </div>
                    </div>
                    <!-- /card -->
                     <!-- /card -->
                     <div class="card">
                        <div class="card-header" role="tab">
                            <h5 class="mb-0">
                                <a class="collapsed" data-toggle="collapse" href="#collapseSS_payment" aria-expanded="false">
                                    <i class="indicator icon_plus_alt2"></i>HOW LONG DOES IT TAKE TO RELEASE THE WITHDRAWAL?
                                </a>
                            </h5>
                        </div>
                        <div id="collapseSS_payment" class="collapse" role="tabpanel" data-parent="#payment">
                            <div class="card-body">
                                <p>Debit requests are processed every month and if you still have not withdrawn after 48 hours, please write to support.
                            </div>
                        </div>
                    </div>
                    <!-- /card -->
                     <!-- /card -->
                     <div class="card">
                        <div class="card-header" role="tab">
                            <h5 class="mb-0">
                                <a class="collapsed" data-toggle="collapse" href="#collapseOO_payment" aria-expanded="false">
                                    <i class="indicator icon_plus_alt2"></i>MY QUESTION IS NOT ANSWERED HERE. WHAT CAN I DO?
                                </a>
                            </h5>
                        </div>
                        <div id="collapseOO_payment" class="collapse" role="tabpanel" data-parent="#payment">
                            <div class="card-body">
                                <p>Please use the "Support" page to submit your question to us. One of our support staff will respond within 24 hours to a maximum of 48 hours.</p>
                            </div>
                        </div>
                    </div>
                    <!-- /card -->
                  
              
                    <!-- /card -->
                </div>
                <!-- /accordion payment -->
            </div>
            <!-- /col -->
        </div>
        <!-- /row -->
    </div>
    <!-- /container -->
</main>
<!-- /main -->
<!-- end section -->



@include('front.footer')