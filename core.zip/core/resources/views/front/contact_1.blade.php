@include('front.header')
<div id="main" >
    <div class="container">
        <div class="content-area">
            <article id="post-1071" class="post-1071 page type-page status-publish hentry">
                  <div class="entry-content" style="margin-top: 150px">
                    <div class="row" style="margin-left: -110px ;margin-bottom: 15px ;width: 120% ;height: 400px ; background: url('{{asset('assets/images/front-bg/image_header.jpg')}}')">
                        <div class="container" style="text-align: center ; margin-top: 150px">
                            <h1 style="color: #ecf1f5">CONTACT WITH US</h1>
                           <span><a href="{{route('home')}}">Home</a> / <span>contact</span></span>
                        </div>
                    </div>

                    <div class="container">
                        <div class="row">
                            <div class="col-md-6 col-md-offset-3">
                                @if (session()->has('message'))
                                <div style="margin-bottom: 20px;margin-top: 20px;" class="alert alert-success alert-dismissable">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    {{ session()->get('message') }}
                                </div>
                                @endif
                            </div>
                        </div>
                    </div>

                    <!--=-=-=-=-=-=-=-=-=-=-=-=
                         CONTACT US   
                -=-=-=-=-=-=-=-=-==-=-=-=-=-->
                    <section id="contact">
                        <div class="container">
                            <div class="contact-inner">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="contact-form">
                                            <div class="title">
                                                <h3>Put a Note:</h3>
                                            </div>
                                            {{ Form::open() }}
                                            <div class="form-group">
                                                <input type="text" name="name" placeholder="Name *" required class="form-control" aria-describedby="basic-addon2">
                                                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                            </div>
                                            <div class="form-group">
                                                <input type="email" name="email" placeholder="Email *" required class="form-control" aria-describedby="basic-addon3">
                                                <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                                            </div>
                                            <div class="form-group">
                                                <input type="text" name="subject" placeholder="Subject *" required class="form-control" aria-describedby="basic-addon3">
                                                <span class="input-group-addon"><i class="fa fa-info"></i></span>
                                            </div>
                                            <div class="form-group">
                                                <textarea name="message" class="form-control" placeholder="Message *" required rows="5" ></textarea>
                                                <span class="input-group-addon"><i class="fa fa-paper-plane"></i></span>
                                            </div>
                                            <input type="submit" value="send message" class="btn btn-default">
                                            {!! Form::close() !!}
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="contact-info">
                                            <div class="title">
                                                <h3>Address:</h3>
                                            </div>
                                            <div class="info-main">
                                                <p style="text-align:justify;">{!! $general->about_text_contact  !!}</p>
                                                <span class="location"><i class="fa fa-map-marker"></i> {{ $general->address }}</span>
                                                <span class="phone"><i class="fa fa-phone"></i> {{ $general->number }}</span>
                                                <span class="email"><i class="fa fa-envelope"></i>
                                                    {{ $general->email }}</span>
                                            </div>
                                            <div class="social-icon">
                                                <ul class="no-style">
                                                    <li><a href="{{$general->facebook}}"><span class="fa fa-facebook"></span></a></li>
                                                    <li><a href="{{$general->twitter}}"><span class="fa fa-twitter"></span></a></li>
                                                    <li><a href="{{$general->google_plus}}"><span class="fa fa-google-plus"></span></a></li>
                                                    <li><a href="{{$general->linkedin}}"><span class="fa fa-linkedin"></span></a></li>
                                                    <li><a href="{{$general->youtube}}"><span class="fa fa-youtube"></span></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="map">
                            <div class="container-fluid">
                                <div class="map-main">
                                    <iframe src="{{$general->google_map_link}}" allowfullscreen>
                                    </iframe>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </article>
        </div>
    </div>
</div> 
@include('front.footer')


