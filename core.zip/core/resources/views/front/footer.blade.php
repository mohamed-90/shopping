

<footer id="footer" class="footer_main">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="footer_logo">
                    <img src="{{ asset('assets/images/logo/fbxglobal-logo-white.png') }}" alt="#" />
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="main-heading left_text">
                    <h2>Quick links</h2>
                </div>
                <ul class="footer-menu" style="width:50%;">
                    <li><a href="{{ route('home') }}"><i class="fa fa-angle-right"></i> Home</a></li>
                     <li><a href="{{ route('faqs') }}"><i class="fa fa-angle-right"></i> FAQS</a></li>
                    <li><a href="{{ route('contact') }}"><i class="fa fa-angle-right"></i> Contact</a></li>
                </ul>
             
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="main-heading left_text">
                    <h2>Contact us</h2>
                </div>
                <p><a href="emailto:info@demo.com">support@fbxglobal.com</a></p>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="main-heading left_text">
                    <h2>Social media</h2>
                </div>                
                <div class="footer_mail-section" style="width: 90%;">
                   <ul class="social_icons">
                    <li><a href="{{$general->facebook}}" target="_blank"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="{{$general->twitter}}" target="_blank"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="{{$general->youtube}}" target="_blank"><i class="fa fa-youtube"></i></a></li>
                </ul>
                </div>
                
            </div>
        </div>
    </div>
</footer>
<div class="footer-bottom">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12 pull-left">
                <p class="text-center">  © Copyright 2019 Fobex global  - All Rights Reserved. Created By <a href='https://www.iker.ma/' target='_blank'>iker.ma</a></p>
            </div>
        </div>
    </div>
</div>
<!-- search form -->
<!-- Modal -->
<div class="modal fade" id="search_form" role="dialog">
    <button type="button" class="cross_btn close" data-dismiss="modal"><span aria-hidden="true">&times;</span></button>
    <div class="search_bar_inner">
        <form class="search_bar_inner_form" action="">
            <div class="field_form">
                <input type="text" placeholder="Search" />
                <button type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
            </div>
        </form>
    </div>
</div>


<!-- end search form -->
<!-- jQuery (necessary for Bootstrap's JavaScript) -->
<script src="{{ asset('assets/frontEnd/js/jquery.min.js') }}"></script>
<!-- custom js -->
<script src="{{ asset('assets/frontEnd/js/custom.js') }}"></script>


<script>
 
$(function(){
    var anchor = $("#main-content > #w_horizontal_marquee2 a");
    
    anchor.on("click", function(e){
     e.preventDefault();   
     alert("Ok");
 });
 
});


</script>
</body>
</html>