@include('front.header')  

<section id="main-content" class="" style="width: 100%">
        <div id="demos" style="width: 100%">
        <div style="width: 100%; height:40px; background-color: #FFFFFF; overflow:hidden; box-sizing: border-box; border: 1px solid #56667F; border-radius: 4px; text-align: right; line-height:14px; block-size:40px; font-size: 12px; box-sizing:content-box; font-feature-settings: normal; text-size-adjust: 100%; box-shadow: inset 0 -20px 0 0 #56667F;padding:1px;padding: 0px; margin: 0px;">
            <div style="height:40px;">
                <iframe src="https://widget.coinlib.io/widget?type=horizontal_v2&theme=light&pref_coin_id=1505&invert_hover=" width="100%" height="40" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" border="0" style="border:0;margin:0;padding:0;">

                </iframe>
            </div>

        </div>
    </div>
</section>

    <section id="inner_page_infor" class="innerpage_banner">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="full">
                        <div class="inner_page_info">
                            <h3>ALL NEWS</h3>
                            <ul>
                                <li><a href="{{route('home')}}">Home</a></li>
                                <li><i class="fa fa-angle-right"></i></li>
                                <li><a href="">ALL NEWS</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

  <section id="blog">
                        <div class="container">
                            <div class="blog-inner">
                                <div class="title common text-center">
                                    <hr>
                                    <h2>ALL NEWS</h2>
                                    <br>
                                </div>
                                <div class="main">
                                    @foreach($news as $n)

                                    @if($n->id % 2 == 0 )
                                    <div class="item left">
                                        <div class="row">
                                            <div class="col-md-5">
                                                <img src="{{ asset('assets/images') }}/{{ $n->image }}" class="img-responsive" alt="news-img">
                                            </div>
                                            <div class="col-md-7">
                                                <div class="item-title">
                                                    <h2>{{ $n->title }}</h2>
                                                    <div class="item-info">
                                                        <i class="fa fa-bars"></i> Posted On {{ $n->category->name }}
                                                        <i class="fa fa-calendar"></i> {{ \Carbon\Carbon::parse($n->created_at)->format('d F Y') }} 
                                                    </div>
                                                </div>
                                                <div class="item-text">
                                                    <p> {!! substr(strip_tags($n->description),0,280) !!}{{ strlen(strip_tags($n->description)) > 280 ? "..." : "" }}</p>
                                                </div>
                                                <a href="{{ route('news-details',['id'=>$n->id,'slug'=>str_slug($n->title)]) }}" target="_blank" class="btn btn-info">read more <span class="fa fa-angle-double-right"></span></a>
                                            </div>
                                        </div>
                                    </div>
                                    @else
                                    <div class="item right">
                                        <div class="row">
                                            <div class="col-md-5 col-md-push-7 col-lg-push-7">
                                                <img src="{{ asset('assets/images') }}/{{ $n->image }}" class="img-responsive" alt="">
                                            </div>
                                            <div class="col-md-7 col-md-pull-5 col-lg-pull-5">
                                                <div class="item-title">
                                                    <h2>{{ $n->title }}</h2>
                                                    <div class="item-info">
                                                        <i class="fa fa-bars"></i> Posted On {{ $n->category->name }}
                                                        <i class="fa fa-calendar"></i> {{ \Carbon\Carbon::parse($n->created_at)->format('d F Y') }} 
                                                    </div>
                                                </div>
                                                <div class="item-text">
                                                    <p> {!! substr(strip_tags($n->description),0,280) !!}{{ strlen(strip_tags($n->description)) > 280 ? "..." : "" }}</p>
                                                </div>
                                                <a href="{{ route('news-details',['id'=>$n->id,'slug'=>str_slug($n->title)]) }}" target="_blank" class="btn btn-info">read more <span class="fa fa-angle-double-right"></span></a>
                                            </div>
                                        </div>
                                    </div>
                                    @endif
                                    <hr>
                                    @endforeach 
                                </div>
                            </div>
                        </div>
                    </section>
    
    @include('front.footer')