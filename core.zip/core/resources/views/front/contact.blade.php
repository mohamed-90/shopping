@include('front.header')  

<section id="main-content" class="" style="width: 100%">
     <div id="demos" style="width: 100%">
        <div style="width: 100%; height:40px; background-color: #FFFFFF; overflow:hidden; box-sizing: border-box; border: 1px solid #56667F; border-radius: 4px; text-align: right; line-height:14px; block-size:40px; font-size: 12px; box-sizing:content-box; font-feature-settings: normal; text-size-adjust: 100%; box-shadow: inset 0 -20px 0 0 #56667F;padding:1px;padding: 0px; margin: 0px;">
            <div style="height:40px;">
                <iframe src="https://widget.coinlib.io/widget?type=horizontal_v2&theme=light&pref_coin_id=1505&invert_hover=" width="100%" height="40" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" border="0" style="border:0;margin:0;padding:0;">

                </iframe>
            </div>

        </div>
    </div>
</section>

<section id="inner_page_infor" class="innerpage_banner">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="full">
                    <div class="inner_page_info">
                        <h3>Contact US</h3>
                        <ul>
                            <li><a href="#">Home</a></li>
                            <li><i class="fa fa-angle-right"></i></li>
                            <li><a href="#">Contact US</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="container">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            @if (session()->has('message'))
            <div style="margin-bottom: 20px;margin-top: 20px;" class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                {{ session()->get('message') }}
            </div>
            @endif
        </div>
    </div>
</div>
<!-- section -->
<section class="layout_padding">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs">
                <div class="full">
                    <div class="heading_main">
                        <h2><span>CONTACT US</span></h2>
                        <p>You can contact us by using the form below for all your questions and suggestions.</p>
                    </div>
                </div>
            </div>

            <div class="contact_form">
                <div class="form_section">
                    {{ Form::open() }}
                    <fieldset>
                        <div class="field col-lg-6 col-md-6 col-sm-12 col-xs-12">
                            <input name="name" class="field_custom" placeholder="Full name" type="text">
                        </div>

                        <div class="field col-lg-6 col-md-6 col-sm-12 col-xs-12">
                            <input name="email" class="field_custom" placeholder="Email adress" type="email">
                        </div>
                        <div class="field col-lg-6 col-md-6 col-sm-12 col-xs-12">
                            <input name="phone" class="field_custom" placeholder="Phone" type="phone">
                        </div>
                        <div class="field col-lg-6 col-md-6 col-sm-12 col-xs-12">
                            <input name="subject" class="field_custom" placeholder="subject" type="text">
                        </div>
                        <div class="field col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <textarea name="message" class="field_custom" placeholder="Messager"></textarea>
                        </div>
                        <div class="center">

                            <input type="submit" value="SUBMIT NOW" class="btn main_btn">
                        </div>
                    </fieldset>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end section -->


@include('front.footer')