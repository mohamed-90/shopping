@include('front.header')  

<section id="main-content" class="" style="width: 100%">
     <div id="demos" style="width: 100%">
        <div style="width: 100%; height:40px; background-color: #FFFFFF; overflow:hidden; box-sizing: border-box; border: 1px solid #56667F; border-radius: 4px; text-align: right; line-height:14px; block-size:40px; font-size: 12px; box-sizing:content-box; font-feature-settings: normal; text-size-adjust: 100%; box-shadow: inset 0 -20px 0 0 #56667F;padding:1px;padding: 0px; margin: 0px;">
            <div style="height:40px;">
                <iframe src="https://widget.coinlib.io/widget?type=horizontal_v2&theme=light&pref_coin_id=1505&invert_hover=" width="100%" height="40" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" border="0" style="border:0;margin:0;padding:0;">

                </iframe>
            </div>

        </div>
    </div>
</section>

    <section id="inner_page_infor" class="innerpage_banner">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="full">
                        <div class="inner_page_info">
                            <h3>DETAILS NEWS</h3>
                            <ul>
                                <li><a href="{{route('home')}}">Home</a></li>
                                <li><i class="fa fa-angle-right"></i></li>
                                <li><a href="">DETAILS NEWS</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- section -->
      <section id="blog-details">
          <hr>
          <br>
                        <div class="container">
                            <div class="bd-inner">
                                <div class="row">
                                    <div class="col-md-12">

                                        <!-- ========== Main post ========= -->
                                        <div class="post-main">
                                            <div class="post-header">
                                                
                                                <div class="details">
                                                    <h1 class="header">{{$news->title}}</h1>
                                                    <span class="meta"><span class="data"><i class="fa fa-calendar">
                                                        </i> {{ \Carbon\Carbon::parse($news->created_at)->format('d F Y') }}
                                                        </span> | 
                                                        <i class="fa fa-bars">                                                          
                                                        </i>
                                                        <a href="{{ route('category-news',['id'=>$news->category->id,'slug'=>str_slug($news->category->name)]) }}" class="author"> Posted On {{ $news->category->name }}
                                                        </a>
                                                    </span>
                                                </div>
                                                <img src="{{ asset('assets/images') }}/{{ $news->image }}" alt="">
                                            </div>
                                            <div class="post-body">
                                                <p>{!!$news->description!!}</p>
                                            </div>
                                        </div>

                                        <!-- ======= POST-SHARE-ICONS ======= -->

                                        <div class="share-icons">
                                            <div class="views">

                                                <p> <i class="fa fa-eye"></i> View: @php $gr = \App\News::findOrFail($news->id) @endphp {{ $gr->view }}</p>

                                            </div>
                                            

                                        </div>
                                        <hr/>

                                        <!-- ======== COMMENT-BOX ======== -->
                                        <div class="comment-box">
                                            <h2>Comments</h2>
                                            <div class="comment-list">
                                                <div id="fb-root"></div>
                                                <script>(function (d, s, id) {
                                                        var js, fjs = d.getElementsByTagName(s)[0];
                                                        if (d.getElementById(id))
                                                            return;
                                                        js = d.createElement(s);
                                                        js.id = id;
                                                        js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.8&appId=1421567158073949";
                                                        fjs.parentNode.insertBefore(js, fjs);
                                                    }(document, 'script', 'facebook-jssdk'));
                                                </script>
                                                <div class="fb-comments" data-href="{{ url()->current() }}" data-width="100%" data-numposts="5"></div>
                                            </div>
                                        </div>

                                    </div>

                                    <!-- =========== SIDEBAR ========== -->
                                    <div class="col-md-4">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
    <!-- end section -->


    
    @include('front.footer')