@include('front.header')  

<section id="main-content" class="" style="width: 100%">
     <div id="demos" style="width: 100%">
        <div style="width: 100%; height:40px; background-color: #FFFFFF; overflow:hidden; box-sizing: border-box; border: 1px solid #56667F; border-radius: 4px; text-align: right; line-height:14px; block-size:40px; font-size: 12px; box-sizing:content-box; font-feature-settings: normal; text-size-adjust: 100%; box-shadow: inset 0 -20px 0 0 #56667F;padding:1px;padding: 0px; margin: 0px;">
            <div style="height:40px;">
                <iframe src="https://widget.coinlib.io/widget?type=horizontal_v2&theme=light&pref_coin_id=1505&invert_hover=" width="100%" height="40" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" border="0" style="border:0;margin:0;padding:0;">

                </iframe>
            </div>

        </div>
    </div>
</section>

    <section id="inner_page_infor" class="innerpage_banner">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="full">
                        <div class="inner_page_info">
                            <h3>{{ $menu1->name}}</h3>
                            <ul>
                                <li><a href="{{route('home')}}">Home</a></li>
                                <li><i class="fa fa-angle-right"></i></li>
                                <li><a href="">{{ $menu1->name}}</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- section -->
    <section class="layout_padding about_bg_compu">
        <div class="container">
            <div class="row">
                <div class="col-md-7 col-sm-12 col-xs-12">
                    <div class="full">
                         {!! $menu1->description !!}
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- end section -->


    
    @include('front.footer')