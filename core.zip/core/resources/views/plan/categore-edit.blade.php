@extends('layouts.dashboard')
@section('style')

    <link rel="stylesheet" href="{{ asset('assets/dashboard/css/cus.css') }}">
    <link href="{{ asset('assets/dashboard/css/bootstrap-toggle.min.css') }}" rel="stylesheet">
@endsection
@section('content')

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default panel-shadow" data-collapsed="0"><!-- to apply shadow add class "panel-shadow" -->
                <!-- panel body -->
                <div class="panel-body">
                      {!! Form::model($categore,['route'=>['categore-update',$categore->id],'method'=>'put','class'=>'form-horizontal','files'=>true]) !!}
                    <div class="form-body">

                        <div class="form-group">
                            <label class="col-sm-3 control-label">Category Name : </label>

                            <div class="col-sm-6">
                                <input type="text" name="type" id="" value="{{ $categore->type }}" class="form-control input-lg" required placeholder="Category Name">
                            </div>
                        </div>
                         <div class="form-group">
                            <label class="col-sm-3 control-label">Category Description : </label>

                            <div class="col-sm-6">
                                <input type="text" name="description" id="" value="{{ $categore->description }}" class="form-control input-lg" required placeholder="Category Description">
                            </div>
                        </div>
                      
                        <div class="form-group">

                            <div class="row">
                                <div class="col-md-offset-3 col-md-6">
                                    <button type="submit" class="btn btn-info btn-block margin-top-10"><i class="fa fa-paper-plane"></i> Update Category</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    {!! Form::close() !!}
                </div>

            </div>
        </div>
    </div><!---ROW-->


@endsection
@section('scripts')

    <script src="{{ asset('assets/dashboard/js/fileinput.js') }}"></script>
    <script src="{{ asset('assets/dashboard/js/bootstrap-toggle.min.js') }}"></script>

@endsection

