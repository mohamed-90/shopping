@include('front.header') 

<section id="inner_page_infor" class="innerpage_banner">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="full">
                    <div class="inner_page_info">
                        <h3>Mail Verify</h3>
                        <ul>
                            <li><a href="{{route('home')}}">Home</a></li>
                            <li><i class="fa fa-angle-right"></i></li>
                            <li><a href="">Mail Verify</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> 

    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Verify.</div>
                    <div class="panel-body">
                        <div class="text-center">
                            <h4 class="color-red">Check Your MailBox and Verify Your Account.</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@include('front.footer')
