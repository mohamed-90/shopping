@include('front.header') 

<section id="inner_page_infor" class="innerpage_banner">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="full">
                    <div class="inner_page_info">
                        <h3>Password Reset</h3>
                        <ul>
                            <li><a href="{{route('home')}}">Home</a></li>
                            <li><i class="fa fa-angle-right"></i></li>
                            <li><a href="">Password Reset</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            @if (session()->has('message'))
            <div style="margin-top: 20px;margin-bottom: -10px;" class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                {{ session()->get('message') }}
            </div>
            @endif
            @if (session()->has('status'))
            <div style="margin-top: 20px;margin-bottom: -10px;" class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                {{ session()->get('status') }}
            </div>
            @endif

            @if($errors->any())

            @foreach ($errors->all() as $error)

            <div style="margin-top: 20px;margin-bottom: -20px;" class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                {!!  $error !!}
            </div>

            @endforeach
            @endif
        </div>
    </div>

</div>

<!--=-=-=-=-=-=-=-=-=-=-=-=
     FORGOT PASSWORD   
-=-=-=-=-=-=-=-=-==-=-=-=-=-->
<section id="forgot">
    <div class="container">
        <div class="section-inner">
            <center > 
                <div class="sign-main">
                    <div class="title">
                        <h3><span class="fa fa-question-circle"></span> Password Reset</h3>
                    </div>
                    <div class="main-form">
                        <form action="{{ route('password.request') }}" method="post" accept-charset="utf-8" class="block">
                            {!! csrf_field() !!}
                            <input type="hidden" name="token" value="{{ $token }}">
                            <div class="input-group col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                <input type="email" name="email" value="{{ old('email') }}" class="form-control" placeholder="Enter Mail id *">
                            </div>

                            <div class="input-group col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="password" name="password" class="form-control" required placeholder="Enter Password">
                            </div>

                            <div class="input-group col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                <span class="input-group-addon"><i class="fa fa-unlock"></i></span>
                                <input type="password" name="password_confirmation" class="form-control" required placeholder="Confirm Password">
                            </div>
                             <br>
                             <script src="https://www.google.com/recaptcha/api.js" async defer></script>
                            <div class="input-group col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                <div class="g-recaptcha" data-sitekey="{{env('CAPTCHA_KEY')}}">
                                     @if ($errors->has('g-recaptcha-response'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('g-recaptcha-response') }}</strong>
                                </span>
                                @endif
                                </div>
                            </div>

                            <input type="submit" value="Password Reset" class="btn main_btn">
                        </form>
                        <br>
                    </div>
                    <span class="forgot bottom"><i class="fa fa-question-circle"></i> Need an Account? <a href="registration.html">Sign Up</a></span>
                </div>
                <center > 
                    </div>
                    </div>
                    </section>

                    @endsection
