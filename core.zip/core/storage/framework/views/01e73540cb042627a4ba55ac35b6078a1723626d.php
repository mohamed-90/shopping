<?php echo $__env->make('front.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="main" >
    <div class="container">
        <div class="content-area">
            <article id="post-1071" class="post-1071 page type-page status-publish hentry">
                <div class="entry-content" style="margin-top: 150px">
                    <div class="row" style="margin-left: -110px ;margin-bottom: 15px ;width: 120% ;height: 400px ; background: url('<?php echo e(asset('assets/images/front-bg/image_header.jpg')); ?>')">
                        <div class="container" style="text-align: center ; margin-top: 150px">
                            <h1 style="color: #ecf1f5"><?php echo e($menu1->name); ?></h1>
                          <span><a href="<?php echo e(route('home')); ?>">Home</a> / <span><?php echo e($menu1->name); ?></span></span>
                        </div>
                    </div>

                    <section class="our_mission">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mission_value pull-right">
                                    <?php echo $menu1->description; ?>

                                </div>
                            </div>
                        </div>
                    </section>


                </div>
            </article>
        </div>
    </div>
</div> 
<?php echo $__env->make('front.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
