
<?php $__env->startSection('style'); ?>
<style>
    .sub-page .page-header {
        padding: 150px 100px;
        color: #FFFFFF;
        position: relative;
        z-index: 1;
        margin-bottom: 0;
        border-bottom: none;
        text-align: center;
        text-transform: uppercase;
    }
    .sub-page .page-header a {
    color: #FFFFFF;
    text-decoration: underline;
    }
    #header{
            height: auto;
            background-size: 100% 100%!important;
            position: relative;
        }
    .our_mission{
        margin-top: 65px;
        margin-bottom: 20px;
    }
</style>

<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>
        <!-- MAIN HEADER -->
        <div class="sub-page">
            <div class="page-header">
                <div class="container">
                    <h1><?php echo e($page_title); ?></h1>
                    <span><a href="<?php echo e(route('home')); ?>">Home</a> / <span><?php echo e($page_title); ?></span></span>
                </div>
            </div>
    </div>
    </header>


    <section class="our_mission">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mission_value pull-right">
                    <?php echo $page->$tt; ?>

                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>