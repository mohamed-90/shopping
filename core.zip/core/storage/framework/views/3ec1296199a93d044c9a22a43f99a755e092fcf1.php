<?php $__env->startSection('style'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/cus.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default panel-shadow" data-collapsed="0"><!-- to apply shadow add class "panel-shadow" -->

                <!-- panel body -->
                <div class="panel-body">

                    <?php $__currentLoopData = $plan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-sm-4 text-center">
                        <div class="panel panel-success panel-pricing">
                            <div class="panel-heading">
                                <h3 style="font-size: 28px;"><b><?php echo e($p->name); ?></b></h3>
                            </div>
                            <div style="font-size: 18px;padding: 18px;" class="panel-body text-center">
                                <p><strong><?php echo e($p->minimum); ?> <?php echo e($basic->currency); ?> - <?php echo e($p->maximum); ?> <?php echo e($basic->currency); ?></strong></p>
                            </div>
                            <ul style='font-size: 15px;' class="list-group text-center bold">
                                <li class="list-group-item"><i class="fa fa-check"></i> Commission - <?php echo e($p->percent); ?> <i class="fa fa-percent"></i> </li>
                                <li class="list-group-item"><i class="fa fa-check"></i> Time - <?php echo e($p->time); ?> times </li>
                                <li class="list-group-item"><i class="fa fa-check"></i> Compound - <span class="aaaa"><?php echo e($p->compound->name); ?></span></li>
                                <li class="list-group-item"><span class="aaaa"><?php echo e($p->status == 1 ? "Active" : 'DeActive'); ?></span></li>
                            </ul>
                            <div class="panel-footer" style="overflow: hidden">
                                <div class="col-sm-6">
                                    <a class="btn btn-block btn-success" href="<?php echo e(route('plan-edit',$p->id)); ?>"><i class="fa fa-edit"></i> Edit</a>
                                </div>
                                <div class="col-sm-6">
                                    <button type="button" class="btn btn-danger btn-block delete_button"
                                            data-toggle="modal" data-target="#DelModal"
                                            data-id="<?php echo e($p->id); ?>">
                                        <i class="fa fa-trash"></i> Delete
                                    </button>
                                </div>

                            </div>
                        </div>
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>

            </div>
        </div>
    </div><!---ROW-->
    <div class="modal fade" id="DelModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel"> <i class='fa fa-exclamation-triangle'></i> Confirmation..!</h4>
                </div>

                <div class="modal-body">
                    <strong>Are you sure you want to Delete this.?</strong>
                </div>

                <div class="modal-footer">
                    <form method="post" action="<?php echo e(route('delete-plan')); ?>" class="form-inline">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="id" class="abir_id" value="0">

                        <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        <button type="submit" class="btn btn-danger"><i class="fa fa-check"></i> Yes I'm Sure..!</button>
                    </form>
                </div>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script>
        $(document).ready(function () {

            $(document).on("click", '.delete_button', function (e) {
                var id = $(this).data('id');
                $(".abir_id").val(id);

            });

        });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>