<?php $__env->startSection('style'); ?>

    <script type="text/javascript" src="<?php echo e(asset('assets/dashboard/js/nicEdit.js')); ?>">

    </script>
    <script type="text/javascript">
        //<![CDATA[
        bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
        //]]>
    </script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default panel-shadow" data-collapsed="0"><!-- to apply shadow add class "panel-shadow" -->

                <!-- panel head -->
                <div class="panel-heading">
                    <div class="panel-title"><i class="fa fa-money"></i> <strong><?php echo e($page_title); ?></strong></div>

                </div>

                <!-- panel body -->
                <div class="panel-body">
                    <div class="row">
                        <?php $__currentLoopData = $gateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3">
                            <div class="panel panel-info" data-collapsed="0">
                                <!-- panel head -->
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <?php if($gateway->id == 1): ?>
                                        <i class="fa fa-paypal"></i>
                                        <?php elseif($gateway->id == 2): ?>
                                           <i class="fa fa-money"></i>>
                                        <?php elseif($gateway->id == 3): ?>
                                          <i class="fa fa-btc"></i> 
                                        <?php elseif($gateway->id == 4): ?>
                                           <i class="fa fa-cc-stripe"></i> 
                                        <?php elseif($gateway->id == 5): ?>
                                           <i class="fa fa-compass"></i>
                                        <?php elseif($gateway->id == 6): ?>
                                           <i class="fa fa-money"></i>
                                        <?php elseif($gateway->id == 8): ?>
                                           <i class="fa fa-bars"></i>  
                                        <?php else: ?>
                                          <i class="fa fa-money"></i> 
                                        <?php endif; ?> 
                                    <strong><?php echo e($gateway->name); ?></strong></div>

                                </div>
                                <!-- panel body -->
                                <div class="panel-body">
                                    <img width="100%" class="image-responsive" src="<?php echo e(asset('assets/images/gateway')); ?>/<?php echo e($gateway->gateimg); ?>" alt="">
                                </div>
                                <div class="panel-footer">
                                    <a href="javascript:;" onclick="jQuery('#modal-<?php echo e($gateway->id); ?>').modal('show');" class="btn btn-info btn-block btn-icon icon-left"><i class="fa fa-money"></i> ADD FOUND</a>
                                </div>
                            </div>
                        </div>

                            <!-- Modal 1 (Basic)-->
                            <div class="modal fade" id="modal-<?php echo e($gateway->id); ?>">
                                <div class="modal-dialog">
                                    <div class="modal-content">

                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title"><i class="fa fa-money"></i> Add Found via <?php echo e($gateway->name); ?></h4>
                                        </div>
                                        <?php echo e(Form::open()); ?>

                                        <div class="modal-body">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label style="margin-top: 20px;font-size: 14px;" class="col-sm-2 col-sm-offset-2 control-label">Amount : </label>
                                                        <div class="col-sm-7">
                                                            <span style="color: green;margin-left: 10px;"><strong><?php echo e($gateway->minamo); ?> - <?php echo e($gateway->maxamo); ?> <?php echo e($basic->currency); ?>. Charge (<?php echo e($gateway->chargefx); ?> + <?php echo e($gateway->chargepc); ?>%) <?php echo e($basic->currency); ?></strong></span>
                                                            <div class="input-group" style="margin-bottom: 15px;">
                                                                <input type="text" value="" id="amount" name="amount" class="form-control amount" required />
                                                                <span class="input-group-addon">&nbsp;<strong><?php echo e($basic->currency); ?></strong></span>
                                                                <input type="hidden" name="payment_type" id="payment_type" value="<?php echo e($gateway->id); ?>">
                                                                <input type="hidden" name="rate" value="<?php echo e($gateway->rate); ?>">
                                                                <input type="hidden" name="fix" value="<?php echo e($gateway->chargefx); ?>">
                                                                <input type="hidden" name="percent" value="<?php echo e($gateway->chargepc); ?>">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="form-group">
                                                        <div id="result"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php echo e(Form::close()); ?>

                                    </div>
                                </div>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

            </div>
        </div>
    </div><!---ROW-->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script type='text/javascript'>

        jQuery(document).ready(function(){

            $('.amount').on('input', function() {

                var amount = $(this).parent().find("#amount").val();
                var payment_type = $(this).parent().find("#payment_type").val();
                var result = $(this).parent().parent().parent().parent();

                $.post(
                        '<?php echo e(route('paypal-check-amount')); ?>',
                        {
                            _token: '<?php echo e(csrf_token()); ?>',
                            amount : amount,
                            payment_type : payment_type
                        },
                        function(data) {
                            result.find("#result").html(data);
                        }
                );
                
            });
        });
    </script>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>