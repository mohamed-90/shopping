<!DOCTYPE html>
<html lang="en">

    <head>
        <!-- Basic -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!-- Mobile Metas -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1">
        <!-- Site Metas -->
        <title>Fobex Global</title>
        <meta name="keywords" content="">
        <meta name="description" content="">
        <meta name="author" content="">
        <!-- Site Icons -->
        <link rel="icon" href="<?php echo e(asset('assets/frontEnd/03/cropped-fbx-global-32x32.png')); ?>" sizes="32x32" />
        <link rel="icon" href="<?php echo e(asset('assets/frontEnd/03/cropped-fbx-global-192x192.png')); ?>" sizes="192x192" />
        <link rel="apple-touch-icon-precomposed" href="<?php echo e(asset('assets/frontEnd/03/cropped-fbx-global-180x180.png')); ?>" />
<!--        <link rel="icon" href="<?php echo e(asset('assets/images/fevicon/fevicon.gif')); ?>" type="image/gif" />-->
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/frontEnd/css/bootstrap.min.css')); ?>" />
        <!-- Site CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/frontEnd/css/style.css')); ?>" />
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/frontEnd/css/responsive.css')); ?>" />
        <!-- Colors CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/frontEnd/css/colors.css')); ?>" />
        <!-- Custom CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/frontEnd/css/custom.css')); ?>" />
        <!-- Counter CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/frontEnd/css/jquery.countdown.css')); ?>" />
        <!-- Wow Animation CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/frontEnd/css/animate.css')); ?>" />
        <!-- Market value slider CSS -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontEnd/css/carouselTicker.css')); ?>" media="screen" />
        <link href="<?php echo e(asset('assets/frontEnd/animate.css/3.5.2/animate.min.css')); ?>" rel="stylesheet" media="all">

    </head>
    <body id="default_theme" class="home_page_1">
        <!-- loader -->
        <div class="bg_load">
            <img class="" src="<?php echo e(asset('assets/images/logo/fbxglobal-logo-white.png')); ?>" alt="#" />
        </div>
        <!-- end loader -->
        <!-- header -->
        <header id="default_header" class="header_style_1">
            <div class="header_top">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8 col-sm-8 col-xs-12">
                            <div class="full">
                                <ul class="pull-left header_top_menu cutomer_ser">
                                    <li><a href="#"><i class="fa fa-life-ring" aria-hidden="true"></i> Customer Support</a></li>
                                    <li><a href="#"><i class="fa fa-pie-chart"></i> Trading Fees: 0.05% Taker / -0.54% Market</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-12">
                            <div class="full">
                                <ul class="pull-right header_top_menu user_login">
                                    <?php if(!Auth::check()): ?>
                                    <li><a href="<?php echo e(route('login')); ?>"><i class="fa fa-sign-in"></i> Login</a></li>
                                    <li><a href="<?php echo e(route('register')); ?>"><i class="fa fa-lock"></i> Register</a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="full">
                        <div class="col-md-2 col-sm-3 col-xs-12">
                            <!-- logo -->
                            <div class="logo">
                                <a href="/"><img class="img-responsive" src="<?php echo e(asset('assets/images/logo/fbxglobal-logo-white.png')); ?>" alt="logo" /></a>
                            </div>
                            <!-- end logo -->
                        </div>
                        <div class="col-md-7 col-sm-9 col-xs-12">
                            <!-- menu -->
                            <div class="main_menu">
                                <div id="cssmenu" class="dark_menu">
                                  
                                    <ul >
                                        <li >
                                            <a href="<?php echo e(route('home')); ?>" >Home</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('about-us')); ?>">About us</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('news')); ?>">News </a>
                                        </li>

                                        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e(url('menu/')); ?>/<?php echo e($m->id); ?>/<?php echo e(urlencode(strtolower($m->name))); ?>"> <?php echo e($m->name); ?>

                                            </a>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <li>
                                            <a href="<?php echo e(route('contact')); ?>">Contact</a>
                                        </li>
                                        <?php if(Auth::check()): ?>
                                        <li>
                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Hi. <?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?>

                                                <span class="caret"></span>
                                            </a>
                                            <ul class="dropdown-menu">
                                                <?php if(Auth::check()): ?>
                                                <li> <a href="<?php echo e(route('user-dashboard')); ?>"> <i class="fa fa-dashboard"></i> Dashboard</a></li>
                                                <li>
                                                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                                document.getElementById('logout-form').submit();" class=""><i class="fa fa-sign-out right"></i>Log Out</a>
                                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                                        <?php echo e(csrf_field()); ?>

                                                    </form>
                                                </li>
                                                <?php endif; ?>
                                            </ul>
                                        </li>
                                        <?php endif; ?> 
                                    </ul>  

                                </div>
                            </div>
                            <!-- end menu -->
                        </div>
                        <div class="col-md-3 hidden-sm col-xs-12">
                            <!-- right header section -->
                            <ul class="social-links">
                                <li><a href="<?php echo e($general->facebook); ?>"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="<?php echo e($general->twitter); ?>"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="<?php echo e($general->google_plus); ?>"><i class="fa fa-google-plus"></i></a></li>
                                <li><a href="<?php echo e($general->youtube); ?>"><i class="fa fa-youtube"></i></a></li>
                                <li><a href="<?php echo e($general->linkedin); ?>"><i class="fa fa-linkedin"></i></a></li>
                            </ul>

                            <!-- end right header section -->
                        </div>
                    </div>
                </div>
            </div>
        </header>