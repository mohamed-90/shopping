<h3>Subject : <?php echo e($subject); ?></h3>
<h4>Name : <?php echo e($name); ?></h4>
<h4>Phone : <?php echo e($phone); ?></h4>
<p><?php echo $description; ?> </p>