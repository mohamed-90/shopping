<?php $__env->startSection('style'); ?>
    <style>
        span.label{
            font-size: 12px; !important;
        }
        td,th{
            font-size: 14px;
        }
    </style>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/cus.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <script type="text/javascript">
        jQuery( document ).ready( function( $ ) {
            var $table4 = jQuery( "#table-4" );

            $table4.DataTable( {
                dom: 'Bfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            } );
        } );
    </script>

    <table class="table table-striped table-hover table-bordered datatable" id="table-4">
        <thead>
        <tr>
            <th>Sl No</th>
            <th>Date</th>
            <th>Transaction ID</th>
            <th>Method Name</th>
            <th>Total</th>
            <th>Charge</th>
            <th>Amount</th>
            <th>Success Date</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php  $i = 0; ?>
        <?php $__currentLoopData = $fund; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php  $i++; ?>

            <tr>
                <td><?php echo e($i); ?></td>
                <td width="13%"><?php echo e(\Carbon\Carbon::parse($p->created_at)->format('d-F-y h:i:s A')); ?></td>
                <td><?php echo e($p->log->transaction_id); ?></td>
                <td width="12%"><?php echo e($p->log->method->name); ?></td>
                <td width="15%"><?php echo e($basic->symbol); ?> <?php echo e($p->log->total); ?></td>
                <td><?php echo e($basic->symbol); ?> <?php echo e($p->log->charge); ?></td>
                <td><?php echo e($basic->symbol); ?> <?php echo e($p->log->amount); ?></td>
                <td width="10%">
                    <?php if($p->made_time == null): ?>
                        <span class="label label-success"><i class="fa fa-times"></i> Not Seen Yet.</span>
                    <?php else: ?>
                        <?php echo e(\Carbon\Carbon::parse($p->made_time)->format('d-F-y h:i:s A')); ?>

                    <?php endif; ?>
                </td>

                <td>
                    <?php if($p->status == 0): ?>
                        <span class="label label-secondary"><i class="fa fa-spinner"></i> Pending</span>
                    <?php elseif($p->status == 1): ?>
                        <span class="label label-success"><i class="fa fa-check" aria-hidden="true"></i> Completed</span>
                    <?php else: ?>
                        <span class="label label-danger"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Refunded</span>
                    <?php endif; ?>

                </td>
                <td>
                    <a target="_blank" href="<?php echo e(route('manual-payment-view',$p->id)); ?>" class="btn btn-info btn-sm btn-icon icon-left"><i class="fa fa-eye"></i>View</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script>
        $(document).ready(function(){

            $(document).on('click', '#getUser', function(e){

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                    }
                })
                e.preventDefault();

                var uid = $(this).data('id'); // get id of clicked row

                $('#dynamic-content').html(''); // leave this div blank
                $('#modal-loader').show();      // load ajax loader on button click

                $.ajax({
                    url: '<?php echo e(url('/user/manual-fund-details')); ?>',
                    type: 'POST',
                    data: 'id='+uid,
                    dataType: 'html'
                })
                        .done(function(data){
                            console.log(data);
                            $('#dynamic-content').html(''); // blank before load.
                            $('#dynamic-content').html(data); // load here
                            $('#modal-loader').hide(); // hide loader
                        })
                        .fail(function(){
                            $('#dynamic-content').html('<i class="glyphicon glyphicon-info-sign"></i> Something went wrong, Please try again...');
                            $('#modal-loader').hide();
                        });

            });
        });
    </script>

    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/datatables.css')); ?>">
    <script src="<?php echo e(asset('assets/dashboard/js/datatables.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>