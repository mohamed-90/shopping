<?php echo $__env->make('front.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

<section id="inner_page_infor" class="innerpage_banner">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="full">
                    <div class="inner_page_info">
                        <h3>Password Reset</h3>
                        <ul>
                            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li><i class="fa fa-angle-right"></i></li>
                            <li><a href="">Password Reset</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> 

<div class="container">
    <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-12 col-lg-offset-3 col-md-offset-3 col-xs-12">
            <?php if(session()->has('message')): ?>
            <div style="margin-top: 20px;margin-bottom: -10px;" class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo e(session()->get('message')); ?>

            </div>
            <?php endif; ?>
            <?php if(session()->has('status')): ?>
            <div style="margin-top: 20px;margin-bottom: -10px;" class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo e(session()->get('status')); ?>

            </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>

            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div style="margin-top: 20px;margin-bottom: -20px;" class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo $error; ?>

            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

        </div>
    </div>
</div>
<!-- ========================== /Inner Banner =================== -->
<section id="forgot">
    <div class="container">
        <div class="section-inner">
            <center > 
                <div class="sign-main ">
                    <div class="title">
                        <h3><span class="fa fa-question-circle"></span> Password Reset</h3>
                    </div>
                    <br>
                    <form action="<?php echo e(route('password.email')); ?>" method="post" accept-charset="utf-8" class="block">
                        <?php echo csrf_field(); ?>    
                        <div class="main-form">

                            <div class="input-group col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control" placeholder="Your Email Address">
                            </div>
                            <br>
                             <script src="https://www.google.com/recaptcha/api.js" async defer></script>
                            <div class="input-group col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                <div class="g-recaptcha" data-sitekey="<?php echo e(env('CAPTCHA_KEY')); ?>">
                                     <?php if($errors->has('g-recaptcha-response')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('g-recaptcha-response')); ?></strong>
                                </span>
                                <?php endif; ?>
                                </div>
                            </div>
                            <br>
                            <input type="submit" value="Reset Password" class="btn main_btn">
                        </div>
                    </form>
                    <span class="forgot bottom"><i class="fa fa-question-circle"></i> Need an Account? <a href="<?php echo e(route('register')); ?>">Sign Up</a></span>
                </div>
            </center > 
        </div>
    </div>
</section>

<?php echo $__env->make('front.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
