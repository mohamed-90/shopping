<?php $__env->startSection('style'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/cus.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default panel-shadow" data-collapsed="0"><!-- to apply shadow add class "panel-shadow" -->

                <!-- panel head -->
                <div class="panel-heading">
                    <div class="panel-title"><i class="fa fa-send"></i> <strong><?php echo e($page_title); ?></strong></div>
                </div>

                <!-- panel body -->
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-4" >
                            <div class="col-sm-12 text-center" >
<!--                                 <div class="col-sm-4 text-center">-->
                                     
                                <div class="panel panel-info panel-pricing" style="color: #fff" >

                                    <div class="panel-heading" style="border-color: #e9d16f;height: 80px; background: #041E37; color: #fff">
                                        <h3 style="font-size: 25px; color: #fff"><b>
                                               <?php if($fund->payment_type == 1): ?>
                                                    Paypal
                                                <?php elseif($fund->payment_type == 2): ?>
                                                    Perfect Money
                                                <?php elseif($fund->payment_type == 3): ?>
                                                    BTC - ( BlockChain )
                                                <?php elseif($fund->payment_type == 9): ?>
                                                    BTC - ( Block IO )
                                                <?php else: ?>
                                                    Credit Card
                                                <?php endif; ?>
                                            </b></h3>
                                    </div>
                                    <div style="font-size: 18px;padding: 18px;border-color: #e9d16f;" class="panel-body text-center">
                                         <?php if($fund->payment_type == 1): ?>
                                            <?php  $img = $payment->paypal_image  ?>
                                        <?php elseif($fund->payment_type == 2): ?>
                                            <?php  $img = $payment->perfect_image  ?>
                                        <?php elseif($fund->payment_type == 3): ?>
                                            <?php  $img = $payment->btc_image  ?>
                                        <?php elseif($fund->payment_type == 9): ?>
                                            <?php  $img = $payment->block_image  ?>
                                        <?php else: ?>
                                            <?php  $img = $payment->stripe_image  ?>
                                        <?php endif; ?>
                                        <img width="100%" class="image-responsive" src="<?php echo e(asset('assets/images')); ?>/<?php echo e($img); ?>" alt="">
                                    
                                    </div>
                                    <div class="panel-footer" style="overflow: hidden; background: #041E37; color: #fff">
                                        <div class="col-sm-12">
                                            <br>
                                              <a href="" class="btn btn-block" style=" font-size: 14px ; background: #E9D16F; color:#fff ; width: 100%"> Back to Payment Method Page</a>

                                             </div>
                                    </div>
                                </div>
<!--                            </div>  -->

<!--                                <div class="panel panel-info" >
                                    <div class="panel-heading">
                                        <h3 style="font-size: 28px;"><b>
                                                <?php if($fund->payment_type == 1): ?>
                                                    Paypal
                                                <?php elseif($fund->payment_type == 2): ?>
                                                    Perfect Money
                                                <?php elseif($fund->payment_type == 3): ?>
                                                    BTC - ( BlockChain )
                                                <?php elseif($fund->payment_type == 9): ?>
                                                    BTC - ( Block IO )
                                                <?php else: ?>
                                                    Credit Card
                                                <?php endif; ?>
                                            </b></h3>
                                    </div>
                                    <div style="font-size: 18px;padding: 18px;" class="panel-body text-center">
                                        <?php if($fund->payment_type == 1): ?>
                                            <?php  $img = $payment->paypal_image  ?>
                                        <?php elseif($fund->payment_type == 2): ?>
                                            <?php  $img = $payment->perfect_image  ?>
                                        <?php elseif($fund->payment_type == 3): ?>
                                            <?php  $img = $payment->btc_image  ?>
                                        <?php elseif($fund->payment_type == 9): ?>
                                            <?php  $img = $payment->block_image  ?>
                                        <?php else: ?>
                                            <?php  $img = $payment->stripe_image  ?>
                                        <?php endif; ?>
                                        <img width="100%" class="image-responsive" src="<?php echo e(asset('assets/images')); ?>/<?php echo e($img); ?>" alt="">
                                    </div>
                                    <hr>
                                    <div class="panel-footer">
                                        <a href="" class="btn btn-info btn-block" style=" font-size: 14px ; background: #E9D16F; color:#fff ; width: 100%"> Back to Payment Method Page</a>
                                    </div>
                                </div>-->
                            </div>
                        </div>

                    <?php if($fund->payment_type == 9): ?>
                    <div class="col-md-8" >
                    <div class="panel panel-info panel-shadow" data-collapsed="0" ><!-- to apply shadow add class "panel-shadow" -->

                        <!-- panel head -->
                        <div class="panel-heading" style="overflow: hidden; background: #041E37; color: #fff;border-color: #041E37">
                            <div class="panel-title"><i class="fa fa-money"></i> <strong><?php echo e($page_title); ?></strong></div>
                        </div>
                        <!-- panel body -->
                        <div class="panel-body text-center">
                                <h3> PLEASE SEND <span style="color: green">BTC</span> </h3>
                                <h3>TO <span style="color: green"> <?php echo e($sendadd); ?></span></h3>
                                <br>
                                <?php echo $qrcode; ?>

                                <h2 style="font-weight:bold;">SCAN TO SEND</h2>
    
                                <br><br>
                                <h4 style="color: red;"> ** Minimum 3 confirmations  Required to Credit your account.</h4>
                                <br/>

                        </div>
                    </div>
                </div>
                    <?php else: ?>
                    <div class="col-md-8" >
                    <div class="panel panel-info panel-shadow" data-collapsed="0"><!-- to apply shadow add class "panel-shadow" -->

                        <!-- panel head -->
                        <div class="panel-heading" style="overflow: hidden; background: #041E37; color: #fff;border-color: #041E37;">
                            <div class="panel-title"><i class="fa fa-money"></i> <strong><?php echo e($page_title); ?></strong></div>
                        </div>
                        <!-- panel body -->
                        <div class="panel-body">
                            <div class="text-center">
                                <h3>Current Balance : <strong><?php echo e(Auth::user()->amount); ?> - <?php echo e($basic->currency); ?></strong></h3>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="form-group">
                                    <label style="margin-top: 5px;font-size: 14px;" class="col-sm-3 col-sm-offset-2 text-right control-label">Amount : </label>

                                    <div class="col-sm-3">
                                        <div class="input-group">
                                            <input type="text" value="<?php echo e($fund->amount); ?>" readonly name="amount" id="amount" class="form-control" placeholder="Enter Deposit Amount" required>
                                            <span class="input-group-addon red">&nbsp;<strong> <?php echo e($basic->currency); ?> </strong></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group">
                                    <label style="margin-top: 5px;font-size: 14px;" class="col-sm-3 col-sm-offset-2 text-right control-label">Rate : </label>

                                    <div class="col-sm-3">
                                        <div class="input-group">
                                            <input type="text" value="<?php echo e($fund->rate); ?>" readonly name="rate" id="amount" class="form-control" placeholder="Enter Deposit Amount" required>
                                            <span class="input-group-addon red">&nbsp;<strong> <?php echo e($basic->currency); ?> </strong></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group">
                                    <label style="margin-top: 5px;font-size: 14px;" class="col-sm-3 col-sm-offset-2 text-right control-label">Sub Total USD : </label>
                                    <div class="col-sm-3">
                                        <div class="input-group">
                                            <input type="text" value="<?php echo e(round($fund->amount / $fund->rate , 3)); ?>" readonly name="rate" id="amount" class="form-control" placeholder="Enter Deposit Amount" required>
                                            <span class="input-group-addon red">&nbsp;<strong> USD </strong></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="form-group">
                                    <label style="margin-top: 5px;font-size: 14px;" class="col-sm-3 col-sm-offset-2 text-right control-label">Charge : </label>
                                    <div class="col-sm-3">

                                        <?php if($fund->payment_type == 1): ?>
                                            <?php  $charge = $payment->paypal_fix + (($fund->amount * $payment->paypal_percent) / 100)  ?>
                                        <?php elseif($fund->payment_type == 2): ?>
                                            <?php  $charge = $payment->perfect_fix + ($fund->amount * $payment->perfect_percent / 100)  ?>
                                        <?php elseif($fund->payment_type == 3): ?>
                                            <?php  $charge = $payment->btc_fix + ($fund->amount * $payment->btc_percent / 100)  ?>
                                        <?php else: ?>
                                            <?php  $charge = $payment->stripe_fix + ($fund->amount * $payment->stripe_percent / 100)  ?>
                                        <?php endif; ?>

                                        <div class="input-group">
                                            <input type="text" value="<?php echo e($charge); ?>" readonly name="rate" id="amount" class="form-control" placeholder="Enter Deposit Amount" required>
                                            <span class="input-group-addon red">&nbsp;<strong> <?php echo e($basic->currency); ?> </strong></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group">
                                    <label style="margin-top: 5px;font-size: 14px;" class="col-sm-3 col-sm-offset-2 text-right control-label">Total USD : </label>
                                    <div class="col-sm-3">

                                        <?php if($fund->payment_type == 1): ?>
                                            <?php  $total = ($charge + $fund->amount) / $payment->paypal_rate  ?>
                                        <?php elseif($fund->payment_type == 2): ?>
                                            <?php  $total = ($charge + $fund->amount) / $payment->perfect_rate  ?>
                                        <?php elseif($fund->payment_type == 3): ?>
                                            <?php  $total = ($charge + $fund->amount) / $payment->btc_rate  ?>
                                        <?php else: ?>
                                            <?php  $total = ($charge + $fund->amount) / $payment->stripe_rate  ?>
                                        <?php endif; ?>

                                        <div class="input-group">
                                            <input type="text" value="<?php echo e(round(($total),3)); ?>" readonly name="rate" id="amount" class="form-control" placeholder="Enter Deposit Amount" required>
                                            <span class="input-group-addon red">&nbsp;<strong> USD </strong></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <?php if($fund->payment_type == 1): ?>
                            <div class="row">
                                <form action="https://secure.paypal.com/uk/cgi-bin/webscr" method="post" name="paypal" id="paypal">
                                    <input type="hidden" name="cmd" value="_xclick" />
                                    <input type="hidden" name="business" value="<?php echo e($payment->paypal_email); ?>" />
                                    <input type="hidden" name="cbt" value="<?php echo e($site_title); ?>" />
                                    <input type="hidden" name="currency_code" value="USD" />
                                    <input type="hidden" name="quantity" value="1" />
                                    <input type="hidden" name="item_name" value="Add Fund to <?php echo e($site_title); ?>" />

                                    <!-- Custom value you want to send and process back in the IPN -->
                                    <input type="hidden" name="custom" value="<?php echo e($fund->transaction_id); ?>" />

                                    <input name="amount" type="hidden" value="<?php echo e($total); ?>">
                                    <input type="hidden" name="return" value="<?php echo e(route('add-fund')); ?>"/>
                                    <input type="hidden" name="cancel_return" value="<?php echo e(route('add-fund')); ?>" />
                                    <!-- Where to send the PayPal IPN to. -->
                                    <input type="hidden" name="notify_url" value="<?php echo e(route('paypal-ipn')); ?>" />

                                    <div class="form-group">
                                        <div class="col-sm-6 col-sm-offset-3">
                                            <button class="btn btn-danger btn-block btn-icon icon-left"><i
                                                        class="fa fa-send"></i>Add Fund Now</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <?php elseif($fund->payment_type == 2): ?>
                                <div class="row">
                                    <form action="https://perfectmoney.is/api/step1.asp" method="POST" id="myform">
                                        <input type="hidden" name="PAYEE_ACCOUNT" value="<?php echo e($payment->perfect_account); ?>">
                                        <input type="hidden" name="PAYEE_NAME" value="<?php echo e($site_title); ?>">
                                        <input type='hidden' name='PAYMENT_ID' value='<?php echo e($fund->transaction_id); ?>'>
                                        <input type="hidden" name="PAYMENT_AMOUNT"  value="<?php echo e(round(($total),2)); ?>">
                                        <input type="hidden" name="PAYMENT_UNITS" value="USD">
                                        <input type="hidden" name="STATUS_URL" value="<?php echo e(route('perfect-ipn')); ?>">
                                        <input type="hidden" name="PAYMENT_URL" value="<?php echo e(route('add-fund')); ?>">
                                        <input type="hidden" name="PAYMENT_URL_METHOD" value="GET">
                                        <input type="hidden" name="NOPAYMENT_URL" value="<?php echo e(route('add-fund')); ?>">
                                        <input type="hidden" name="NOPAYMENT_URL_METHOD" value="GET">
                                        <input type="hidden" name="SUGGESTED_MEMO" value="<?php echo e($site_title); ?>">
                                        <input type="hidden" name="BAGGAGE_FIELDS" value="IDENT"><br>

                                        <div class="form-group">
                                            <div class="col-sm-6 col-sm-offset-3">
                                                <button class="btn btn-block " style=" font-size: 14px ; background: #E9D16F; color:#fff ; width: 100%">Add Fund Now</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            <?php elseif($fund->payment_type == 3): ?>

                                <div class="row">
                                    <?php echo Form::open(['route'=>'btc-preview']); ?>

                                    <input type="hidden" name="amount" value="<?php echo e(round(($total),3)); ?>">
                                    <input type="hidden" name="fund_id" value="<?php echo e($fund->id); ?>">
                                    <input type="hidden" name="transaction_id" value="<?php echo e($fund->transaction_id); ?>">
                                    <input type="hidden" name="charge" value="<?php echo e($charge); ?>">
                                    <div class="form-group">
                                        <div class="col-sm-6 col-sm-offset-3">
                                            <button class="btn btn-block" style=" font-size: 14px ; background: #E9D16F; color:#fff ; width: 100%">Add Fund Now</button>
                                        </div>
                                    </div>
                                    <?php echo e(Form::close()); ?>

                                </div>

                            <?php elseif($fund->payment_type == 4): ?>
                                <div class="row">
                                    <?php echo Form::open(['route'=>'stripe-preview']); ?>

                                    <input type="hidden" name="amount" value="<?php echo e(round(($total),2)); ?>">
                                    <input type="hidden" name="fund_id" value="<?php echo e($fund->id); ?>">
                                    <input type="hidden" name="transaction" value="<?php echo e($fund->transaction_id); ?>">
                                    <input type="hidden" name="charge" value="<?php echo e($charge); ?>">
                                        <div class="form-group">
                                            <div class="col-sm-6 col-sm-offset-3">
                                                <button class="btn btn-block" style=" font-size: 14px ; background: #E9D16F; color:#fff ; width: 100%">Add Fund Now</button>
                                            </div>
                                        </div>
                                    <?php echo e(Form::close()); ?>

                                </div>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
                    <?php endif; ?>

                        
                    </div>
                </div>

            </div>
        </div>
    </div><!---ROW-->

    <div class="modal fade" id="DelModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel"> <i class='fa fa-exclamation-triangle'></i> Confirmation..!</h4>
                </div>

                <div class="modal-body">
                    <strong>Are you sure you want to Deposit this Package.?</strong>
                </div>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script>
        $(document).ready(function () {

            $(document).on("click", '.delete_button', function (e) {
                var id = $(this).data('id');
                $(".abir_id").val(id);

            });

        });
    </script>
    <script type='text/javascript'>

        jQuery(document).ready(function(){

            $('#amount').on('input', function() {
                var amount = $("#amount").val();
                var plan = $("#plan").val();
                $.post(
                        '<?php echo e(url('/deposit-amount')); ?>',
                        {
                            _token: '<?php echo e(csrf_token()); ?>',
                            amount : amount,
                            plan : plan
                        },
                        function(data) {
                            $("#result").html(data);
                        }
                );
            });
        });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>