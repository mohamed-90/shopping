<?php echo $__env->make('front.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    
<section id="main-content" class="" style="width: 100%">
<!--    <script type="text/javascript" src="<?php echo e(asset('assets/frontEnd/js/widget.js')); ?>">
    </script>
    <div class="coinlore-priceticker-widget" data-mcurrency="usd" data-bcolor="#fff" data-scolor="#333" data-ccolor="#428bca" data-pcolor="#428bca">
        
    </div>-->
    
    <div id="demos" style="width: 100%">
        <div style="width: 100%; height:40px; background-color: #FFFFFF; overflow:hidden; box-sizing: border-box; border: 1px solid #56667F; border-radius: 4px; text-align: right; line-height:14px; block-size:40px; font-size: 12px; box-sizing:content-box; font-feature-settings: normal; text-size-adjust: 100%; box-shadow: inset 0 -20px 0 0 #56667F;padding:1px;padding: 0px; margin: 0px;">
            <div style="height:40px;">
                <iframe src="https://widget.coinlib.io/widget?type=horizontal_v2&theme=light&pref_coin_id=1505&invert_hover=" width="100%" height="40" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" border="0" style="border:0;margin:0;padding:0;">

                </iframe>
            </div>

        </div>
    </div>
</section>
<!-- market value slider end -->
<!-- full slider parallax section -->
<section id="full_slider" class="full_slider_inner padding_0">
    <div class="main_slider">
        <div id="bootstrap-touch-slider" class="carousel bs-slider slide  control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="5000">
            <div class="carousel-inner" role="listbox">
                <?php ($cnt = 0); ?>
                <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($cnt === 0): ?>
                <div class="item active">
                    <?php else: ?>
                    <div class="item">
                        <?php endif; ?>
                        
                        <?php if($cnt === 0): ?>
                        <img src="<?php echo e(asset('assets/frontEnd/images/slider_img1.jpg')); ?>" alt="Bootstrap Touch Slider" class="slide-image" />
                        <div class="container">
                            <div class="row">
                                <div class="slide-text slide_style_left white_fonts"  style=" text-align: center">
                                    <h1 data-animation="animated fadeInUp">
                                        <?php echo e($s->title); ?>

                                    </h1>
                                    <h3 data-animation="animated fadeInDown">
                                        <span class="color"><?php echo e($s->description); ?> </span>
                                    </h3>                                        
                                </div>
                            </div>
                        </div>

                        <?php endif; ?> 
                        <?php if($cnt === 1): ?>
                        <img src="<?php echo e(asset('assets/frontEnd/images/slider_img2.jpg')); ?>" alt="Bootstrap Touch Slider" class="slide-image" />
                        <div class="container">
                            <div class="row">
                                <!-- Slide Text Layer -->
                                <div class="slide-text slide_style_left white_fonts" style=" text-align: center">
                                    <h1 data-animation="animated fadeInUp">
                                        <?php echo e($s->title); ?>

                                    </h1>
                                    <h3 data-animation="animated fadeInDown">
                                        <span class="color"><?php echo e($s->description); ?> </span>
                                    </h3>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?> 
                        <?php if($cnt === 2): ?>
                        <img src="<?php echo e(asset('assets/frontEnd/images/slider_img3.jpg')); ?>" alt="Bootstrap Touch Slider" class="slide-image" />
                        <div class="container">
                            <div class="row">
                                <!-- Slide Text Layer -->
                                <div class="slide-text slide_style_left white_fonts"  style=" text-align: center">
                                    <h1 data-animation="animated fadeInUp">
                                        <?php echo e($s->title); ?>

                                    </h1>
                                    <h3 data-animation="animated fadeInDown">
                                        <span class="color"><?php echo e($s->description); ?> </span>
                                    </h3>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>                                              
                    </div>
                    <?php ($cnt++); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <!-- End of Wrapper For Slides -->
                <!-- Left Control -->
                <a class="left carousel-control" href="#bootstrap-touch-slider" role="button" data-slide="prev">
                    <span class="fa fa-angle-left" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <!-- Right Control -->
                <a class="right carousel-control" href="#bootstrap-touch-slider" role="button" data-slide="next">
                    <span class="fa fa-angle-right" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
            <!-- End  bootstrap-touch-slider Slider -->
        </div>
</section>
<!-- end full slider parallax section -->   
<!-- section -->
<section class="layout_padding">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="full">
                    <div class="heading_main">
                        <h2><span>What is Fobex Global corporation?</span></h2>
                        <p>FOBEX GLOBAL CORPORATION is an international company that includes many investors 
                            and businessmen in the world. It has already been developed by a team of professionals
                            in various fields such as forex trading, mining and trading digital currency, 
                            real estate. The company also seeks to be an international leader in the digital
                            and real estate field and be positioned as a tool for financial and economic 
                            development in the world.</p>
                    </div>
                </div>
            </div>
        </div>            
    </div>
</section>
<!-- end section -->
<!-- section -->
<section class="layout_padding dark_bg white_fonts">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="full">
                    <div class="heading_main">
                        <h2><span>Why Choose Fobex Global?</span></h2>
                        <p>Our team uses a sophisticated approach that was previously available only through major investment companies.
                            <br>They bring strong strategies to make big profits.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row" style="margin-top:20px;">
            <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="full">
                    <div class="cryto_feature">
                        <ul>
                            <li>
                                <div class="pull-left"><img src="<?php echo e(asset('assets/frontEnd/images/gb1.png')); ?>" alt="#" /></div>
                                <div>
                                    <h3>High-Tech Mining</h3>

                                </div>
                            </li>
                            <li>
                                <div class="pull-left"><img src="<?php echo e(asset('assets/frontEnd/images/gb3.png')); ?>" alt="#" /></div>
                                <div>
                                    <h3>Good & Long Experience</h3>

                                </div>
                            </li>
                            <li>
                                <div class="pull-left"><img src="<?php echo e(asset('assets/frontEnd/images/gb2.png')); ?>" alt="#" /></div>
                                <div>
                                    <h3>High-Tech Trading</h3>

                                </div>
                            </li>
                            
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="full digital_earth">
                    <img src="<?php echo e(asset('assets/frontEnd/images/bg3_new.png')); ?>" alt="#" />
                </div>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="full">
                    <div class="cryto_feature right_text">
                        <ul>
                            <li>

                                <div class="pull-right"><img src="<?php echo e(asset('assets/frontEnd/images/gb4.png')); ?>" alt="#" /></div>
                                <div>
                                    <h3>Internationally Legal</h3>

                                </div>
                            </li>
                            <li>

                                <div class="pull-right"><img src="<?php echo e(asset('assets/frontEnd/images/gb5.png')); ?>" alt="#" /></div>
                                <div>
                                    <h3>Secure and Stable</h3>

                                </div>
                            </li>
                            <li>

                                <div class="pull-right"><img src="<?php echo e(asset('assets/frontEnd/images/gb6.png')); ?>" alt="#" /></div>
                                <div>
                                    <h3>Lots of investments</h3>

                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end section -->
<!-- section -->
<section class="layout_padding">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="full our_work_type">
                    <div class="center"><img src="<?php echo e(asset('assets/frontEnd/images/logos/lg1.jpg')); ?>" alt="#" /></div>
                    <div class="center">
                        <h4>TRADING ROBOTS </h4>

                    </div>
                    <div class="center">
                        <p>
                            We have sophisticated ROBOTS that analyze various stock exchanges and market conditions. 
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="full our_work_type">
                    <div class="center"><img src="<?php echo e(asset('assets/frontEnd/images/logos/lg2.png')); ?>" alt="#" /></div>
                    <div class="center">
                        <h4>MINING CRYPTOCURRENCY    </h4>
                    </div>
                    <div class="center">
                        <p>
                            We have modern hardware and technology for digital currency mining.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="full our_work_type">
                    <div class="center"><img src="<?php echo e(asset('assets/frontEnd/images/logos/lg3.jpg')); ?>" alt="#" /></div>
                    <div class="center">
                        <h4>REAL ESTATE İNVESTMENTS</h4>
                    </div>
                    <div class="center">
                        <p>
                            We have more than 15 years experience in real estate investment.
                        </p>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
<!-- end section -->
<!-- section -->
<section class="layout_padding dark_bg">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="full">
                    <div class="heading_main">
                        <h2><span>How it works</span></h2>
                        <p>We have valuable business experience in various financial markets,
                            we also have extensive knowledge in real estate investments,
                            aspire to develop and improve our operations, and invest properly to 
                            increase profits and capital.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end section -->
<!-- section -->
<section class="layout_padding">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="full">
                    <div class="heading_main">
                        <h2><span>OUR TEAM</span></h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-1 col-sm-12 col-xs-12"></div>
            <div class="col-md-10 col-sm-12 col-xs-12">
                <div class="full testmonial_slider">
                    <div class="carousel slide" data-ride="carousel" id="quote-carousel">
                        <!-- Carousel Slides / Quotes -->
                        <div class="carousel-inner text-center">
                            <!-- Quote 1 -->

                            <div class="item active">
                                <blockquote>
                                    <div class="row">
                                        <div class="col-sm-10 col-sm-offset-1">
                                            <div class="center">
                                                <div class="client_img">
                                                    <img class="img-responsive" src="<?php echo e(asset('assets/images/user-default.png')); ?>" alt="#" />
                                                </div>
                                            </div>
                                            <p>
                                                <span class="left_testmonial_qout">
                                                    <i class="fa fa-quote-left">

                                                    </i>
                                                </span>
                                                He has over 20 years experience in the financial markets.
                                                He worked as a trader and broker at many global investment banks.

                                                <span class="right_testmonial_qout">
                                                    <i class="fa fa-quote-right"></i>
                                                </span>
                                            </p>
                                            <div class="center">
                                                <p class="client_name">Thomas Perry</p>
                                            </div>
                                            <div class="center">
                                                <p class="country_name">Director and Shareholder</p>
                                            </div>
                                        </div>
                                    </div>
                                </blockquote>
                            </div>

                            <div class="item">
                                <blockquote>
                                    <div class="row">
                                        <div class="col-sm-10 col-sm-offset-1">
                                            <div class="center">
                                                <div class="client_img">
                                                    <img class="img-responsive" src="<?php echo e(asset('assets/images/user-default.png')); ?>" alt="#" />
                                                </div>
                                            </div>
                                            <p>
                                                <span class="left_testmonial_qout">
                                                    <i class="fa fa-quote-left">

                                                    </i>
                                                </span>
                                                He is a technical expert for over 7 years in programming and systems development.

                                                <span class="right_testmonial_qout">
                                                    <i class="fa fa-quote-right"></i>
                                                </span>
                                            </p>
                                            <div class="center">
                                                <p class="client_name">Michael Rivera</p>
                                            </div>
                                            <div class="center">
                                                <p class="country_name">Chief technical officer</p>
                                            </div>
                                        </div>
                                    </div>
                                </blockquote>
                            </div>

                            <div class="item">
                                <blockquote>
                                    <div class="row">
                                        <div class="col-sm-10 col-sm-offset-1">
                                            <div class="center">
                                                <div class="client_img">
                                                    <img class="img-responsive" src="<?php echo e(asset('assets/images/user-default.png')); ?>" alt="#" />
                                                </div>
                                            </div>
                                            <p>
                                                <span class="left_testmonial_qout">
                                                    <i class="fa fa-quote-left">

                                                    </i>
                                                </span>
                                                He is a specializing in construction and decoration, and a successful real estate investor.
                                                <span class="right_testmonial_qout">
                                                    <i class="fa fa-quote-right"></i>
                                                </span>
                                            </p>
                                            <div class="center">
                                                <p class="client_name">James Smith</p>
                                            </div>
                                            <div class="center">
                                                <p class="country_name">Chief Financial Officer & Co-Founder</p>
                                            </div>
                                        </div>
                                    </div>
                                </blockquote>
                            </div>

                        </div>

                        <a data-slide="prev" href="#quote-carousel" class="left carousel-control"><i class="fa fa-chevron-left"></i></a>
                        <a data-slide="next" href="#quote-carousel" class="right carousel-control"><i class="fa fa-chevron-right"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-sm-12 col-xs-12"></div>
        </div>
    </div>
</section>
<!-- end section -->

<?php echo $__env->make('front.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>