<?php $__env->startSection('style'); ?>
<style>
    .sub-page .page-header {
        padding: 150px 100px;
        color: #FFFFFF;
        position: relative;
        z-index: 1;
        margin-bottom: 0;
        border-bottom: none;
        text-align: center;
        text-transform: uppercase;
    }
    .sub-page .page-header a {
    color: #FFFFFF;
    text-decoration: underline;
    }
    #header{
            height: auto;
            background-size: 100% 100%!important;
            position: relative;
        }
    .upercasea-font{
        text-transform: uppercase;
    }
</style>

<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>
        <!-- MAIN HEADER -->
        <div class="sub-page">
            <div class="page-header">
                <div class="container">
                    <h1 class="upercasea-font">CONTACT WITH US</h1>
                    <span><a href="<?php echo e(route('home')); ?>">Home</a> / <span>contact</span></span>
                </div>
            </div>
    </div>
    </header>

    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <?php if(session()->has('message')): ?>
            <div style="margin-bottom: 20px;margin-top: 20px;" class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo e(session()->get('message')); ?>

            </div>
            <?php endif; ?>
        </div>
    </div>



    <!--=-=-=-=-=-=-=-=-=-=-=-=
         CONTACT US   
-=-=-=-=-=-=-=-=-==-=-=-=-=-->
    <section id="contact">
        <div class="container">
            <div class="contact-inner">
                <div class="row">
                    <div class="col-md-6">
                        <div class="contact-form">
                            <div class="title">
                                <h3>Put a Note:</h3>
                            </div>
                            <?php echo e(Form::open()); ?>

                                <div class="form-group">
                                    <input type="text" name="name" placeholder="Name *" required class="form-control" aria-describedby="basic-addon2">
                                    <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                </div>
                                <div class="form-group">
                                    <input type="email" name="email" placeholder="Email *" required class="form-control" aria-describedby="basic-addon3">
                                    <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                                </div>
                                 <div class="form-group">
                                    <input type="text" name="subject" placeholder="Subject *" required class="form-control" aria-describedby="basic-addon3">
                                    <span class="input-group-addon"><i class="fa fa-info"></i></span>
                                </div>
                                
                                <div class="form-group">
                                   

                                    <textarea name="message" class="form-control" placeholder="Message *" required rows="5" ></textarea>
                                    <span class="input-group-addon"><i class="fa fa-paper-plane"></i></span>
                                </div>
                                <input type="submit" value="send message" class="btn btn-default">
                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="contact-info">
                            <div class="title">
                                <h3>Address:</h3>
                            </div>
                            <div class="info-main">
                                <p style="text-align:justify;"><?php echo $general->about_text_contact; ?></p>
                                <span class="location"><i class="fa fa-map-marker"></i> <?php echo e($general->address); ?></span>
                                <span class="phone"><i class="fa fa-phone"></i> <?php echo e($general->number); ?></span>
                                <span class="email"><i class="fa fa-envelope"></i>
                                <?php echo e($general->email); ?></span>
                            </div>
                            <div class="social-icon">
                                <ul class="no-style">
                                    <li><a href="<?php echo e($general->facebook); ?>"><span class="fa fa-facebook"></span></a></li>
                                    <li><a href="<?php echo e($general->twitter); ?>"><span class="fa fa-twitter"></span></a></li>
                                    <li><a href="<?php echo e($general->google_plus); ?>"><span class="fa fa-google-plus"></span></a></li>
                                    <li><a href="<?php echo e($general->linkedin); ?>"><span class="fa fa-linkedin"></span></a></li>
                                    <li><a href="<?php echo e($general->youtube); ?>"><span class="fa fa-youtube"></span></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="map">
            <div class="container-fluid">
                <div class="map-main">
                    <iframe src="<?php echo e($general->google_map_link); ?>" allowfullscreen>
                    </iframe>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.front-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>