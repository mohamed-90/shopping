<?php $__env->startSection('style'); ?>
<style>
    .sub-page .page-header {
        padding: 150px 100px;
        color: #FFFFFF;
        position: relative;
        z-index: 1;
        margin-bottom: 0;
        border-bottom: none;
    }
    .sub-page .page-header a {
    color: #FFFFFF;
    text-decoration: underline;
    }
    #header{
            height: auto;
            background-size: 100% 100%!important;
            position: relative;
            margin-bottom:50px;
        }
    .our_mission{
        margin-top: 65px;
        margin-bottom: 20px;
    }
    .capitalize_name{
        text-transform:capitalize;
    }
    .empty-news{
        text-align: center;
        font-weight: 600;
        color: #1E223F;
        padding: 100px 0px;
        font-size: 25px;
        border: 1px solid #f3f3f3;
        background-color: #F6F6F6;
    }
</style>

<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>
        <!-- MAIN HEADER -->
        <div class="sub-page">
            <div class="page-header">
                <div class="container">
                    <h1><?php echo e($page_title); ?></h1>
                    <span><a href="<?php echo e(route('home')); ?>">Home</a> / <span class="capitalize_name"><?php echo e($category_name); ?></span></span>
                </div>
            </div>
    </div>
    </header>

      <!--=-=-=-=-=-=-=-=-=-=-=
          BLOG   
-=-=-=-=-=-=-=-=-==-=-=-=-->
<section id="blog">
        <div class="container">
            <div class="blog-inner">
                <div class="title common text-center">
                    <h2><?php echo e($category_name); ?></h2>
                </div>
                <div class="main">
                
                <?php if(count($news)==0): ?>
                    <h5 class="empty-news">News Not Available</h5>
                <?php else: ?>

                    <?php  $b = 0  ?>
                      <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php if($b++ % 2 == 0 ): ?>
                            <div class="item left">
                            <div class="row">
                                <div class="col-md-5">
                                    <img src="<?php echo e(asset('assets/images')); ?>/<?php echo e($n->image); ?>" class="img-responsive" alt="news-img">
                                </div>
                                <div class="col-md-7">
                                    <div class="item-title">
                                        <h2><?php echo e($n->title); ?></h2>
                                        <div class="item-info">
                                            <i class="fa fa-bars"></i> Posted On <?php echo e($n->category->name); ?>

                                            <i class="fa fa-calendar"></i> <?php echo e(\Carbon\Carbon::parse($n->created_at)->format('d F Y')); ?> 
                                        </div>
                                    </div>
                                    <div class="item-text">
                                        <p> <?php echo substr(strip_tags($n->description),0,280); ?><?php echo e(strlen(strip_tags($n->description)) > 280 ? "..." : ""); ?></p>
                                    </div>
                                     <a href="<?php echo e(route('news-details',['id'=>$n->id,'slug'=>str_slug($n->title)])); ?>" target="_blank" class="btn btn-info">read more <span class="fa fa-angle-double-right"></span></a>
                                </div>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="item right">
                        <div class="row">
                            <div class="col-md-5 col-md-push-7 col-lg-push-7">
                                <img src="<?php echo e(asset('assets/images')); ?>/<?php echo e($n->image); ?>" class="img-responsive" alt="">
                            </div>
                            <div class="col-md-7 col-md-pull-5 col-lg-pull-5">
                                <div class="item-title">
                                    <h2><?php echo e($n->title); ?></h2>
                                    <div class="item-info">
                                         <i class="fa fa-bars"></i> Posted On <?php echo e($n->category->name); ?>

                                         <i class="fa fa-calendar"></i> <?php echo e(\Carbon\Carbon::parse($n->created_at)->format('d F Y')); ?> 
                                    </div>
                                </div>
                                <div class="item-text">
                                    <p> <?php echo substr(strip_tags($n->description),0,280); ?><?php echo e(strlen(strip_tags($n->description)) > 280 ? "..." : ""); ?></p>
                                </div>
                                <a href="<?php echo e(route('news-details',['id'=>$n->id,'slug'=>str_slug($n->title)])); ?>" target="_blank" class="btn btn-info">read more <span class="fa fa-angle-double-right"></span></a>
                            </div>
                        </div>
                    </div>
                        <?php endif; ?>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>