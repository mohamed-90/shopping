<?php echo $__env->make('front.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  

<section id="main-content" class="" style="width: 100%">
    <div id="demos" style="width: 100%">
        <div style="width: 100%; height:40px; background-color: #FFFFFF; overflow:hidden; box-sizing: border-box; border: 1px solid #56667F; border-radius: 4px; text-align: right; line-height:14px; block-size:40px; font-size: 12px; box-sizing:content-box; font-feature-settings: normal; text-size-adjust: 100%; box-shadow: inset 0 -20px 0 0 #56667F;padding:1px;padding: 0px; margin: 0px;">
            <div style="height:40px;">
                <iframe src="https://widget.coinlib.io/widget?type=horizontal_v2&theme=light&pref_coin_id=1505&invert_hover=" width="100%" height="40" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" border="0" style="border:0;margin:0;padding:0;">

                </iframe>
            </div>

        </div>
    </div>
</section>

<section id="inner_page_infor" class="innerpage_banner">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="full">
                    <div class="inner_page_info">
                        <h3>Login</h3>
                        <ul>
                            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li><i class="fa fa-angle-right"></i></li>
                            <li><a href="">Login</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="container">
    <div class="row">
        
        <div class="col-md-6 col-md-offset-3">
            <?php if(session()->has('message')): ?>
            <div style="margin-top: 20px;margin-bottom: -15px;" class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo e(session()->get('message')); ?>

            </div>
            <?php endif; ?>
            <?php if(session()->has('status')): ?>
            <div style="margin-top: 20px;margin-bottom: -15px;" class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo e(session()->get('status')); ?>

            </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>

            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div style="margin-top: 20px;margin-bottom: -15px;" class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo $error; ?>

            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<br>
<!--=-=-=-=-=-=-=-=-=-=-=-=
     LOG IN   
-=-=-=-=-=-=-=-=-==-=-=-=-=-->
<section id="login">
    <div class="container">
        <div class="section-inner">
            <center > 
                <div class="sign-main" >
                   
                    <div class="title">
                        <h3><span class="fa fa-lock"></span> Welcome to Fobex Global!</h3>
                    </div>

                    <form class="form_contant" action="<?php echo e(route('login')); ?>" method="post" accept-charset="utf-8">
                        <?php echo csrf_field(); ?>

                        <fieldset>
                            <div class="input-group col-lg-6 col-md-6 col-sm-6 col-xs-6">
<!--                                <span class="input-group-addon"><i class="fa fa-envelope"></i></span>-->
                                <input type="email" name="email" class="field_custom" value="<?php echo e(old('email')); ?>" placeholder="Your Email">
                            </div>
                            <div class="input-group col-lg-6 col-md-6 col-sm-6 col-xs-6">
<!--                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>-->
                                <input type="password" name="password" autocomplete="new-password" class="field_custom" placeholder="Password">
                            </div>

                            <script src="https://www.google.com/recaptcha/api.js" async defer></script>
                            <div class="input-group col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                <div class="g-recaptcha" data-sitekey="<?php echo e(env('CAPTCHA_KEY')); ?>">
                                    <?php if($errors->has('g-recaptcha-response')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('g-captcha-response')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="center">
                                <!--                                <a class="btn main_btn" href="#">SUBMIT NOW</a>-->
                                <input type="submit" value="login" class="btn main_btn">
                            </div>
                        </fieldset>
                    </form>
                    <br>
                    <span class="reset bottom"><i class="fa fa-question-circle"></i> Forgot your password? <a href="<?php echo e(route('password.request')); ?>">Reset now</a></span>
                    <span class="signup bottom"><i class="fa fa-question-circle"></i> Don't Have an Account? <a href="<?php echo e(route('register')); ?>">Sign up</a></span>
                    <br>
                </div>
            </center>
            <br>
        </div>
    </div>
</section>

<?php echo $__env->make('front.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>