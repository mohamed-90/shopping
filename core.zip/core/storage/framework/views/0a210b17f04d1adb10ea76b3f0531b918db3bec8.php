
<?php $__env->startSection('style'); ?>
    <style>
        span.label{
            font-size: 12px; !important;
        }
        td,th{
            font-size: 14px;
        }
    </style>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css//cus.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <table class="table table-striped table-hover table-bordered datatable" id="table-4">
        <thead>
        <tr>
            <th>Date</th>
            <th>Transaction ID</th>
            <th>Method Name</th>
            <th>Total</th>
            <th>Charge</th>
            <th>Amount</th>
            <th>Success Date</th>
            <th>Status</th>
        </tr>
        </thead>
        <tbody>
            <tr>
                <td width="13%"><?php echo e(\Carbon\Carbon::parse($fund->created_at)->format('d-F-y h:i:s A')); ?></td>
                <td><?php echo e($fund->log->transaction_id); ?></td>
                <td width="12%"><?php echo e($fund->log->method->name); ?></td>
                <td width="15%"><?php echo e($basic->symbol); ?> <?php echo e($fund->log->total); ?></td>
                <td><?php echo e($basic->symbol); ?> <?php echo e($fund->log->charge); ?></td>
                <td><?php echo e($basic->symbol); ?> <?php echo e($fund->log->amount); ?></td>
                <td width="10%">
                    <?php if($fund->made_time == null): ?>
                        <span class="label label-success"><i class="fa fa-times"></i> Not Seen Yet.</span>
                    <?php else: ?>
                        <?php echo e(\Carbon\Carbon::parse($fund->made_time)->format('d-F-y h:i:s A')); ?>

                    <?php endif; ?>
                </td>

                <td>
                    <?php if($fund->status == 0): ?>
                        <span class="label label-secondary"><i class="fa fa-spinner"></i> Pending</span>
                    <?php elseif($fund->status == 1): ?>
                        <span class="label label-success"><i class="fa fa-check" aria-hidden="true"></i> Completed</span>
                    <?php else: ?>
                        <span class="label label-danger"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Refunded</span>
                    <?php endif; ?>
                </td>
            </tr>
        </tbody>

    </table>

    <div class="panel panel-default panel-shadow" data-collapsed="0"><!-- to apply shadow add class "panel-shadow" -->

        <!-- panel head -->
        <div class="panel-heading">
            <div class="panel-title">Payment Prove Preview</div>

            <div class="panel-options">
                <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
                <a href="#" data-rel="close"><i class="entypo-cancel"></i></a>
            </div>
        </div>

        <!-- panel body -->
        <div class="panel-body">
            <h3>Message : </h3><br>
            <p class="lead"><?php echo e($fund->message); ?></p>
            <hr>
            <div class="row">
                <div class="col-sm-12">
                    <?php $__currentLoopData = $img; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img style="margin-bottom: 10px;" src="<?php echo e(asset('assets/upload')); ?>/<?php echo e($i->image); ?>" alt="" class="img-responsive">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-8 col-md-offset-2 col-sm-12">
                    <button type="button" class="btn btn-danger  btn-lg btn-icon btn-block icon-left delete_button"
                            data-toggle="modal" data-target="#DelModal"
                            data-id="<?php echo e($fund->id); ?>">
                        <i class="fa fa-check"></i> Confirm Payment
                    </button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="DelModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel"> <i class='fa fa-exclamation-triangle'></i> Confirmation..!</h4>
                </div>

                <div class="modal-body">
                    <strong>Are you sure you want to Confirm This Payment.?</strong>
                </div>

                <div class="modal-footer">
                    <form method="post" action="<?php echo e(route('manual-payment-confirm')); ?>" class="form-inline">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="id" class="abir_id" value="0">

                        <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        <button type="submit" class="btn btn-danger"><i class="fa fa-check"></i> Yes I'm Sure..!</button>
                    </form>
                </div>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {

            $(document).on("click", '.delete_button', function (e) {
                var id = $(this).data('id');
                $(".abir_id").val(id);

            });

        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>