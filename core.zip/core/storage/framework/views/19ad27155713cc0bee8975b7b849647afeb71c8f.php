
    <!--=-=-=-=-=-=-=-=-=-=-=-
          HEADER    
-=-=-=-=-=-=-=-=-=-=-=-=-=-->
<header id="header" class="sub-page">

<!-- ========== TOP BAR ========== -->
<div id="top-bar">
    <div class="container">
        <div class="tb-inner">
            <div class="left pull-left">
                <a class="email" href="mailto:example@host.com"><span class="fa fa-envelope"></span>example@host.com</a>
                <a class="phone" href="tel:+0123456789"><span class="fa fa-phone"></span>+012 345 6789</a>
            </div>
            <div class="right pull-right">
                <a href="#"><span class="fa fa-user"></span>Log in</a>
                <a href="#"><span class="fa fa-edit"></span>Register</a>
                <ul class="social-icon no-style">
                    <li>
                        <a href="#" class="fa fa-facebook"></a>
                    </li>
                    <li>
                        <a href="#" class="fa fa-twitter"></a>
                    </li>
                    <li>
                        <a href="#" class="fa fa-instagram"></a>
                    </li>
                    <li>
                        <a href="#" class="fa fa-google-plus"></a>
                    </li>
                    <li>
                        <a href="#" class="fa fa-pinterest"></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- ========== NAVIGATION BAR ========== -->
<nav id="navigation" class="navbar navbar-inverse navbar-custom" data-spy="affix" data-offset-top="35">
    <div class="container">

        <!-- === NAVBAR-HEADER ===  -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle hamburger" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
            <a href="#top" class="navbar-brand logo-1"><img src="<?php echo e(asset('assets/images')); ?>/<?php echo e($general->logo); ?>" alt="navbar logo"></a>
        </div>

        <!-- ===MAIN-NAVBAR=== -->
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="index.html">home</a></li>
                <li><a href="about-us.html">about us</a></li>
                <li class="dropdown top">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">hosting <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="shared-hosting.html">shared hosting</a></li>
                        <li><a href="reseller-hosting.html">reseller hosting</a></li>
                        <li><a href="vps-hosting.html">vps hosting</a></li>
                        <li><a href="dedicated-server.html">dedicated server</a></li>
                    </ul>
                </li>
                <li class="dropdown top">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">blog <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="blog-list.html">blog list</a></li>
                        <li><a href="blog-post-1.html">blog post 1</a></li>
                        <li><a href="blog-post-2.html">blog post 2</a></li>
                    </ul>
                </li>
                <li class="dropdown top">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">pages <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="pricing-table.html">pricing plans</a></li>
                        <li><a href="our-service.html">our services</a></li>
                        <li class="dropdown dropdown-in">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">our team &nbsp;<span class="caret-right"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="team-1.html">our team 1</a></li>
                                <li><a href="team-2.html">our team 2</a></li>
                            </ul>
                        </li>
                        <li class="dropdown dropdown-in">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">login/signup &nbsp;<span class="caret-right"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="login.html">login</a></li>
                                <li><a href="registration.html">register</a></li>
                                <li><a href="forgot.html">forgot password</a></li>
                                <li><a href="log-sign-up.html">login/register</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li class="dropdown top">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">contact <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="contact-1.html">contact default</a></li>
                        <li><a href="contact-2.html">contact page 1</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- MAIN HEADER -->
<div class="page-header">
    <div class="container">
        <h1>about us</h1>
        <span><a href="index.html">Home</a> / <span>about us</span></span>
    </div>
</div>
</header>