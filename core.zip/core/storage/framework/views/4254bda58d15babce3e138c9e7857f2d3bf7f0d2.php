
<?php $__env->startSection('style'); ?>
    <style>
        span.label{
            font-size: 12px; !important;
        }
        td,th{
            font-size: 14px;
        }
    </style>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/cus.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/bootstrap-popover-x.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <script type="text/javascript">
        jQuery( document ).ready( function( $ ) {
            var $table4 = jQuery( "#table-4" );

            $table4.DataTable( {
                dom: 'Bfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            } );
        } );
    </script>

    <table class="table table-striped table-hover table-bordered datatable" id="table-4">
        <thead>
        <tr>
            <th>Sl No</th>
            <th>Name</th>
            <th>Email</th>
            <th>Current Amount</th>
            <th>Block At</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php  $i = 0; ?>
        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php  $i++; ?>

            <tr>
                <td><?php echo e($i); ?></td>
                <td><?php echo e($p->name); ?></td>
                <td><?php echo e($p->email); ?></td>
                <td><?php echo e($p->amount); ?> - <?php echo e($basic->currency); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($p->block_at)->format('d F Y H:i A')); ?></td>
                <td width="30%">
                    <button data-toggle="modal" data-target="#view-modal"
                            data-id="<?php echo e($p->id); ?>"
                            id="getUser" class="btn btn-info btn-icon icon-left">
                        <i class="fa fa-eye"></i> Details
                    </button>
                    <button type="button" class="btn btn-primary btn-icon icon-left" data-toggle="popover-x" data-target="#myPopover<?php echo e($p->id); ?>" data-placement="top"><i class="fa fa-list"></i> Activity</button>

                    <div id="myPopover<?php echo e($p->id); ?>" class="popover popover-success popover-md">
                        <div class="arrow"></div>
                        <div class="popover-title"><span class="close" data-dismiss="popover-x">&times;</span><strong><i class="fa fa-indent"></i> Activity</strong></div>
                        <div class="popover-content">
                            <a href="<?php echo e(route('user-transaction',$p->id)); ?>" class="btn btn-info btn-icon icon-left"><i class="fa fa-cloud-upload"></i> Transaction</a>
                            <a href="<?php echo e(route('user-deposit',$p->id)); ?>" class="btn btn-success btn-icon icon-left"><i class="fa fa-cloud-download"></i> Deposit</a>
                            <a href="<?php echo e(route('user-withdraw',$p->id)); ?>" class="btn btn-danger btn-icon icon-left"><i class="fa fa-reply-all"></i> Withdraw</a>
                        </div>
                    </div>
                    <?php if($p->block_status == 1): ?>
                        <button type="button" class="btn btn-danger btn-icon icon-left unblock_button"
                                data-toggle="modal" data-target="#unblocklModal"
                                data-id="<?php echo e($p->id); ?>">
                            <i class="fa fa-user-plus"></i> UnBlock
                        </button>
                    <?php else: ?>
                        <button type="button" class="btn btn-danger btn-icon icon-left block_button"
                                data-toggle="modal" data-target="#blockModal"
                                data-id="<?php echo e($p->id); ?>">
                            <i class="fa fa-user-times"></i> Block
                        </button>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
    <meta name="_token" content="<?php echo csrf_token(); ?>" />

    <div class="modal fade" id="blockModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel"> <i class='fa fa-exclamation-triangle'></i> Confirmation..!</h4>
                </div>

                <div class="modal-body">

                    <strong>Are you sure you want to <strong>Block</strong> This User.?</strong>
                </div>

                <div class="modal-footer">
                    <form method="post" action="<?php echo e(route('user-block')); ?>" class="form-inline">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="id" class="abir_id" value="0">
                        <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        <button type="submit" class="btn btn-danger"><i class="fa fa-check"></i> Yes I'm Sure..!</button>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <div class="modal fade" id="unblocklModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel"> <i class='fa fa-exclamation-triangle'></i> Confirmation..!</h4>
                </div>

                <div class="modal-body">

                    <strong>Are you sure you want to <strong>UnBlock</strong> This User.?</strong>
                </div>

                <div class="modal-footer">
                    <form method="post" action="<?php echo e(route('user-unblock')); ?>" class="form-inline">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="id" class="abir_id" value="0">
                        <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        <button type="submit" class="btn btn-danger"><i class="fa fa-check"></i> Yes I'm Sure..!</button>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <div id="view-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
        <div class="modal-dialog">
            <div class="modal-content">

                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title">
                        <i class="glyphicon glyphicon-user"></i> User Details
                    </h4>
                </div>

                <div class="modal-body">
                    <div id="modal-loader" style="display: none; text-align: center;">
                        <!-- ajax loader -->
                        <img src="<?php echo e(asset('assets/images/ajax-loader.gif')); ?>">
                    </div>

                    <!-- mysql data will be load here -->
                    <div id="dynamic-content"></div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                </div>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function(){

            $(document).on('click', '#getUser', function(e){

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                    }
                })
                e.preventDefault();

                var uid = $(this).data('id'); // get id of clicked row

                $('#dynamic-content').html(''); // leave this div blank
                $('#modal-loader').show();      // load ajax loader on button click

                $.ajax({
                    url: '<?php echo e(url('/user-details')); ?>',
                    type: 'POST',
                    data: 'id='+uid,
                    dataType: 'html'
                })
                        .done(function(data){
                            console.log(data);
                            $('#dynamic-content').html(''); // blank before load.
                            $('#dynamic-content').html(data); // load here
                            $('#modal-loader').hide(); // hide loader
                        })
                        .fail(function(){
                            $('#dynamic-content').html('<i class="glyphicon glyphicon-info-sign"></i> Something went wrong, Please try again...');
                            $('#modal-loader').hide();
                        });

            });
        });
    </script>

    <script>
        $(document).ready(function () {

            $(document).on("click", '.block_button', function (e) {
                var id = $(this).data('id');
                $(".abir_id").val(id);

            });

        });
    </script>
    <script>
        $(document).ready(function () {

            $(document).on("click", '.unblock_button', function (e) {
                var id = $(this).data('id');
                $(".abir_id").val(id);
            });

        });
    </script>
    <script>
        $(document).ready(function () {

            $(document).on("click", '.ref_button', function (e) {
                var id = $(this).data('id');
                $(".abir_id").val(id);

            });

        });
    </script>

    <script src="<?php echo e(asset('assets/dashboard/js/bootstrap-popover-x.min.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/datatables.css')); ?>">

    <script src="<?php echo e(asset('assets/dashboard/js/datatables.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>