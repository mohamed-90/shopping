 <footer id="footer">
        <div class="footer-bottom">
            <div class="container">
                <div class="footer-b-inner">
                    <div class="footer-text">
                        <p>&copy;Static</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>