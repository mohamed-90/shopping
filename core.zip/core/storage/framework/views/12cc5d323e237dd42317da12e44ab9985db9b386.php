<!DOCTYPE html>
<!--[if lt IE 7]>      <html lang="en" class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html lang="en" class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html lang="en" class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="zxx">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title><?php echo e($site_title); ?> | <?php echo e($page_title); ?></title>
    <meta name="description" content="MAMA host">
    <meta name="keywords" content="tag, tag, tag, tag, tag">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">



    <link href="<?php echo e(asset('assets/images')); ?>/<?php echo e($general->favicon); ?>" rel="shortcut icon" type="image/x-icon" />
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet">
    <link href="<?php echo e(asset('assets/front/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/front/owlcarousel/assets/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/animate.css')); ?>">
    <link href="<?php echo e(asset('assets/front/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- <link href="<?php echo e(asset('assets/front/css/style.css')); ?>" rel="stylesheet"> -->
    <link href="<?php echo e(asset('assets/front/css/color.php')); ?>?color=<?php echo e($general->color); ?>" rel="stylesheet">

    <style>
        .header-login{
            background-color: transparent;
            color: #fff;
            font-size: 15px;
            padding: 5px 10px;
            border-radius: 5px;
            outline: none;
            border: 1px solid #f6f6f6;
        }
        .header-login option{
            background-color: #1E223F;
            padding: 5px 10px;
        }
        
        .header-login a{
            background: transparent;
            background-color: transparent;
        }
        .header-login a:hover{
            background: transparent;
            background-color: transparent;
        }
        .color{
            color:#<?php echo e($general->color); ?>; 
        }
        #header{
            height: 100vh;
            background-size: 100% 100%;
            position: relative;
        }

    </style>
    <?php echo $__env->yieldContent('style'); ?>
</head>

<body class="color-1">

<!-- PRELOADER -->
<div class="preloader">
    <div class="preloader-in">
        <div class="block"></div>
    </div>
</div>




<!--=-=-=-=-=-=-=-=-=-=-=-
          HEADER    
-=-=-=-=-=-=-=-=-=-=-=-=-=-->
    <header id="header" style="background: url(<?php echo e(asset('assets/images/front-bg/image_header.jpg')); ?>) center no-repeat fixed">

        <!-- ========== TOP BAR ========== -->
        <div id="top-bar">
            <div class="container">
                <div class="tb-inner">
                    <div class="left pull-left">
                        <a class="email" href="mailto:example@host.com"><span class="fa fa-envelope"></span><?php echo e($general->email); ?></a>
                        <a class="phone" href="tel:+0123456789"><span class="fa fa-phone"></span><?php echo e($general->number); ?></a>
                    </div>
                    <div class="right pull-right">
                        <?php if(!Auth::check()): ?>
                            <a href="<?php echo e(route('login')); ?>"><span class="fa fa-user"></span>Log in</a>
                            <a href="<?php echo e(route('register')); ?>"><span class="fa fa-edit"></span>Register</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- ========== NAVIGATION BAR ========== -->
        <nav id="navigation" class="navbar navbar-inverse navbar-custom" data-spy="affix" data-offset-top="35">
            <div class="container">

                <!-- === NAVBAR-HEADER ===  -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle hamburger" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a href="#top" class=""><img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="" style="max-height:60px;margin-top:5px;padding:5px;"></a>
                </div>

                <!-- ===MAIN-NAVBAR=== -->
                <div class="collapse navbar-collapse">
                <ul class="nav navbar-nav navbar-right">
                            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li><a href="<?php echo e(route('about-us')); ?>">About Us</a></li>
                            <li class="dropdown top"><a href="<?php echo e(route('news')); ?>">News <i class="fa fa-sort-desc"></i></a>
                                <ul class="dropdown-menu">
                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(route('category-news',['id'=>$c->id,'slug'=>str_slug($c->name)])); ?>"><?php echo e($c->name); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>
                            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(url('menu/')); ?>/<?php echo e($m->id); ?>/<?php echo e(urlencode(strtolower($m->name))); ?>"> <?php echo e($m->name); ?>

                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                            <?php if(Auth::check()): ?>
                                <li class="dropdown top">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Hi. <?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?> <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <?php if(Auth::check()): ?>
                                        <li> <a href="<?php echo e(route('user-dashboard')); ?>"> <i class="fa fa-dashboard"></i> Dashboard</a></li>
                                        <li>
                                        <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                            document.getElementById('logout-form').submit();" class=""><i class="fa fa-sign-out right"></i>Log Out</a>
                                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                                <?php echo e(csrf_field()); ?>

                                            </form>
                                        </li>
                                        <?php endif; ?>
                                    </ul>
                                </li>
                             <?php endif; ?>    
                    </ul>
                </div>
            </div>
        </nav>

   
         <?php echo $__env->yieldContent('content'); ?>


<!--=-=-=-=-=-=-=-=-=-=-=
        OUR CLIENTS   
-=-=-=-=-=-=-=-=-==-=-=-=-->
<section id="client">
        <div class="container">
            <div class="client-inner">
                <div class="title common text-center">
                    <h2>Accept Payment Method</h2>
                </div>
                <div class="main">
                    <div class="client-carousel owl-carousel owl-theme" id="client-carousel">
                     
                        <a href="<?php echo e(route('register')); ?>">
                            <div class="item">
                                <img src="<?php echo e(asset('assets/images')); ?>/<?php echo e($payment->paypal_image); ?>" alt="Logo">
                            </div>
                        </a>
                        <a href="<?php echo e(route('register')); ?>">
                            <div class="item">
                                <img src="<?php echo e(asset('assets/images')); ?>/<?php echo e($payment->perfect_image); ?>" alt="Logo">
                            </div>
                        </a>
                        <a href="<?php echo e(route('register')); ?>">
                            <div class="item">
                                <img src="<?php echo e(asset('assets/images')); ?>/<?php echo e($payment->btc_image); ?>" alt="Logo">
                            </div>
                        </a>
                        <a href="<?php echo e(route('register')); ?>">
                            <div class="item">
                                <img src="<?php echo e(asset('assets/images')); ?>/<?php echo e($payment->stripe_image); ?>" alt="Logo">
                            </div>
                        </a>
                   
    
                    </div>
                </div>
            </div>
        </div>
    </section>     

    <!--=-=-=-=-=-=-=-=-=-=-=
          FOOTER   
-=-=-=-=-=-=-=-=-==-=-=-=-->
<footer id="footer">
<div class="container">
    <div class="footer-inner">
        <div class="footer-top">
            <div class="social-icons">
                <ul class="no-style">
                    <li><a href="<?php echo e($general->facebook); ?>"><span class="fa fa-facebook"></span></a></li>
                    <li><a href="<?php echo e($general->twitter); ?>"><span class="fa fa-twitter"></span></a></li>
                    <li><a href="<?php echo e($general->linkedin); ?>"><span class="fa fa-linkedin"></span></a></li>
                    <li><a href="<?php echo e($general->google_plus); ?>"><span class="fa fa-google-plus"></span></a></li>
                    <li><a href="<?php echo e($general->youtube); ?>"><span class="fa fa-youtube"></span></a></li>
                </ul>
            </div>
            <a href="#top" class="back-to-top btn btn-info"><span class="fa fa-chevron-up"></span></a>
        </div>
    </div>
</div>
<div class="footer-bottom">
    <div class="container">
        <div class="footer-b-inner">
            <div class="links">
                <ul class="no-style">
                    <li><a href="<?php echo e(route('document')); ?>" class="transition3s">Document</a></li>
                    <li><a style="padding: 0px 20px" href="<?php echo e(route('faqs')); ?>" class="transition3s">FAQS</a></li>
                    <li><a href="<?php echo e(route('terms')); ?>" class="transition3s">Terms & Condition</a></li>
                    <li><a href="<?php echo e(route('privacy')); ?>" class="transition3s">Privacy & Security</a></li>
                </ul>
            </div>
            <div class="footer-text">
                <p><?php echo $general->footer_bottom_text; ?></p>
            </div>
        </div>
    </div>
</div>
</footer>

    <!-- ======= Body Scripts ======= -->

    <!-- Jquery Library -->
    <script src="<?php echo e(asset('assets/front/js/jquery-1.12.4.min.js')); ?>"></script>
    <!-- Bootstrap JS -->
    <script src="<?php echo e(asset('assets/front/js/bootstrap.min.js')); ?>"></script>
    <!-- Owl Carousel JS -->
    <script src="<?php echo e(asset('assets/front/owlcarousel/owl.carousel.min.js')); ?>"></script>
    <!-- WOW JS -->
    <script src="<?php echo e(asset('assets/front/js/wow.min.js')); ?>"></script>
    <!-- Way Points JS -->
    <script src="<?php echo e(asset('assets/front/js/waypoints.min.js')); ?>"></script>
    <!-- Counter JS -->
    <script src="<?php echo e(asset('assets/front/js/jquery.counterup.min.js')); ?>"></script>
    <!-- Slider JS -->
    <script src="<?php echo e(asset('assets/front/js/jquery-ui-slider.min.js')); ?>"></script>
    <!-- Arctext JS -->
    <script src="<?php echo e(asset('assets/front/js/jquery.arctext.js')); ?>"></script>
    <!-- Custom Js -->
    <script src="<?php echo e(asset('assets/front/js/script.js')); ?>"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
