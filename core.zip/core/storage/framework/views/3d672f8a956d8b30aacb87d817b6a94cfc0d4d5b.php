
<?php $__env->startSection('content'); ?>



    <!-- ========================== Inner Banner =================== -->
    <section class="inner_banner">
        <div class="container">
            <div class="banner-title">
                <h1><?php echo e($page_title); ?></h1>
                <span class="decor-equal"></span>
            </div>
        </div>
    </section>
    <!-- ========================== /Inner Banner =================== -->

    <!-- ======================= Breadcrumb ========================== -->
    <section class="breadcrumb_sec">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-6 col-sm-6 col-xs-3">
                    <h5><?php echo e($page_title); ?></h5>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-xs-9" style="text-align:right;">
                    <ul>
                        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li class="dot"></li>
                        <li><?php echo e($page_title); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- ======================= /Breadcrumb ========================== -->


    <!-- =========================== News container =================== -->
    <div class="news_content_container">
        <div class="container">
            <div class="row">
                <article class="col-lg-9 col-md-8 col-sm-12 col-xs-12 news_post">

                    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="single_news_post">
                        <div class="img_container">
                            <a href="<?php echo e(route('news-details',['id'=>$n->id,'slug'=>str_slug($n->title)])); ?>">
                            <img class="img-responsive" src="<?php echo e(asset('assets/images')); ?>/<?php echo e($n->image); ?>" alt="images">
                                </a>
                        </div> <!-- /img_container -->
                        <div class="post_holder">
                            <div class="post_heading">
                                <ul>
                                    <li><i class="fa fa-bars"></i><a href="#">Posted On <?php echo e($n->category->name); ?></a></li>
                                    <li>|</li>
                                    <li><i class="fa fa-calendar"></i><a href="#"><?php echo e(\Carbon\Carbon::parse($n->created_at)->format('d F Y')); ?> </a></li>
                                </ul>
                                <div class="title_container">
                                    <a href="<?php echo e(route('news-details',['id'=>$n->id,'slug'=>str_slug($n->title)])); ?>">
                                    <h4><?php echo e($n->title); ?></h4></a>
                                    <span class="decor_default"></span>
                                </div>
                            </div>  <!-- /post_heading -->
                            <p class="article"><?php echo e(substr(strip_tags($n->description),0,380)); ?><?php echo e(strlen(strip_tags($n->description)) > 380 ? "..." : ""); ?></p>
                        </div> <!-- /post_holder -->
                        <div class="share_read">
                            <ul class="share">
                                <li><a class="hvr-sweep-to-right" href="#"><i class="fa fa-eye"></i> View <?php  $gr = \App\News::findOrFail($n->id)  ?> <?php echo e($gr->view); ?></a></li>
                                <li><a class="hvr-sweep-to-right" href="#"><i class="fa fa-share"></i>Share</a></li>
                            </ul>
                            <div class="share_item">
                                <ul>
                                    <li><a target="_blank" href="http://www.facebook.com/share.php?u=<?php echo e(url()->current()); ?>/<?php echo e($n->id); ?>/<?php echo e(str_slug($n->title)); ?>&title=<?php echo e($n->title); ?>" class="hvr-sweep-to-right transition3s"><i class="fa fa-facebook"></i></a></li>
                                    <li><a target="_blank" href="http://twitter.com/home?status=<?php echo e($n->title); ?>+<?php echo e(url()->current()); ?>/<?php echo e($n->id); ?>/<?php echo e(str_slug($n->title)); ?>" class="hvr-sweep-to-right transition3s"><i class="fa fa-twitter"></i></a></li>
                                    <li><a target="_blank" href="https://plus.google.com/share?url=<?php echo e(url()->current()); ?>/<?php echo e($n->id); ?>/<?php echo e(str_slug($n->title)); ?>" class="hvr-sweep-to-right transition3s"><i class="fa fa-google-plus"></i></a></li>
                                </ul>
                            </div><!-- /share -->
                            <a href="<?php echo e(route('news-details',['id'=>$n->id,'slug'=>str_slug($n->title)])); ?>" class="read_more transition3s flt_right">Read More <i class="fa fa-caret-right"></i></a>
                            <div class="clear_fix"></div>
                        </div> <!-- /share_read -->
                    </div> <!-- /single_news_post -->

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div style="text-align:center;">
                        <?php echo $news->links(); ?>

                    </div> <!-- /pagination_menu -->
                </article> <!-- /news_post -->

                <!-- ====================== Blog aside ==================== -->

                <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 blog_aside">

                    <div class="blog_feeds">
                        <div class="title_container">
                            <h4>News</h4>
                            <span class="decor_default"></span>
                        </div>

                        <div class="single_feeds clear_fix"> <!-- single_feeds -->
                            <?php $__currentLoopData = $news_rand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="img_holder">
                                <img style="width: 70px;height: 70px" src="<?php echo e(asset('assets/images')); ?>/<?php echo e($nr->image); ?>" alt="images">
                            </div> <!--  /img_holder -->
                            <div class="text_holder">
                                <a href="<?php echo e(route('news-details',['id'=>$nr->id,'slug'=>str_slug($nr->title)])); ?>">
                                <h5><?php echo e(substr($nr->title,0,38)); ?><?php echo e(strlen($nr->title) > 38 ? "..." : ''); ?></h5></a>
                                <ul>
                                    <li><i class="fa fa-user"></i><?php echo e($nr->category->name); ?></li>
                                    <li>|</li>
                                    <li><i class="fa fa-calendar"></i><?php echo e(\Carbon\Carbon::parse($nr->created_at)->format('d M y')); ?></li>
                                </ul>
                            </div> <!-- /text_holder -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div> <!-- /single_feeds -->

                    </div> <!-- /blog_feeds -->
                    <div class="news_categories">
                        <div class="title_container">
                            <h4>Categories</h4>
                            <span class="decor_default"></span>
                        </div>
                        <ul>
                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route('category-news',['id'=>$cat->id,'slug'=>str_slug($cat->name)])); ?>"><i class="fa fa-angle-right"></i><?php echo e($cat->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div> <!-- /news_categories -->
                    <div class="instagram_photos">
                        <div class="title_container">
                            <h4>News Photos</h4>
                            <span class="decor_default"></span>
                        </div>
                        <div class="more_project_gallery">
                            <div>
                                <?php $__currentLoopData = $news_rand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="img_holder"><img style="width: 84px" class="img-responsive" src="<?php echo e(asset('assets/images')); ?>/<?php echo e($n->image); ?>" alt="images">
                                    <div class="hover_overlay hvr-shutter-out-vertical">
                                        <div class="content">
                                            <a class="fancybox" href="#"><i class="fa fa-link"></i></a>
                                        </div>
                                    </div>
                                </div> <!-- /img_holder -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div> <!-- /more_project_gallery -->
                    </div> <!-- /instragram_photos -->
                </div> <!-- /blog_aside -->
            </div> <!-- /row -->
        </div> <!-- /contianer -->
    </div>


    <!-- =========================== /News container =================== -->


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.font-end2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>