@php
	echo $array['content'];
@endphp
