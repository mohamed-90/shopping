<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\State;

class StateController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $sellers = State::orderBy('created_at', 'desc')->get();
        return view('state.index', compact('sellers'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         return view('state.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         
            $state = new State();
            $state->name = $request->name;
            $state->description = $request->description;
            if($request->status)
            {
               $state->status=1; 
            }
            else
            {
                $state->status=0;
            }
            
            if($state->save()){
              
                flash(__('State has been inserted successfully'))->success();
                return redirect()->route('states.index');
            }
            else {
                    flash(__('Something went wrong'))->error();
                    return back();
                }
 
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       $seller = State::findOrFail(decrypt($id));
        return view('state.edit', compact('seller'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $seller = State::findOrFail($id);
        $seller->name = $request->name;
        $seller->description = $request->description;
         if($request->status)
            {
               $seller->status=1; 
            }
            else
            {
                $seller->status=0;
            }
        
            if($seller->save()){
                flash(__('State has been updated successfully'))->success();
                return redirect()->route('states.index');
            }

        flash(__('Something went wrong'))->error();
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $seller = State::findOrFail($id);

        if(State::destroy($id)){
            flash(__('State has been deleted successfully'))->success();
            return redirect()->route('states.index');
        }

        flash(__('Something went wrong'))->error();
        return back();
    }
}
