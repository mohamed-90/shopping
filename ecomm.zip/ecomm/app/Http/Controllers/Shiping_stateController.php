<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\State;
use App\Shiping_state;
use Auth;

class Shiping_stateController extends Controller
{
    
    public function index()
    {
      $shiping = Shiping_state::orderBy('created_at', 'desc')->get();
        return view('frontend.seller.shipState', compact('shiping'));
    }
    
    public function create()
    {
        //
    }
   
    public function store(Request $request)
    {
         $sellers = State::orderBy('created_at', 'desc')->get();
        if(Auth::user())
        {
           $id_use = Auth::user()->id;
           
            foreach($sellers as $seller)
         {
             $shiping_state = new Shiping_state();
             $shiping_state->id_user = $id_use;
             $shiping_state->id_state = $seller->id;
             $shiping_state->status = 1 ;
             $shiping_state->save();
         }
            
        }
        flash(__('shiping States has been inserted successfully'))->success();
                return redirect()->route('shiping_state.index');
        
    }

    
    public function show($id)
    {
        //
    }

    
    public function edit($id)
    {
        //
    }

   public function modif($id)
   {
      $seller = Shiping_state::findOrFail($id);
     
         if($seller->status == 1)
            {
               $seller->status=0; 
            }
            else
            {
                $seller->status=1;
            }
        
            if($seller->save()){
                flash(__('Shiping state has been updated successfully'))->success();
                    return redirect()->route('shiping_state.index');
            }

        flash(__('Something went wrong'))->error();
        return back(); 
       
   }
    public function update(Request $request, $id)
    {
      $seller = Shiping_state::findOrFail($id);
     
         if($seller->status)
            {
               $seller->status=1; 
            }
            else
            {
                $seller->status=0;
            }
        
            if($seller->save()){
                flash(__('Shiping state has been updated successfully'))->success();
                    return redirect()->route('shiping_state.index');
            }

        flash(__('Something went wrong'))->error();
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
