<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;
use App\Make_offer;
use Illuminate\Support\Facades\Session;

use Auth;

class CompareController extends Controller
{
    public function index(Request $request)
    {
        //dd($request->session()->get('compare'));
        $categories = Category::all();
        return view('frontend.view_compare', compact('categories'));
    }
    
    public function addTomake_offer(Request $request)
    {
        if(Auth::check())
        {
        $mo = new Make_offer();       
        $mo->user_id = Auth::user()->id;
        $mo->id_product = $request->id;
        $mo->id_admin = $request->id_admin;
        $mo->price = $request->price;
        $mo->old_price = $request->old_price;
        $mo->description = $request->description;
        $mo->save();
        
        flash(__('The make offer successfully'))->success();
      
        return back(); 
        }
        else
        {
            return view('frontend.user_login');
        }
       
    }

    //clears the session data for compare
    public function reset(Request $request)
    {
        $request->session()->forget('compare');
        return back();
    }

    //store comparing products ids in session 
    public function addToCompare(Request $request)
    {
        if($request->session()->has('compare')){
            $compare = $request->session()->get('compare', collect([]));
            if(!$compare->contains($request->id)){
                if(count($compare) == 3){
                    $compare->forget(0);
                    $compare->push($request->id);
                }
                else{
                    $compare->push($request->id);
                }
            }
        }
        else{
            $compare = collect([$request->id]);
            $request->session()->put('compare', $compare);
        }

        return view('frontend.partials.compare');
    }
}
